"""Admission for an explicitly provisioned CV data volume; never mounts disks.

The Windows owner tool maintains the binding outside the VHD. A directory with
the right name is insufficient: every launch rechecks the live ext4/partition
identity and physical host capacity. This is not an OS security boundary.
"""
from __future__ import annotations

import base64
import json
import os
from pathlib import Path
import stat
import subprocess
import time
import uuid

GIB = 1024 ** 3
VHD_PATH = r"H:\CVToolkit\storage\cv-data.vhdx"
MOUNT = "/mnt/wsl/cv-toolkit"
SCHEMA = "CVDataVolume-v1"


class StorageUnavailable(RuntimeError):
    pass


class StorageUse:
    """Hold an admitted volume busy for a consumer's complete lifetime.

    The Windows unmount owner must record stop-requested before checking fuser.
    Entry rechecks that mutable binding after opening, closing the admission
    race. This directory FD is deliberately inheritable only through an
    explicit subprocess pass_fds argument; abrupt supervisor exit cannot then
    remove protection while an owned child is still writing.
    """
    def __init__(self, binding_path):
        if not isinstance(binding_path, (str, Path)):
            raise StorageUnavailable("storage_use_binding_path_required")
        self.binding_path = Path(binding_path)
        self.fd = None
        self.report = None

    def __enter__(self):
        if self.fd is not None:
            raise StorageUnavailable("storage_use_already_entered")
        if os.name != "posix" or not hasattr(os, "O_DIRECTORY") or not hasattr(os, "O_NOFOLLOW"):
            raise StorageUnavailable("storage_use_platform_unqualified")
        before = validate_storage(self.binding_path)
        root = Path(before["binding"]["dataRoot"])
        metadata = root.stat()
        try:
            self.fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
            opened = os.fstat(self.fd)
            device = Path(before["mount"]["source"]).stat().st_rdev
            if (not stat.S_ISDIR(opened.st_mode) or opened.st_dev != device
                    or (opened.st_dev, opened.st_ino) != (metadata.st_dev, metadata.st_ino)
                    or opened.st_uid != before["binding"]["uid"]):
                raise StorageUnavailable("storage_use_directory_identity_changed")
            after = validate_storage(self.binding_path)
            if after["binding"] != before["binding"]:
                raise StorageUnavailable("storage_use_binding_changed_during_open")
            current = root.stat()
            if (current.st_dev, current.st_ino) != (opened.st_dev, opened.st_ino):
                raise StorageUnavailable("storage_use_directory_changed_during_open")
            self.report = after
            return self
        except BaseException:
            self.close()
            raise

    def fileno(self):
        if self.fd is None:
            raise StorageUnavailable("storage_use_not_active")
        return self.fd

    def close(self):
        descriptor, self.fd = self.fd, None
        if descriptor is not None:
            os.close(descriptor)

    def __exit__(self, exc_type, exc, tb):
        self.close()


def _guid(value):
    try:
        return str(uuid.UUID(str(value).strip("{}")))
    except (ValueError, TypeError, AttributeError):
        raise StorageUnavailable("storage_guid_invalid") from None


def validate_binding(binding: dict) -> dict:
    if not isinstance(binding, dict) or binding.get("schemaVersion") != SCHEMA:
        raise StorageUnavailable("storage_binding_schema_invalid")
    expected = {"owner": "portable-cv-toolkit", "vhdPath": VHD_PATH,
                "mountName": "cv-toolkit", "distro": "Ubuntu-24.04",
                "linuxMountPoint": MOUNT, "dataRoot": MOUNT + "/cv-toolkit",
                "uid": 1001, "virtualSizeBytes": 128 * GIB,
                "creationOwnership": True}
    for key, value in expected.items():
        if type(binding.get(key)) is not type(value) or binding[key] != value:
            raise StorageUnavailable("storage_binding_" + key + "_mismatch")
    for key in ("id", "vhdDiskIdentifier", "windowsDiskGuid", "partitionGuid", "fsUuid"):
        _guid(binding.get(key))
    for key in ("partitionNumber", "partitionOffsetBytes", "partitionSizeBytes", "gid"):
        value = binding.get(key)
        if type(value) is not int or value < (0 if key == "gid" else 1):
            raise StorageUnavailable("storage_binding_" + key + "_invalid")
    if binding["partitionOffsetBytes"] + binding["partitionSizeBytes"] > binding["virtualSizeBytes"]:
        raise StorageUnavailable("storage_partition_outside_disk")
    if binding.get("phase") != "mounted":
        raise StorageUnavailable("storage_binding_not_mounted")
    if binding.get("lastError"):
        raise StorageUnavailable("storage_binding_unresolved_error")
    return binding


def load_binding(path: Path) -> dict:
    path = Path(path)
    if path.is_symlink() or path.stat().st_size > 65536:
        raise StorageUnavailable("storage_binding_file_invalid")
    return validate_binding(json.loads(path.read_text(encoding="utf-8-sig")))


def _json_command(arguments):
    result = subprocess.run(arguments, text=True, capture_output=True, timeout=15, check=True)
    return json.loads(result.stdout)


def observe_mount(binding: dict) -> dict:
    """Read Linux mount/block metadata only. Unknown observations fail closed."""
    try:
        mounts = _json_command(["findmnt", "--json", "--mountpoint", binding["linuxMountPoint"],
                                "--output", "TARGET,SOURCE,FSTYPE,UUID,OPTIONS"])["filesystems"]
        if len(mounts) != 1:
            return {"status": "unknown"}
        row = mounts[0]
        tree = _json_command(["lsblk", "--json", "--tree", "--bytes", "--output",
                              "PATH,TYPE,SIZE,START,PARTUUID,PTUUID,UUID"])["blockdevices"]
        matches = []
        def visit(rows, parent=None):
            for device in rows:
                if device.get("path") == row.get("source"):
                    matches.append((device, parent))
                visit(device.get("children", []), device)
        visit(tree)
        if len(matches) != 1 or matches[0][1] is None:
            return {"status": "unknown"}
        part, disk = matches[0]
        return {"status": "observed", "target": row.get("target"), "source": row.get("source"),
                "fstype": row.get("fstype"), "uuid": row.get("uuid"), "options": row.get("options"),
                "partuuid": part.get("partuuid"), "disk_guid": disk.get("ptuuid"),
                "partition_size_bytes": int(part["size"]), "offset_bytes": int(part["start"]) * 512,
                "disk_size_bytes": int(disk["size"])}
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError):
        return {"status": "unknown"}


def host_capacity() -> dict:
    """Physical Windows volume space, independent of the ext4 virtual ceiling."""
    script = ('@("C", "H") | ForEach-Object { $v=Get-Volume -DriveLetter $_ -ErrorAction Stop; '
              '[pscustomobject]@{drive=$_;free_bytes=[long]$v.SizeRemaining;'
              'volume_id=[string]$v.UniqueId;health=[string]$v.HealthStatus} } | ConvertTo-Json -Compress')
    encoded = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
    try:
        rows = _json_command(["powershell.exe", "-NoProfile", "-NonInteractive", "-EncodedCommand", encoded])
        return {"observed_at": time.time(), "free_bytes": {r["drive"]: r["free_bytes"] for r in rows},
                "volume_ids": {r["drive"]: r["volume_id"] for r in rows},
                "health": {r["drive"]: r["health"] for r in rows}}
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError):
        return {"observed_at": None, "free_bytes": {}}


def admission(binding: dict, *, observation=None, capacity=None, now=None, required_bytes=0) -> list[str]:
    try:
        validate_binding(binding)
    except StorageUnavailable as error:
        return [str(error)]
    observation = observe_mount(binding) if observation is None else observation
    capacity = host_capacity() if capacity is None else capacity
    now = time.time() if now is None else now
    gaps = []
    if type(required_bytes) is not int or required_bytes < 0:
        return ["storage_growth_budget_invalid"]
    if not isinstance(observation, dict) or not isinstance(capacity, dict):
        return ["storage_observation_malformed"]
    if any(not isinstance(capacity.get(key, {}), dict) for key in ("free_bytes", "health", "volume_ids")):
        return ["host_capacity_malformed"]
    if observation.get("status") != "observed":
        gaps.append("storage_mount_unknown")
    else:
        expected = {"target": binding["linuxMountPoint"], "fstype": "ext4",
                    "partition_size_bytes": binding["partitionSizeBytes"],
                    "offset_bytes": binding["partitionOffsetBytes"],
                    "disk_size_bytes": binding["virtualSizeBytes"]}
        for key, value in expected.items():
            if type(observation.get(key)) is not type(value) or observation[key] != value:
                gaps.append("storage_" + key + "_mismatch")
        for key, bind_key in (("uuid", "fsUuid"), ("partuuid", "partitionGuid"), ("disk_guid", "windowsDiskGuid")):
            try:
                if _guid(observation.get(key)) != _guid(binding[bind_key]):
                    gaps.append("storage_" + key + "_mismatch")
            except StorageUnavailable:
                gaps.append("storage_" + key + "_unknown")
        if "rw" not in str(observation.get("options", "")).split(","):
            gaps.append("storage_not_writable")
        if not str(observation.get("source", "")).startswith("/dev/"):
            gaps.append("storage_device_unknown")
    stamp = capacity.get("observed_at")
    if type(stamp) not in (int, float) or not 0 <= now - stamp <= 60:
        gaps.append("host_capacity_stale_or_unknown")
    for drive, reserve in (("C", 30 * GIB), ("H", 100 * GIB)):
        available = capacity.get("free_bytes", {}).get(drive)
        growth = max(GIB, required_bytes) if drive == "H" else 0
        if type(available) is not int or available < reserve + growth:
            gaps.append("host_" + drive.lower() + "_capacity_unknown_or_below_reserve")
        if capacity.get("health", {}).get(drive) != "Healthy":
            gaps.append("host_" + drive.lower() + "_health_unknown_or_unhealthy")
    if not binding.get("hostHVolumeId") or capacity.get("volume_ids", {}).get("H") != binding["hostHVolumeId"]:
        gaps.append("host_h_volume_identity_mismatch")
    return gaps


def validate_storage(binding_path_or_dict, *, required_bytes=0) -> dict:
    """Fresh admission report, or StorageUnavailable; performs no disk mutation."""
    try:
        binding = (validate_binding(binding_path_or_dict) if isinstance(binding_path_or_dict, dict)
                   else load_binding(Path(binding_path_or_dict)))
        observation, capacity = observe_mount(binding), host_capacity()
        gaps = admission(binding, observation=observation, capacity=capacity, required_bytes=required_bytes)
        if gaps:
            raise StorageUnavailable(",".join(gaps))
        root = _validate_data_root(binding, observation)
        space = os.statvfs(root)
        available = space.f_bavail * space.f_frsize
        if available < max(GIB, required_bytes):
            raise StorageUnavailable("storage_ext4_capacity_below_growth_budget")
        return {"status": "admitted", "binding": binding, "mount": observation, "capacity": capacity}
    except (OSError, ValueError, TypeError, KeyError) as error:
        raise StorageUnavailable("storage_binding_unreadable_or_invalid") from error


def _validate_data_root(binding, observation):
    root = Path(binding["dataRoot"])
    if (not root.is_dir() or root.resolve() != root.absolute() or root.stat().st_uid != binding["uid"]
            or root.stat().st_mode & 0o022 or not os.access(root, os.W_OK | os.X_OK)):
        raise StorageUnavailable("storage_data_root_identity_invalid")
    device = Path(observation["source"]).stat().st_rdev
    if root.stat().st_dev != device or Path(binding["linuxMountPoint"]).stat().st_dev != device:
        raise StorageUnavailable("storage_data_root_device_mismatch")
    return root


def validate_storage_path(binding_path_or_dict, path, *, required_bytes=0) -> Path:
    """Reject symlinks and nested foreign mounts, including an existing parent."""
    return validate_storage_paths(binding_path_or_dict, [path], required_bytes=required_bytes)[0]


def validate_storage_paths(binding_path_or_dict, paths, *, required_bytes=0) -> list[Path]:
    """One fresh admission, followed by complete local checks for every path."""
    if isinstance(paths, (str, bytes, Path)):
        raise StorageUnavailable("storage_paths_iterable_required")
    try:
        paths = list(paths)
    except TypeError as error:
        raise StorageUnavailable("storage_paths_iterable_required") from error
    report = validate_storage(binding_path_or_dict, required_bytes=required_bytes)
    root = Path(report["binding"]["dataRoot"])
    return [_validate_admitted_path(root, path) for path in paths]


def _validate_admitted_path(root: Path, path) -> Path:
    target = Path(path).absolute()
    if not target.is_relative_to(root) or target.resolve() != target:
        raise StorageUnavailable("storage_output_escape")
    device = root.stat().st_dev
    cursor = target
    while cursor != root:
        if cursor.exists() and cursor.stat().st_dev != device:
            raise StorageUnavailable("storage_output_device_mismatch")
        cursor = cursor.parent
    return target


def child_environment(binding: dict, base_env=None, *, parent_env=None, observation=None, capacity=None,
                      create=False) -> dict[str, str]:
    """Explicitly prepare process-local paths; HOME and GPU lease stay unchanged."""
    gaps = admission(binding, observation=observation, capacity=capacity)
    if gaps:
        raise StorageUnavailable(",".join(gaps))
    observation = observe_mount(binding) if observation is None else observation
    root = _validate_data_root(binding, observation)
    space = os.statvfs(root)
    if space.f_bavail * space.f_frsize < GIB:
        raise StorageUnavailable("storage_ext4_capacity_below_growth_budget")
    paths = {"UV_CACHE_DIR": "cache/uv", "HF_HOME": "cache/huggingface", "TORCH_HOME": "cache/torch",
             "TORCHINDUCTOR_CACHE_DIR": "cache/torchinductor", "TRITON_CACHE_DIR": "cache/triton",
             "CUDA_CACHE_PATH": "cache/cuda", "XDG_CACHE_HOME": "cache", "TMPDIR": "tmp",
             "TMP": "tmp", "TEMP": "tmp", "PIP_CACHE_DIR": "cache/pip"}
    if base_env is not None and parent_env is not None:
        raise StorageUnavailable("storage_environment_arguments_conflict")
    inherited = base_env if base_env is not None else parent_env
    result = dict(os.environ if inherited is None else inherited)
    for key, relative in paths.items():
        path = root / relative
        if path.resolve() != path.absolute():
            raise StorageUnavailable("storage_cache_symlink_rejected")
        cursor = path
        while cursor != root:
            if cursor.exists() and cursor.stat().st_dev != root.stat().st_dev:
                raise StorageUnavailable("storage_cache_device_mismatch")
            cursor = cursor.parent
        if create:
            path.mkdir(mode=0o700, parents=True, exist_ok=True)
        if (not path.is_dir() or path.resolve() != path.absolute() or path.stat().st_uid != binding["uid"]
                or path.stat().st_dev != root.stat().st_dev or not os.access(path, os.W_OK | os.X_OK)):
            raise StorageUnavailable("storage_cache_missing_or_unowned")
        result[key] = str(path)
    return result
