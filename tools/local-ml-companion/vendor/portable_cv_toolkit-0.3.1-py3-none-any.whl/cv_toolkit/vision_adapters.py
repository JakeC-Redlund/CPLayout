"""Pinned local Transformers vision adapters, run only in the managed worker."""
from __future__ import annotations

import importlib.metadata
import json
import math
import os
from pathlib import Path
import time

from .adapters import ReadinessGap, autocast, synchronize, timed_summary, torch_setup
from .artifacts import artifact_row, atomic_json, json_sha256
from .media import (FrameJournal, VideoSelection, index_video, iter_pdf_pages,
                    iter_video_frames, load_image, resize_for_model)


def _progress(context, stage, completed, total, unit):
    # Mutable live counters are advisory. Immutable result/index artifacts bind
    # evidence. The worker owns this directory and never follows a target link.
    target = context.output / "progress.json"
    if target.is_symlink():
        raise ValueError("progress_symlink_rejected")
    temporary = context.output / ".progress-next"
    with temporary.open("x", encoding="utf-8") as stream:
        json.dump({"stage": stage, "completed": completed, "total": total, "unit": unit}, stream)
        stream.flush()
    os.replace(temporary, target)


def _versions(names):
    for name, expected in names.items():
        try:
            actual = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError as error:
            raise ReadinessGap("dependency_missing:" + name) from error
        if actual != expected:
            raise ReadinessGap("dependency_version_mismatch:" + name)


def normalize_quads(boxes, scores, width, height):
    """Reject malformed/degenerate boxes; clip valid quads to actual pixels."""
    import numpy as np
    import cv2
    boxes = np.asarray(boxes, dtype=float)
    scores = np.asarray(scores, dtype=float)
    if boxes.size == 0 and scores.size == 0:
        return [], []
    if boxes.ndim != 3 or boxes.shape[1:] != (4, 2) or scores.shape != (len(boxes),):
        raise ValueError("ocr_quad_shape_invalid")
    if not np.isfinite(boxes).all() or not np.isfinite(scores).all():
        raise ValueError("ocr_detection_nonfinite")
    accepted, rejected = [], []
    for source_index, (box, score) in enumerate(zip(boxes, scores)):
        if not 0 <= score <= 1:
            raise ValueError("ocr_detection_score_invalid")
        if ((box[:, 0] < 0).all() or (box[:, 1] < 0).all() or
                (box[:, 0] > width - 1).all() or (box[:, 1] > height - 1).all()):
            rejected.append({"source_index": source_index, "reason": "outside_image"})
            continue
        box[:, 0] = np.clip(box[:, 0], 0, width - 1)
        box[:, 1] = np.clip(box[:, 1], 0, height - 1)
        hull = cv2.convexHull(box.astype(np.float32)).reshape((-1, 2))
        if len(hull) != 4 or abs(cv2.contourArea(hull)) < 2:
            rejected.append({"source_index": source_index, "reason": "degenerate_quad"})
            continue
        # Cyclic corner order, anchored nearest the top-left, works for rotated
        # quadrilaterals without a sum/difference tie selecting one point twice.
        center = hull.mean(axis=0)
        ordered = hull[np.argsort(np.arctan2(hull[:, 1] - center[1], hull[:, 0] - center[0]))]
        first = min(range(4), key=lambda i: (float(ordered[i].sum()), float(ordered[i, 1]), float(ordered[i, 0])))
        ordered = np.roll(ordered, -first, axis=0)
        accepted.append({"quad": ordered.tolist(), "detection_score": float(score), "source_index": source_index})
    accepted.sort(key=lambda row: (min(p[1] for p in row["quad"]), min(p[0] for p in row["quad"]), row["source_index"]))
    return accepted, rejected


def perspective_crop(image_array, quad):
    import numpy as np
    import cv2
    points = np.asarray(quad, dtype=np.float32)
    width = max(2, int(round(max(np.linalg.norm(points[0] - points[1]), np.linalg.norm(points[2] - points[3])))))
    height = max(2, int(round(max(np.linalg.norm(points[0] - points[3]), np.linalg.norm(points[1] - points[2])))))
    if width * height > image_array.shape[0] * image_array.shape[1] * 2:
        raise ValueError("ocr_crop_oversized")
    target = np.asarray([[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]], dtype=np.float32)
    matrix = cv2.getPerspectiveTransform(points, target)
    if not np.isfinite(matrix).all() or abs(np.linalg.det(matrix)) < 1e-12:
        raise ValueError("ocr_crop_transform_invalid")
    crop = cv2.warpPerspective(image_array, matrix, (width, height), flags=cv2.INTER_CUBIC,
                               borderMode=cv2.BORDER_REPLICATE)
    rotated = height / width >= 1.5
    if rotated:
        crop = np.rot90(crop).copy()
    return crop, {"input_to_unrotated_crop": matrix.tolist(), "crop_rotation_ccw": 90 if rotated else 0,
                  "crop_dimensions": [int(crop.shape[1]), int(crop.shape[0])]}


def _tensor_observation(context, name, tensor, model):
    context.stage(name, str(tensor.device), tensors_verified=True,
                  parameter_device=str(next(model.parameters()).device), evidence="returned-tensor-device")


class OCRModel:
    def __init__(self, job, context, bundles):
        _versions({"transformers": "5.17.0"})
        self.job, self.context = job, context
        self.torch, _, self.device = torch_setup(job, context)
        try:
            from transformers import AutoImageProcessor, AutoModelForObjectDetection, AutoModelForTextRecognition
            import cv2
        except (ImportError, OSError) as error:
            raise ReadinessGap("ocr_dependencies_unavailable:" + type(error).__name__) from error
        start = time.perf_counter()
        local = {"local_files_only": True, "trust_remote_code": False}
        self.det_processor = AutoImageProcessor.from_pretrained(str(bundles["ocr-det"]), backend="torchvision",
            limit_side_len=min(job["configuration"]["max_side"], 1536), limit_type="max", **local)
        self.rec_processor = AutoImageProcessor.from_pretrained(str(bundles["ocr-rec"]), backend="torchvision", **local)
        self.det_model = AutoModelForObjectDetection.from_pretrained(str(bundles["ocr-det"]), use_safetensors=True, **local).to(self.device).eval()
        self.rec_model = AutoModelForTextRecognition.from_pretrained(str(bundles["ocr-rec"]), use_safetensors=True, **local).to(self.device).eval()
        synchronize(self.torch, self.device)
        context.timings["model_load_ms"] = (time.perf_counter() - start) * 1000

    def predict(self, image):
        import numpy as np
        config, torch = self.job["configuration"], self.torch
        self.context.check()
        bounded, transform = resize_for_model(image, config["max_side"])
        inputs = self.det_processor(images=bounded, return_tensors="pt").to(self.device)
        with torch.inference_mode(), autocast(torch, self.job):
            outputs = self.det_model(**inputs)
        _tensor_observation(self.context, "ocr_text_detection", outputs.last_hidden_state, self.det_model)
        # The pinned processor converts tensors to NumPy, which cannot expose
        # bfloat16 directly. Keep observed forward dtype/device independent.
        outputs.last_hidden_state = outputs.last_hidden_state.float()
        detections = self.det_processor.post_process_object_detection(outputs,
            target_sizes=inputs["target_sizes"], max_candidates=config["max_regions"] + 1)[0]
        boxes = detections["boxes"].detach().cpu().numpy()
        scores = detections["scores"].detach().cpu().numpy()
        if boxes.size:
            boxes = boxes.astype(float)
            boxes[..., 0] *= transform["model_to_input_scale"][0]
            boxes[..., 1] *= transform["model_to_input_scale"][1]
        regions, rejected = normalize_quads(boxes, scores, image.width, image.height)
        truncated = len(regions) > config["max_regions"]
        regions = regions[:config["max_regions"]]
        # Release detector tensors before cropped recognition. Crop one region
        # at a time so wide text cannot create an unbounded padded batch.
        del inputs, outputs, detections
        pixels = np.asarray(image)
        for index, region in enumerate(regions):
            self.context.check()
            crop, crop_transform = perspective_crop(pixels, region["quad"])
            inputs = self.rec_processor(images=[crop], return_tensors="pt").to(self.device)
            with torch.inference_mode(), autocast(torch, self.job):
                outputs = self.rec_model(**inputs)
            _tensor_observation(self.context, "ocr_text_recognition", outputs.last_hidden_state, self.rec_model)
            texts = self.rec_processor.post_process_text_recognition(outputs)
            if len(texts) != 1 or not isinstance(texts[0].get("text"), str):
                raise ValueError("ocr_recognition_output_invalid")
            text, score = texts[0]["text"], float(texts[0]["score"])
            # Upstream CTC gives NaN mean for an all-blank sequence.
            if not text and math.isnan(score):
                score = 0.0
            if not math.isfinite(score) or not 0 <= score <= 1:
                raise ValueError("ocr_recognition_score_invalid")
            region.update(region_id=f"text-{index:04d}", text=text, recognition_score=score,
                crop_transform=crop_transform, box_xyxy=[min(p[0] for p in region["quad"]),
                    min(p[1] for p in region["quad"]), max(p[0] for p in region["quad"]), max(p[1] for p in region["quad"])])
            del inputs, outputs, crop
        return {"regions": regions, "rejected_regions": rejected, "regions_truncated": truncated,
                "preprocessing": transform, "reading_order": "top_then_left_geometric_only"}


class DetectionModel:
    def __init__(self, job, context, bundles):
        _versions({"transformers": "5.17.0"})
        self.job, self.context = job, context
        self.torch, _, self.device = torch_setup(job, context)
        try:
            from transformers import AutoProcessor, AutoModelForZeroShotObjectDetection
        except (ImportError, OSError) as error:
            raise ReadinessGap("detection_dependencies_unavailable:" + type(error).__name__) from error
        start = time.perf_counter()
        local = {"local_files_only": True, "trust_remote_code": False}
        self.processor = AutoProcessor.from_pretrained(str(bundles["detector"]), **local)
        self.model = AutoModelForZeroShotObjectDetection.from_pretrained(str(bundles["detector"]),
            disable_custom_kernels=True, use_safetensors=True, **local).to(self.device).eval()
        synchronize(self.torch, self.device)
        context.timings["model_load_ms"] = (time.perf_counter() - start) * 1000

    def predict(self, image):
        config, torch = self.job["configuration"], self.torch
        bounded, transform = resize_for_model(image, config["max_side"])
        rows = []
        # Separate bounded prompts preserve immutable query identity without
        # guessing which words a multi-label model phrase belonged to.
        for query in config["queries"]:
            self.context.check()
            prompt = query["text"].strip().rstrip(".") + "."
            inputs = self.processor(images=bounded, text=prompt, return_tensors="pt").to(self.device)
            if inputs["input_ids"].shape[-1] > self.model.config.max_text_len:
                raise ValueError("detection_query_token_limit")
            with torch.inference_mode(), autocast(torch, self.job):
                outputs = self.model(**inputs)
            _tensor_observation(self.context, "text_guided_detection", outputs.logits, self.model)
            result = self.processor.post_process_grounded_object_detection(outputs, inputs["input_ids"],
                threshold=config["threshold"], text_threshold=config["text_threshold"],
                target_sizes=[(image.height, image.width)])[0]
            boxes, scores = result["boxes"].detach().cpu().tolist(), result["scores"].detach().cpu().tolist()
            labels = result["text_labels"]
            if len(boxes) != len(scores) or len(boxes) != len(labels):
                raise ValueError("detection_output_shape_invalid")
            for box, score, label in zip(boxes, scores, labels):
                if len(box) != 4 or not all(math.isfinite(x) for x in box) or not math.isfinite(score) or not 0 <= score <= 1:
                    raise ValueError("detection_output_nonfinite_or_invalid")
                box = [max(0, min(image.width if i % 2 == 0 else image.height, value)) for i, value in enumerate(box)]
                if box[2] <= box[0] or box[3] <= box[1]:
                    continue
                rows.append({"query_id": query["id"], "box_xyxy": box, "score": score, "text_label": str(label)})
            del inputs, outputs, result
        rows.sort(key=lambda row: (-row["score"], row["query_id"], row["box_xyxy"]))
        return {"detections": rows[:config["max_detections"]], "detections_truncated": len(rows) > config["max_detections"],
                "preprocessing": transform, "query_evaluation": "sequential_single_query"}


def _predict(model, image, context):
    synchronize(model.torch, model.device)
    start = time.perf_counter()
    result = model.predict(image)
    synchronize(model.torch, model.device)
    elapsed = (time.perf_counter() - start) * 1000
    context.timings["compute_ms"] = context.timings.get("compute_ms", 0) + elapsed
    return result, elapsed


def _run(job, context, model_class, medium, tracking=False):
    from .bundles import stage_job_assets
    try:
        staged = stage_job_assets(job, context)
        config = job["configuration"]
        max_pixels = job["limits"]["max_pixels"]
        index = None
        if medium == "video":
            _versions({"av": "18.1.0"})
            selection = VideoSelection.from_config(config)
            _progress(context, "decode", 0, None, "frames")
            index = index_video(staged["media"], selection, check=context.check,
                progress=lambda count: _progress(context, "decode", count, None, "frames"))
            path = atomic_json(context.output, "frame-index.json", index, protected=context.protected)
            context.outputs.append(artifact_row(path, context.output, role="frame-index"))
            _progress(context, "decode", index["decoded_frames"], index["decoded_frames"], "frames")
        elif medium == "pdf":
            _versions({"pypdfium2": "5.13.0"})
        model = model_class(job, context, staged["bundles"])
        if medium == "video":
            return _video(job, context, model, staged["media"], selection, index, tracking)
        if medium == "image":
            image, metadata = load_image(staged["media"], max_pixels=max_pixels)
            warmups, samples, prediction = [], [], None
            total = config["warmup_steps"] + config["measurement_runs"]
            for iteration in range(total):
                prediction, elapsed = _predict(model, image, context)
                (warmups if iteration < config["warmup_steps"] else samples).append(elapsed)
                _progress(context, "inference", iteration + 1, total, "runs")
            context.timings.update(warmup_ms=warmups, measurement=timed_summary(samples))
            items = [{**metadata, **prediction}]
        else:
            items = []
            for image, metadata in iter_pdf_pages(staged["media"], config["pages"], dpi=config["dpi"],
                                                 max_pixels=max_pixels, check=context.check):
                prediction, elapsed = _predict(model, image, context)
                items.append({**metadata, **prediction, "inference_ms": elapsed})
                _progress(context, "inference", len(items), len(config["pages"]), "pages")
                del image
        packet = {"schema_version": "CVVisionPredictions-v1", "job_id": job["job_id"],
                  "job_sha256": json_sha256(job), "model_revisions": config["model_revisions"],
                  "media_asset": {key: value for key, value in next(row for row in job["assets"] if row["role"] != "model").items()
                                  if key in {"id", "sha256", "role"}},
                  "configuration_sha256": json_sha256(config),
                  "medium": medium, "complete": True, "items": items,
                  "quality_evaluated": False, "operator_accepted": False}
        path = atomic_json(context.output, "predictions.json", packet, protected=context.protected)
        context.outputs.append(artifact_row(path, context.output, role="vision-predictions"))
        return {"prediction_ref": path.name, "item_count": len(items), "complete": True,
                "quality_evaluated": False, "operator_accepted": False,
                "limitations": ["uncalibrated_model_scores", "screening_candidate_not_field_qualification"]}
    except (ImportError, ModuleNotFoundError) as error:
        raise ReadinessGap("vision_dependency_import_failed:" + type(error).__name__) from error


def _video(job, context, model, media, selection, index, tracking):
    trackers = None
    if tracking:
        _versions({"trackers": "2.6.1", "supervision": "0.30.5"})
        from .tracking import QueryTrackers
        trackers = QueryTrackers(job["job_id"], job["configuration"]["queries"], job["configuration"])
    journal = FrameJournal(context, index["decoded_frames"])
    complete, samples = False, []
    try:
        for image, metadata in iter_video_frames(media, selection, check=context.check, expected_index=index["frames"]):
            prediction, elapsed = _predict(model, image, context)
            if trackers:
                prediction["detections"] = trackers.update(prediction["detections"], metadata["timestamp_seconds"])
            journal.append({**metadata, **prediction, "inference_ms": elapsed})
            samples.append(elapsed)
            _progress(context, "inference", journal.count, index["decoded_frames"], "frames")
            del image
        complete = journal.count == index["decoded_frames"]
        if not complete:
            raise ValueError("video_inference_coverage_incomplete")
    finally:
        journal.close(complete=complete)
    context.timings["measurement"] = timed_summary(samples)
    return {"prediction_ref": "predictions.jsonl", "frame_index_sha256": index["frame_index_sha256"],
            "decoded_frames": index["decoded_frames"], "processed_frames": journal.count,
            "missing_frames": index["decoded_frames"] - journal.count, "complete": complete,
            "frame_policy": "every-frame", "quality_evaluated": False, "operator_accepted": False,
            "limitations": ["cpu_codec_decode", "algorithmic_tracks_not_physical_identity",
                            "independent_query_classes_may_describe_same_object", "uncalibrated_model_scores"]}


def ppocr_image(job, context):
    return _run(job, context, OCRModel, "image")


def ppocr_pdf(job, context):
    return _run(job, context, OCRModel, "pdf")


def ppocr_video(job, context):
    return _run(job, context, OCRModel, "video")


def grounding_dino_image(job, context):
    return _run(job, context, DetectionModel, "image")


def grounding_dino_pdf(job, context):
    return _run(job, context, DetectionModel, "pdf")


def grounding_dino_video_track(job, context):
    return _run(job, context, DetectionModel, "video", tracking=True)


ADAPTERS = {"ppocr-image": ppocr_image, "ppocr-pdf": ppocr_pdf, "ppocr-video": ppocr_video,
            "grounding-dino-image": grounding_dino_image, "grounding-dino-pdf": grounding_dino_pdf,
            "grounding-dino-video-track": grounding_dino_video_track}
