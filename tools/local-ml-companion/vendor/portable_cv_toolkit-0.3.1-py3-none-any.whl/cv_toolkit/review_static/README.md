# Local review interface

The review server is optional. Base-toolkit imports do not import FastAPI,
Uvicorn, PDF, video, imaging or model libraries. Install the owner-pinned review
dependencies in the managed environment before starting it. No browser CDN,
JavaScript framework, cloud service or API key is used.

Start with a **machine-local**, owner-controlled JSON configuration:

```sh
python -m cv_toolkit.review_server --config /absolute/local-review-host.json
```

The command prints the exact loopback URL, then its instance identity. Open
that URL. The host profile registry and its mounted-storage binding are checked
before any state-directory creation. Review state must be inside the admitted
data root. Model runtimes and preview subprocesses currently require Linux/WSL.
The Windows launcher opens ordinary-user Edge against this loopback service.

The host configuration is `CVReviewHost-v1`:

| Field | Owner-controlled value |
| --- | --- |
| `state_root` | Absolute private directory under the admitted data root |
| `runtime_registry` | Absolute `CVRuntimeRegistry-v1` path |
| `port` | Exact loopback port; defaults to 47631 |
| `preview_profile` | Managed runtime profile, defaults to the first model profile |
| `sources` | Entries containing `id`, `label`, absolute `path`, `input_classification` |
| `models` | Entries containing `id`, `label`, `job_template` |
| `max_upload_bytes` | Optional lower ceiling; maximum 128 MiB |
| `max_queue` | Optional queue ceiling; default 8, maximum 16 |

Each `job_template` contains the closed `CVJob-v2` inference contract's
`schema_version`, `runtime_profile`, `kind`, `adapter`, `device`, verified model
`assets`, fixed `configuration`, and optional resource `limits`. Do not put
`job_id`, `output_root`, `cancel_file` or a media asset in the template. The host
constructs those from opaque browser source/model IDs and owned directories.
Browser requests cannot choose an interpreter, command, filesystem path,
runtime profile, bundle, GPU budget or output root. Valid classification values
are `synthetic`, `public-licensed` and `approved-redacted`; they are declarations.

PDF page selections are sorted, unique and limited to 20 pages. Video analysis
uses every frame of a bounded clip, at most 30 seconds / 900 frames; it never
silently samples. Frame-coverage artifacts distinguish processed, missing and
decoded frames. Video previews use the same clip-selection and orientation
logic as analysis. Overlay coordinates are scaled from each prediction's image
dimensions. Tabular predictions provide an accessible alternative to the
canvas overlay.

Review notes preserve literal comments and acknowledged revisions. Concurrent
tab edits return a conflict instead of overwriting a newer note. Local browser
storage retains unsaved drafts. Browser-submitted authorship remains unverified;
notes and predictions are structurally separate. Accepting a note does not mark
the model prediction as operator-accepted in the runtime result.
Saving any note requires a completed result and verified worker cleanup. Each
note binds to a frozen hash of the runtime result, source, admitted request and
verified artifact list. Changed/missing evidence makes historical notes stale;
the interface never applies them to replacement predictions. Queued, running,
failed and cancelled runs cannot receive decisions.

Exports contain JSON, CSV, an offline HTML review, available figures and verified
artifacts, plus a SHA-256 integrity manifest. Every external text CSV cell gets a
leading apostrophe, including whitespace/control-prefixed formulas; literal
originals remain in JSON.
Extract an export and open `index.html` after stopping the server. Missing source
previews are explicitly stated, never replaced with a fabricated figure.

Verify an archive independently, without the server or optional UI dependencies:

```sh
python -m cv_toolkit.review_server --verify-export /absolute/review.zip
```

Verification rejects extra/duplicate members, traversal, symlinks, oversized
entries, hash mismatches and stale note/result bindings. It verifies artifact
bytes and internal bindings; it does not authenticate an author or establish
source-media rights. Source hashes are retained, while original source bytes
are not embedded in the portable export.

Stop the exact owner without guessing from a port or PID:

```sh
python -m cv_toolkit.review_server --config /absolute/local-review-host.json --stop
```

The server uses an OS-held ownership lease and token-bound stop request. The
Windows launcher additionally passes the expected server instance. Cancellation
is requested first, then verified Linux descendants can be stopped using their
unique inherited token and PID/start identities. Failed/unknown cleanup retains
ownership metadata and artifacts. A restarted server marks unfinished jobs
interrupted and does not claim ownership of historical processes.
Unresolved historical resources block new jobs. Explicit host-only recovery
requires the exclusive inactive-server kernel lease:

```sh
python -m cv_toolkit.review_server --config /absolute/local-review-host.json --recover-owned-resources
```

Recovery matches persisted ownership tokens and process start identities before
stopping tagged descendants. Missing/untrusted launch-window identity remains
an explicit unknown; it is never inferred from a PID or port. Shutdown is bounded
and records unknown cleanup when owned work cannot be verified stopped within
the deadline. Resource identities, results and recovery records are retained.

`Launch-CVReview.ps1` takes `-ConfigLinuxPath`, `-PythonLinuxPath`, and optionally
`-Distro`, `-Port` and a separate unused `-DebugPort` for owned Edge automation.
WSL commands explicitly select user `cyber`. An optional debugging listener binds
to loopback on the generated dedicated profile; no shared browser is attached.
The launcher may invoke only the separate data-volume helper elevated
for mounting. Edge remains ordinary-user and receives a dedicated generated
profile. Elevated launches use an explicitly unowned manual-browser fallback.
`Stop-CVReview.ps1` verifies the recorded Edge process start and profile and stops
the exact server instance; unrelated browser tabs/profiles are preserved.
There is no startup service and no automatic deletion of retained data.
