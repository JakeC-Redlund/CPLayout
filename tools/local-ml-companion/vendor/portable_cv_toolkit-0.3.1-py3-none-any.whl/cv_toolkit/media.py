"""Bounded, lazy media decoding. No remote inputs or implicit frame sampling.

Coordinates describe the displayed pixels. Transforms retain their relationship
to encoded source pixels; PDF pixels remain distinct from document points.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import struct

from .artifacts import artifact_row, atomic_json, json_sha256, sha256_file

VIDEO_OPEN_OPTIONS = {"protocol_whitelist": "file", "format_whitelist": "mov,matroska,avi,gif",
                      "enable_drefs": "0", "use_absolute_path": "0"}
VIDEO_FORMATS = frozenset({"mov", "mp4", "m4a", "3gp", "3g2", "mj2", "matroska", "webm", "avi", "gif"})


def _check_pixels(width, height, maximum):
    if width < 1 or height < 1 or width * height > maximum:
        raise ValueError("media_pixel_limit_exceeded")


def exif_inverse(orientation, width, height):
    """Display-to-source affine in pixel-edge coordinates (not pixel centers)."""
    return {
        1: [[1, 0, 0], [0, 1, 0], [0, 0, 1]],
        2: [[-1, 0, width], [0, 1, 0], [0, 0, 1]],
        3: [[-1, 0, width], [0, -1, height], [0, 0, 1]],
        4: [[1, 0, 0], [0, -1, height], [0, 0, 1]],
        5: [[0, 1, 0], [1, 0, 0], [0, 0, 1]],
        6: [[0, 1, 0], [-1, 0, height], [0, 0, 1]],
        7: [[0, -1, width], [-1, 0, height], [0, 0, 1]],
        8: [[0, -1, width], [1, 0, 0], [0, 0, 1]],
    }[orientation]


def load_image(path, *, max_pixels=16_000_000):
    from PIL import Image, ImageOps
    with Image.open(path) as source:
        if source.format not in {"PNG", "JPEG", "WEBP"}:
            raise ValueError("image_format_not_supported")
        if getattr(source, "n_frames", 1) != 1:
            raise ValueError("animated_image_requires_video_workflow")
        width, height = source.size
        _check_pixels(width, height, max_pixels)
        orientation = source.getexif().get(274, 1)
        if type(orientation) is not int or orientation not in range(1, 9):
            raise ValueError("image_orientation_invalid")
        image = ImageOps.exif_transpose(source).convert("RGB")
        return image, {"width": image.width, "height": image.height,
            "source_dimensions": [width, height], "coordinate_units": "image-pixels",
            "exif_orientation": orientation, "display_to_source": exif_inverse(orientation, width, height)}


def resize_for_model(image, max_side):
    """Bound model pixels without inventing precision in inverse coordinates."""
    from PIL import Image
    scale = min(1.0, max_side / max(image.size))
    size = (max(1, round(image.width * scale)), max(1, round(image.height * scale)))
    resized = image.resize(size, Image.Resampling.BILINEAR) if size != image.size else image
    return resized, {"input_dimensions": list(image.size), "model_dimensions": list(size),
                     "model_to_input_scale": [image.width / size[0], image.height / size[1]]}


def iter_pdf_pages(path, pages, *, dpi=200, max_pixels=16_000_000, check=lambda: None):
    if (not isinstance(pages, list) or not 1 <= len(pages) <= 20 or
            any(type(p) is not int or p < 1 for p in pages) or pages != sorted(set(pages)) or
            type(dpi) not in (int, float) or not 36 <= dpi <= 300):
        raise ValueError("pdf_selection_invalid")
    try:
        import pypdfium2 as pdfium
    except (ImportError, OSError) as error:
        raise ImportError("pdfium_runtime_unavailable") from error
    # All handles are worker-local and serialized. No shared PDFium threads.
    with pdfium.PdfDocument(str(path)) as document:
        if pages[-1] > len(document):
            raise ValueError("pdf_page_out_of_range")
        for number in pages:
            check()
            page = document[number - 1]
            try:
                width, height = page.get_size()
                scale = dpi / 72
                _check_pixels(math.ceil(width * scale), math.ceil(height * scale), max_pixels)
                bitmap = page.render(scale=scale)
                try:
                    image = bitmap.to_pil().convert("RGB")
                    _check_pixels(image.width, image.height, max_pixels)
                finally:
                    bitmap.close()
                yield image, {"page_number": number, "width": image.width, "height": image.height,
                    "page_dimensions_points": [width, height], "dpi": dpi,
                    "coordinate_units": "page-render-pixels", "page_rotation_degrees": page.get_rotation(),
                    "render_pixels_per_point": scale,
                    "limitations": ["page_render_coordinates_not_document_text_positions"]}
            finally:
                page.close()


@dataclass(frozen=True)
class VideoSelection:
    stream_index: int = 0
    start_seconds: float = 0.0
    duration_seconds: float = 10.0
    max_frames: int = 900
    max_width: int = 1920
    max_height: int = 1080

    @classmethod
    def from_config(cls, config):
        if config.get("frame_policy", "every-frame") != "every-frame":
            raise ValueError("video_requires_every_frame")
        value = cls(config.get("stream_index", 0), config.get("clip_start_seconds", 0),
                    config.get("clip_duration_seconds", 10), config.get("max_frames", 900),
                    config.get("max_width", 1920), config.get("max_height", 1080))
        if (type(value.stream_index) is not int or value.stream_index < 0 or
            type(value.start_seconds) not in (int, float) or not math.isfinite(value.start_seconds) or value.start_seconds < 0 or
            type(value.duration_seconds) not in (int, float) or not 0 < value.duration_seconds <= 30 or
            type(value.max_frames) is not int or not 1 <= value.max_frames <= 900 or
            type(value.max_width) is not int or not 1 <= value.max_width <= 1920 or
            type(value.max_height) is not int or not 1 <= value.max_height <= 1080):
            raise ValueError("video_selection_invalid")
        return value


def _rotation(frame, stream):
    for item in getattr(frame, "side_data", ()):
        if "DISPLAYMATRIX" not in str(item.type):
            continue
        try:
            matrix = struct.unpack("=9i", bytes(item))
        except (ValueError, TypeError, struct.error) as error:
            raise ValueError("video_display_matrix_unreadable") from error
        a, b, u, c, d, v, x, y, w = matrix
        # FFmpeg's 16.16 linear terms and 2.30 homogeneous scale. Rotation alone
        # cannot describe reflections, shear, perspective, scale or translation.
        unit = 65536
        if (u or v or x or y or w != 1 << 30 or
                any(term not in {-unit, 0, unit} for term in (a, b, c, d)) or
                a * a + b * b != unit * unit or c * c + d * d != unit * unit or
                a * c + b * d != 0 or a * d - b * c != unit * unit):
            raise ValueError("video_display_matrix_not_pure_orthogonal_rotation")
    rotation = getattr(frame, "rotation", None)
    if rotation is None:
        if any("DISPLAYMATRIX" in str(item.type) for item in getattr(frame, "side_data", ())):
            raise ValueError("video_display_matrix_unreadable")
        rotation = stream.metadata.get("rotate", 0)
    try:
        rotation = float(rotation)
    except (ValueError, TypeError) as error:
        raise ValueError("video_rotation_invalid") from error
    if not math.isfinite(rotation) or rotation % 90:
        raise ValueError("video_rotation_not_orthogonal")
    return int(rotation) % 360


def iter_video_frames(path, selection, *, check=lambda: None, expected_index=None):
    """Sequential decode with at most the current decoded frame and RGB image.

    PTS are source presentation timestamps. Selection is relative to stream start;
    duplicate timestamps preserve separate ordinals. Decoder-internal buffering
    is separate from the application's two-frame limit.
    """
    try:
        import av
    except (ImportError, OSError) as error:
        raise ImportError("pyav_runtime_unavailable") from error
    from PIL import Image
    if not Path(path).is_file():
        raise ValueError("video_local_file_required")
    count, previous, dimensions = 0, None, None
    # Filename suffixes do not constrain FFmpeg probing: a local .mp4 may be a
    # network playlist. Restrict protocols AND demuxers before opening, and
    # keep MOV external data references disabled even for admitted containers.
    with av.open(str(path), mode="r", options=dict(VIDEO_OPEN_OPTIONS)) as container:
        formats = set(container.format.name.split(","))
        if not formats or not formats <= VIDEO_FORMATS:
            raise ValueError("video_container_not_admitted")
        if selection.stream_index >= len(container.streams.video):
            raise ValueError("video_stream_missing")
        stream = container.streams.video[selection.stream_index]
        stream.codec_context.thread_count = 1
        origin = Fraction(stream.start_time or 0) * stream.time_base
        start = origin + Fraction(str(selection.start_seconds))
        end = start + Fraction(str(selection.duration_seconds))
        # Keyframe preroll is bounded; refuse unusually long GOPs rather than
        # silently omitting frames or doing unbounded preselection decoding.
        if selection.start_seconds:
            container.seek(int(start / stream.time_base), backward=True, any_frame=False, stream=stream)
        preroll = 0
        for frame in container.decode(stream):
            check()
            if frame.pts is None or frame.time_base is None:
                raise ValueError("video_timestamp_missing")
            timestamp = Fraction(frame.pts) * frame.time_base
            if previous is not None and timestamp < previous:
                raise ValueError("video_timestamp_backwards")
            previous = timestamp
            if timestamp < start:
                preroll += 1
                if preroll > 900 or start - timestamp > 30:
                    raise ValueError("video_seek_preroll_limit")
                continue
            if timestamp >= end:
                break
            if count >= selection.max_frames:
                raise ValueError("video_frame_limit_exceeded_no_sampling")
            rotation = _rotation(frame, stream)
            encoded_size = (frame.width, frame.height)
            display_size = encoded_size[::-1] if rotation in (90, 270) else encoded_size
            if display_size[0] > selection.max_width or display_size[1] > selection.max_height:
                raise ValueError("video_dimensions_exceeded_no_rescaling")
            if dimensions is not None and display_size != dimensions:
                raise ValueError("video_dimensions_changed")
            dimensions = display_size
            image = frame.to_image().convert("RGB")
            if rotation:
                image = image.transpose({90: Image.Transpose.ROTATE_90, 180: Image.Transpose.ROTATE_180,
                                         270: Image.Transpose.ROTATE_270}[rotation])
            row = {"ordinal": count, "pts": frame.pts,
                   "time_base": [frame.time_base.numerator, frame.time_base.denominator],
                   "timestamp_seconds": float(timestamp), "relative_seconds": float(timestamp - origin),
                   "width": image.width, "height": image.height, "source_dimensions": list(encoded_size),
                   "rotation_degrees_ccw": rotation, "coordinate_units": "display-frame-pixels",
                   "display_to_source": exif_inverse({0: 1, 90: 8, 180: 3, 270: 6}[rotation], *encoded_size),
                   "pixel_sha256": hashlib.sha256(image.tobytes()).hexdigest()}
            if expected_index is not None:
                if count >= len(expected_index) or row != expected_index[count]:
                    raise ValueError("video_frame_identity_changed")
            yield image, row
            count += 1
            del image, frame
    if not count:
        raise ValueError("video_selection_empty")
    if expected_index is not None and count != len(expected_index):
        raise ValueError("video_frame_coverage_incomplete")


def index_video(path, selection, *, check=lambda: None, progress=None):
    frames = []
    for image, row in iter_video_frames(path, selection, check=check):
        frames.append(row)
        if progress is not None:
            progress(len(frames))
        del image
    return {"schema_version": "CVVideoIndex-v1", "source_sha256": sha256_file(Path(path)),
            "selection": selection.__dict__, "frames": frames, "decoded_frames": len(frames),
            "frame_policy": "every-frame", "frame_index_sha256": json_sha256(frames),
            "complete": True, "decoder": "PyAV", "hardware_decode_claimed": False}


class FrameJournal:
    """Append-only bounded predictions; immutable checkpoints identify prefixes."""
    def __init__(self, context, expected_count, *, max_bytes=256 * 1024**2):
        self.context, self.expected_count = context, expected_count
        self.max_bytes, self.bytes, self.count = max_bytes, 0, 0
        self.path = context.output / "predictions.jsonl"
        self.handle = self.path.open("xb")
        self.digest = hashlib.sha256()
        self.closed = False

    def append(self, row):
        self.context.check()
        if row.get("ordinal") != self.count or self.count >= self.expected_count:
            raise ValueError("frame_result_not_contiguous")
        encoded = (json.dumps(row, sort_keys=True, allow_nan=False, separators=(",", ":")) + "\n").encode()
        if self.bytes + len(encoded) > self.max_bytes:
            raise ValueError("frame_result_byte_limit")
        self.handle.write(encoded)
        self.digest.update(encoded)
        self.bytes += len(encoded)
        self.count += 1
        if self.count % 30 == 0:
            self._flush()
            path = atomic_json(self.context.output, f"frame-prefix-{self.count:05d}.json",
                {"schema_version": "CVFramePrefix-v1", "complete": False, "processed_frames": self.count,
                 "prefix_bytes": self.bytes, "prefix_sha256": self.digest.hexdigest()})
            self.context.outputs.append(artifact_row(path, self.context.output, role="frame-prefix"))

    def _flush(self):
        self.handle.flush()
        os.fsync(self.handle.fileno())

    def close(self, *, complete=False):
        if self.closed:
            return
        self._flush()
        self.handle.close()
        self.closed = True
        complete = complete and self.count == self.expected_count
        path = atomic_json(self.context.output, "frame-coverage.json",
            {"schema_version": "CVFrameCoverage-v1", "complete": complete,
             "decoded_frames": self.expected_count, "processed_frames": self.count,
             "missing_frames": self.expected_count - self.count, "prefix_bytes": self.bytes,
             "prefix_sha256": self.digest.hexdigest()})
        self.context.outputs.extend([artifact_row(self.path, self.context.output, role="frame-predictions"),
                                     artifact_row(path, self.context.output, role="frame-coverage")])
