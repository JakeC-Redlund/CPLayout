"""Versioned, portable evidence manifest with independent local byte verification.

Manifest paths are relative to an explicitly supplied artifact root. The manifest
does not retain raw pixels, OCR, prompts, or private absolute source paths.
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any, Mapping
from .artifacts import sha256_file


SCHEMA_VERSION = "CVRunManifest-v1"
_EVIDENCE_CLASSES = {"metadata", "artifact-bytes", "measured-pixels", "human-review", "runtime-proof"}
_SHA256_LENGTH = 64
_DERIVED_VERSIONS = {"RedlundFormLayoutProbe-v2"}
_LEGACY_VERSIONS = {"RedlundFormLayoutProbe-v1"}


class ManifestError(ValueError):
    """Invalid or unverifiable CV run evidence."""


def _sha256_file(path: Path) -> str:
    return sha256_file(path)


def _artifact_path(root: Path, ref: str) -> Path:
    if not isinstance(ref, str) or not ref or Path(ref).is_absolute():
        raise ManifestError("artifact_ref_invalid")
    relative = Path(ref)
    if any(part in (".", "..") for part in relative.parts):
        raise ManifestError("artifact_ref_invalid")
    path = (root / relative).resolve(strict=False)
    if not path.is_relative_to(root):
        raise ManifestError("artifact_ref_outside_root")
    return path


def _check_artifacts(rows: Any, root: Path, label: str, *, allow_empty: bool = False) -> None:
    if not isinstance(rows, list) or (not rows and not allow_empty):
        raise ManifestError(f"{label}_missing")
    refs: set[str] = set()
    for row in rows:
        if not isinstance(row, dict):
            raise ManifestError(f"{label}_invalid")
        ref, digest = row.get("ref"), row.get("sha256")
        if not isinstance(ref, str):
            raise ManifestError(f"{label}_ref_invalid")
        if not isinstance(digest, str) or len(digest) != _SHA256_LENGTH or any(ch not in "0123456789abcdef" for ch in digest):
            raise ManifestError(f"{label}_sha256_invalid")
        if ref in refs:
            raise ManifestError(f"{label}_duplicate_ref")
        refs.add(ref)
        path = _artifact_path(root, ref)
        if not path.is_file():
            raise ManifestError(f"{label}_artifact_missing")
        if _sha256_file(path) != digest:
            raise ManifestError(f"{label}_hash_mismatch")


def _nonempty_string(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def verify_run_manifest(
    manifest: Mapping[str, Any],
    artifact_root: Path,
    *,
    expected_identity: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Validate structure and reopen every declared input/output artifact.

    Returns a verification envelope. Submitted evidence class, observations,
    human review, and runtime assertions remain caller declarations. Only the
    listed local artifact bytes and supplied applicability identity are checked.
    """
    if isinstance(manifest, Mapping) and manifest.get("schema_version") == "CVRunManifest-v2":
        from .manifest_v2 import verify_manifest_v2
        return verify_manifest_v2(manifest, artifact_root, expected_identity=expected_identity)
    if not isinstance(manifest, Mapping) or manifest.get("schema_version") != SCHEMA_VERSION:
        raise ManifestError("manifest_version_invalid")
    root = Path(artifact_root).resolve(strict=False)
    if not root.is_dir():
        raise ManifestError("artifact_root_not_found")
    capture = manifest.get("capture")
    if not isinstance(capture, dict) or not _nonempty_string(capture.get("id")):
        raise ManifestError("capture_identity_missing")
    width, height = capture.get("width"), capture.get("height")
    if type(width) is not int or width <= 0 or type(height) is not int or height <= 0:
        raise ManifestError("capture_dimensions_invalid")
    if not _nonempty_string(capture.get("coordinate_units")):
        raise ManifestError("coordinate_units_missing")
    tool = manifest.get("tool")
    if not isinstance(tool, dict) or any(not _nonempty_string(tool.get(k)) for k in ("name", "version", "configuration_sha256", "build_sha256")):
        raise ManifestError("tool_identity_invalid")
    for key in ("configuration_sha256", "build_sha256"):
        digest = tool[key]
        if len(digest) != 64 or any(ch not in "0123456789abcdef" for ch in digest):
            raise ManifestError("tool_identity_invalid")
    model = manifest.get("model")
    if model is not None:
        if not isinstance(model, dict) or not _nonempty_string(model.get("id")):
            raise ManifestError("model_identity_invalid")
        model_hash = model.get("configuration_sha256")
        if not isinstance(model_hash, str) or len(model_hash) != 64 or any(ch not in "0123456789abcdef" for ch in model_hash):
            raise ManifestError("model_identity_invalid")
    if not isinstance(manifest.get("preprocessing_transforms"), list):
        raise ManifestError("preprocessing_transforms_invalid")
    question_hash = manifest.get("question_catalog_sha256")
    if question_hash is not None and (not isinstance(question_hash, str) or len(question_hash) != 64 or any(ch not in "0123456789abcdef" for ch in question_hash)):
        raise ManifestError("question_catalog_sha256_invalid")
    predecessor_hash = manifest.get("predecessor_sha256")
    if predecessor_hash is not None and (not isinstance(predecessor_hash, str) or len(predecessor_hash) != 64 or any(ch not in "0123456789abcdef" for ch in predecessor_hash)):
        raise ManifestError("predecessor_sha256_invalid")
    declared = manifest.get("declared_input_classification")
    if not _nonempty_string(declared):
        raise ManifestError("input_classification_missing")
    observation = manifest.get("observed_verification")
    if not isinstance(observation, dict) or not _nonempty_string(observation.get("status")):
        raise ManifestError("observed_verification_missing")
    if manifest.get("evidence_class") not in _EVIDENCE_CLASSES:
        raise ManifestError("evidence_class_invalid")
    if not isinstance(manifest.get("measurements"), dict) or not isinstance(manifest.get("failures"), list):
        raise ManifestError("results_invalid")
    if not isinstance(manifest.get("uncertainty"), list) or not isinstance(manifest.get("limitations"), list):
        raise ManifestError("limits_invalid")
    timing = manifest.get("execution_timing_ms")
    if not isinstance(timing, (int, float)) or isinstance(timing, bool) or not math.isfinite(timing) or timing < 0:
        raise ManifestError("timing_invalid")
    _check_artifacts(manifest.get("inputs"), root, "input")
    _check_artifacts(manifest.get("outputs"), root, "output", allow_empty=bool(manifest["failures"]))
    input_paths = {_artifact_path(root, row["ref"]) for row in manifest["inputs"]}
    output_paths = {_artifact_path(root, row["ref"]) for row in manifest["outputs"]}
    if input_paths & output_paths:
        raise ManifestError("output_overwrites_input")
    if expected_identity is not None:
        if not isinstance(expected_identity, Mapping) or not expected_identity:
            raise ManifestError("expected_identity_invalid")
        actual_identity = {
            "capture_id": capture["id"],
            "tool_configuration_sha256": tool["configuration_sha256"],
            "tool_build_sha256": tool["build_sha256"],
            "model_id": model["id"] if model else None,
            "model_configuration_sha256": model["configuration_sha256"] if model else None,
            "question_catalog_sha256": question_hash,
            "preprocessing_transforms": manifest["preprocessing_transforms"],
            "input_sha256_by_ref": {row["ref"]: row["sha256"] for row in manifest["inputs"]},
        }
        unknown = set(expected_identity) - set(actual_identity)
        if unknown:
            raise ManifestError("expected_identity_invalid")
        if any(actual_identity[key] != value for key, value in expected_identity.items()):
            raise ManifestError("manifest_applicability_mismatch")
    # JSON round trip also rejects non-serializable values and returns an
    # independent document, rather than a mutable caller-owned mapping.
    try:
        clean = json.loads(json.dumps(manifest, allow_nan=False))
    except (TypeError, ValueError) as error:
        raise ManifestError("manifest_json_invalid") from error
    return {
        "verification_status": "artifact-bytes-verified",
        "verified_input_count": len(clean["inputs"]),
        "verified_output_count": len(clean["outputs"]),
        "applicability_status": (
            "matched-full-identity" if expected_identity is not None and set(expected_identity) == set(actual_identity)
            else "matched-provided-fields-only" if expected_identity is not None
            else "not-compared"
        ),
        "compared_identity_fields": sorted(expected_identity) if expected_identity is not None else [],
        "submitted_manifest": clean,
        "human_review_verified": False,
        "runtime_verified": False,
    }


def build_run_manifest(
    artifact_root: Path,
    *,
    inputs: list[dict[str, Any]],
    outputs: list[dict[str, Any]],
    capture: dict[str, Any],
    tool: dict[str, Any],
    model: dict[str, Any] | None = None,
    preprocessing_transforms: list[dict[str, Any]] | None = None,
    declared_input_classification: str,
    observed_verification: dict[str, Any],
    measurements: dict[str, Any],
    failures: list[Any],
    uncertainty: list[Any],
    execution_timing_ms: float,
    evidence_class: str,
    limitations: list[str],
    predecessor_sha256: str | None = None,
    question_catalog_sha256: str | None = None,
) -> dict[str, Any]:
    """Build a manifest only when all referenced bytes match their hashes."""
    manifest = {
        "schema_version": SCHEMA_VERSION,
        "inputs": inputs,
        "outputs": outputs,
        "capture": capture,
        "tool": tool,
        "model": model,
        "preprocessing_transforms": preprocessing_transforms if preprocessing_transforms is not None else [],
        "question_catalog_sha256": question_catalog_sha256,
        "declared_input_classification": declared_input_classification,
        "observed_verification": observed_verification,
        "measurements": measurements,
        "failures": failures,
        "uncertainty": uncertainty,
        "execution_timing_ms": execution_timing_ms,
        "evidence_class": evidence_class,
        "limitations": limitations,
        "predecessor_sha256": predecessor_sha256,
    }
    if predecessor_sha256 is not None and (len(predecessor_sha256) != 64 or any(ch not in "0123456789abcdef" for ch in predecessor_sha256)):
        raise ManifestError("predecessor_sha256_invalid")
    return verify_run_manifest(manifest, artifact_root)["submitted_manifest"]


def load_run_manifest(payload: Mapping[str, Any], *, allow_legacy: bool = True) -> dict[str, Any]:
    """Read historical records without silently granting current verification.

    CVRunManifest-v1 still needs verify_run_manifest with local artifact bytes.
    """
    if not isinstance(payload, Mapping):
        raise ManifestError("manifest_invalid")
    version = payload.get("schema_version")
    if version in (SCHEMA_VERSION, "CVRunManifest-v2"):
        return {"status": "unverified-current", "manifest": dict(payload)}
    if isinstance(version, str) and version in _DERIVED_VERSIONS:
        return {"status": "derived-unverified", "manifest": dict(payload)}
    if allow_legacy and isinstance(version, str) and version in _LEGACY_VERSIONS:
        return {"status": "legacy-unverified", "manifest": dict(payload)}
    raise ManifestError("manifest_version_invalid")
