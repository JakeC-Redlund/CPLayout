"""Dependency-free host and browser contracts for the loopback review UI."""
from __future__ import annotations

import json
import math
from pathlib import Path
import re

ID = re.compile(r"[a-z0-9][a-z0-9_-]{0,63}\Z")
CLASSIFICATIONS = {"synthetic", "public-licensed", "approved-redacted"}
MAX_UPLOAD_BYTES = 128 * 1024 * 1024
MAX_JSON_BYTES = 64 * 1024


class ReviewError(ValueError):
    """An invalid local review request, safe to display as an error code."""


def opaque_id(value):
    if not isinstance(value, str) or not ID.fullmatch(value):
        raise ReviewError("invalid_id")
    return value


def text(value, maximum=200, *, empty=False):
    if not isinstance(value, str) or len(value) > maximum or (not empty and not value.strip()):
        raise ReviewError("invalid_text")
    return value


def integer(value, low, high):
    if type(value) is not int or not low <= value <= high:
        raise ReviewError("invalid_integer")
    return value


def number(value, low, high):
    if type(value) not in (int, float) or not math.isfinite(value) or not low <= value <= high:
        raise ReviewError("invalid_number")
    return value


def json_object(data):
    if len(data) > MAX_JSON_BYTES:
        raise ReviewError("json_too_large")
    try:
        value = json.loads(data, parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
    except (ValueError, UnicodeDecodeError) as exc:
        raise ReviewError("invalid_json") from exc
    if not isinstance(value, dict):
        raise ReviewError("json_object_required")
    return value


def exact_fields(value, allowed, required=()):
    if not isinstance(value, dict) or set(value) - set(allowed) or not set(required) <= set(value):
        raise ReviewError("unknown_or_missing_fields")


def host_config(value):
    exact_fields(value, {"schema_version", "state_root", "port", "runtime_registry", "sources", "models",
                         "preview_profile", "max_upload_bytes", "max_queue"},
                 {"schema_version", "state_root", "runtime_registry", "models"})
    if value["schema_version"] != "CVReviewHost-v1":
        raise ReviewError("host_schema_invalid")
    result = dict(value)
    for field in ("state_root", "runtime_registry"):
        if not isinstance(value[field], str) or not Path(value[field]).is_absolute():
            raise ReviewError("host_path_absolute_required")
        result[field] = str(Path(value[field]).resolve())
    result["port"] = integer(value.get("port", 47631), 1024, 65535)
    result["max_upload_bytes"] = integer(value.get("max_upload_bytes", MAX_UPLOAD_BYTES), 1, MAX_UPLOAD_BYTES)
    result["max_queue"] = integer(value.get("max_queue", 8), 1, 16)
    result["sources"], result["models"] = [], []
    for kind in ("sources", "models"):
        rows = value.get(kind, [])
        if not isinstance(rows, list) or len(rows) > 128:
            raise ReviewError("catalog_too_large")
        seen = set()
        for row in rows:
            allowed = {"id", "label", "path", "input_classification"} if kind == "sources" else {"id", "label", "job_template"}
            exact_fields(row, allowed, allowed)
            identifier = opaque_id(row["id"])
            if identifier in seen:
                raise ReviewError("duplicate_catalog_id")
            seen.add(identifier)
            text(row["label"])
            if kind == "sources":
                if not isinstance(row["path"], str) or not Path(row["path"]).is_absolute():
                    raise ReviewError("source_absolute_path_required")
                if row["input_classification"] not in CLASSIFICATIONS:
                    raise ReviewError("classification_invalid")
            else:
                template = row["job_template"]
                if not isinstance(template, dict) or template.get("schema_version") != "CVJob-v2":
                    raise ReviewError("job_template_v2_required")
                if any(key in template for key in ("job_id", "output_root", "cancel_file")):
                    raise ReviewError("host_template_identity_reserved")
                if template.get("kind") != "inference" or template.get("device") not in {"cpu", "cuda"}:
                    raise ReviewError("inference_template_required")
                opaque_id(template.get("runtime_profile"))
                if not isinstance(template.get("assets", []), list):
                    raise ReviewError("template_assets_invalid")
                if any(not isinstance(asset, dict) or asset.get("role") != "model" for asset in template.get("assets", [])):
                    raise ReviewError("template_model_assets_only")
            result[kind].append(dict(row))
    default_profile = result["models"][0]["job_template"]["runtime_profile"] if result["models"] else None
    result["preview_profile"] = opaque_id(value.get("preview_profile", default_profile))
    return result


def run_request(value):
    exact_fields(value, {"source_id", "model_id", "pages", "clip_start_seconds", "clip_duration_seconds", "queries"},
                 {"source_id", "model_id"})
    result = {"source_id": opaque_id(value["source_id"]), "model_id": opaque_id(value["model_id"])}
    if "pages" in value:
        pages = value["pages"]
        if not isinstance(pages, list) or not 1 <= len(pages) <= 20:
            raise ReviewError("pages_invalid")
        for page in pages:
            integer(page, 1, 10000)
        if sorted(set(pages)) != pages:
            raise ReviewError("pages_must_be_sorted_unique")
        result["pages"] = pages
    for key, bounds in {"clip_start_seconds": (0, 86400), "clip_duration_seconds": (.01, 30)}.items():
        if key in value:
            result[key] = number(value[key], *bounds)
    if "queries" in value:
        queries = value["queries"]
        if not isinstance(queries, list) or not 1 <= len(queries) <= 16:
            raise ReviewError("queries_invalid")
        result["queries"] = [{"id": "query-" + str(i + 1), "text": text(item, 200)} for i, item in enumerate(queries)]
    return result


def note_request(value):
    exact_fields(value, {"expected_revision", "decision", "comment", "author_label", "evidence_identity_sha256"},
                 {"expected_revision", "decision", "comment", "evidence_identity_sha256"})
    integer(value["expected_revision"], 0, 100000)
    if value["decision"] not in {"unreviewed", "accept", "revise", "reject", "decline"}:
        raise ReviewError("decision_invalid")
    text(value["comment"], 10000, empty=True)
    text(value.get("author_label", ""), 100, empty=True)
    if not isinstance(value["evidence_identity_sha256"], str) or not re.fullmatch(r"[0-9a-f]{64}", value["evidence_identity_sha256"]):
        raise ReviewError("evidence_identity_required")
    return dict(value)
