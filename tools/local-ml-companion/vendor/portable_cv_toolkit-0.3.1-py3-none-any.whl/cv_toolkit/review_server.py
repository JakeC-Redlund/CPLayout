"""Optional FastAPI loopback review host with a fixed, local-only job API."""
import argparse
import asyncio
from contextlib import asynccontextmanager
import json
import os
from pathlib import Path
import secrets
import socket
import threading
import time
import uuid
from urllib.parse import unquote

from .review_jobs import ReviewStore, write_state
from .review_media import EXTENSIONS
from .review_schema import CLASSIFICATIONS, MAX_JSON_BYTES, ReviewError, host_config, integer, json_object, text

STATIC = Path(__file__).with_name("review_static")


def create_app(config, *, store=None):
    # Optional dependencies never affect base-toolkit importability.
    from fastapi import FastAPI, Request
    from fastapi.responses import FileResponse, JSONResponse
    config = host_config(config)
    store = store or ReviewStore(config)
    csrf_token = secrets.token_urlsafe(32)
    origin = "http://127.0.0.1:" + str(config["port"])

    @asynccontextmanager
    async def lifespan(_app):
        try:
            yield
        finally:
            await asyncio.to_thread(store.close)

    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None, lifespan=lifespan)
    app.state.review_store = store

    @app.middleware("http")
    async def guard(request: Request, call_next):
        if request.headers.get("host") != "127.0.0.1:" + str(config["port"]):
            return JSONResponse({"error": "host_rejected"}, status_code=403)
        supplied_origin = request.headers.get("origin")
        if supplied_origin is not None and supplied_origin != origin:
            return JSONResponse({"error": "origin_rejected"}, status_code=403)
        if request.headers.get("sec-fetch-site") in {"cross-site", "same-site"}:
            return JSONResponse({"error": "cross_site_rejected"}, status_code=403)
        if request.method not in {"GET", "HEAD"}:
            token = request.headers.get("x-cv-csrf", "")
            if supplied_origin != origin or not secrets.compare_digest(token, csrf_token):
                return JSONResponse({"error": "csrf_rejected"}, status_code=403)
        response = await call_next(request)
        response.headers.update({"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff",
            "Referrer-Policy": "no-referrer", "X-Frame-Options": "DENY",
            "Content-Security-Policy": "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"})
        return response

    @app.exception_handler(ReviewError)
    async def review_error(_request, error):
        status = 409 if str(error) in {"revision_conflict", "queue_full", "job_not_finished"} else 400
        return JSONResponse({"error": str(error)}, status_code=status)

    @app.exception_handler(ValueError)
    async def validation_error(_request, _error):
        return JSONResponse({"error": "invalid_local_configuration_or_request"}, status_code=400)

    async def read_json(request):
        if request.headers.get("content-type", "").split(";", 1)[0].strip() != "application/json":
            raise ReviewError("json_content_type_required")
        chunks, count = [], 0
        async for chunk in request.stream():
            count += len(chunk)
            if count > MAX_JSON_BYTES:
                raise ReviewError("json_too_large")
            chunks.append(chunk)
        return json_object(b"".join(chunks))

    @app.get("/")
    async def index():
        return FileResponse(STATIC / "index.html", media_type="text/html")

    @app.get("/app.js")
    async def javascript():
        return FileResponse(STATIC / "app.js", media_type="text/javascript")

    @app.get("/style.css")
    async def styles():
        return FileResponse(STATIC / "style.css", media_type="text/css")

    @app.get("/api/health")
    async def health():
        return {"service": "cv-review", "status": "ready", "version": "CVReviewHost-v1", "instance_id": store.instance_id}

    @app.get("/api/bootstrap")
    async def bootstrap():
        return {"csrf_token": csrf_token, "sources": store.source_catalog(), "models": store.model_catalog(),
                "max_upload_bytes": config["max_upload_bytes"], "jobs": store.list_jobs(),
                "authorship_verified": False, "resource_recovery_required": bool(store.recovery_gaps())}

    @app.get("/api/sources")
    async def sources():
        return {"sources": store.source_catalog()}

    @app.post("/api/uploads")
    async def upload(request: Request):
        if request.headers.get("content-type", "").split(";", 1)[0] != "application/octet-stream":
            raise ReviewError("binary_upload_required")
        # Filename determines only an allowlisted extension, never a destination path.
        label = text(unquote(request.headers.get("x-cv-filename", "upload")))
        extension = Path(label).suffix.lower()
        if extension not in EXTENSIONS:
            raise ReviewError("unsupported_media_extension")
        classification = request.headers.get("x-cv-classification")
        if classification not in CLASSIFICATIONS:
            raise ReviewError("classification_required")
        path = store.root / "uploads" / (uuid.uuid4().hex + extension)
        published = False
        try:
            count = 0
            with path.open("xb") as handle:
                async for chunk in request.stream():
                    count += len(chunk)
                    if count > config["max_upload_bytes"]:
                        raise ReviewError("upload_too_large")
                    handle.write(chunk)
                handle.flush()
                os.fsync(handle.fileno())
            if not count:
                raise ReviewError("empty_upload")
            row = await asyncio.to_thread(store.add_upload, path, label, classification)
            published = True
            return row
        finally:
            if not published:
                path.unlink(missing_ok=True)

    @app.get("/api/sources/{source_id}/metadata")
    async def metadata(source_id: str):
        result, _ = await asyncio.to_thread(store.media, source_id)
        return result

    @app.get("/api/sources/{source_id}/preview/{index}")
    async def preview(source_id: str, index: int):
        integer(index, 0, 9999)
        _, path = await asyncio.to_thread(store.media, source_id, index=index)
        return FileResponse(path, media_type="image/png")

    @app.get("/api/jobs")
    async def jobs():
        return {"jobs": store.list_jobs()}

    @app.post("/api/jobs")
    async def submit(request: Request):
        return await asyncio.to_thread(store.submit, await read_json(request))

    @app.get("/api/jobs/{job_id}")
    async def job(job_id: str):
        return await asyncio.to_thread(store.public_record, store.record(job_id))

    @app.get("/api/jobs/{job_id}/preview/{index}")
    async def job_preview(job_id: str, index: int):
        integer(index, 0, 9999)
        record = store.record(job_id)
        _, path = await asyncio.to_thread(store.media, record["source_id"], index=index, job_id=job_id)
        return FileResponse(path, media_type="image/png")

    @app.post("/api/jobs/{job_id}/cancel")
    async def cancel(job_id: str, request: Request):
        if await read_json(request) != {}:
            raise ReviewError("cancel_body_must_be_empty")
        return store.cancel(job_id)

    @app.post("/api/jobs/{job_id}/notes")
    async def notes(job_id: str, request: Request):
        return await asyncio.to_thread(store.save_note, job_id, await read_json(request))

    @app.get("/api/jobs/{job_id}/artifacts/{artifact_id}")
    async def artifact(job_id: str, artifact_id: str):
        path = await asyncio.to_thread(store.artifact, job_id, artifact_id)
        media = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".json": "application/json"}.get(path.suffix.lower(), "text/plain")
        return FileResponse(path, media_type=media)

    @app.post("/api/jobs/{job_id}/export")
    async def export(job_id: str, request: Request):
        if await read_json(request) != {}:
            raise ReviewError("export_body_must_be_empty")
        path = await asyncio.to_thread(store.export, job_id)
        return FileResponse(path, media_type="application/zip", filename="cv-review-" + job_id + ".zip")

    return app


def load_config(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 1024 * 1024:
        raise ReviewError("host_config_invalid")
    if os.name == "posix" and (path.stat().st_uid != os.getuid() or path.stat().st_mode & 0o022):
        raise ReviewError("host_config_owner_or_permissions_invalid")
    return host_config(json.loads(path.read_text()))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--verify-export", type=Path, help="Verify portable ZIP bytes without starting a server or loading optional dependencies.")
    parser.add_argument("--recover-owned-resources", action="store_true", help="Recover tagged processes only while the server kernel lease is exclusively available.")
    parser.add_argument("--stop", action="store_true", help="Ask the exact owner to stop; never signal a recorded PID.")
    parser.add_argument("--expected-instance", help="Refuse to stop a replacement server instance.")
    args = parser.parse_args(argv)
    if args.verify_export:
        from .review_jobs import verify_export
        print(json.dumps(verify_export(args.verify_export), sort_keys=True))
        return 0
    if args.config is None:
        parser.error("--config is required unless --verify-export is used")
    config = load_config(args.config)
    if args.recover_owned_resources:
        from .review_jobs import recover_owned_resources
        report = recover_owned_resources(config)
        print(json.dumps(report, sort_keys=True))
        return 0 if report["status"] == "verified-stopped" else 2
    root = Path(config["state_root"])
    if args.stop:
        owner = json.loads((root / "server-owner.json").read_text())
        if args.expected_instance and owner.get("instance_id") != args.expected_instance:
            raise ReviewError("server_instance_changed")
        if owner.get("state") != "running":
            print(json.dumps({"cleanup": owner.get("state", "unknown")}))
            return 0 if owner.get("state") == "verified-stopped" else 2
        write_state(root / "stop-request.json", {"token": owner["token"]})
        deadline = time.monotonic() + 55
        while time.monotonic() < deadline:
            current = json.loads((root / "server-owner.json").read_text())
            if current.get("token") != owner["token"]:
                raise ReviewError("server_owner_changed")
            if current.get("state") == "verified-stopped":
                with socket.socket() as check:
                    check.settimeout(.2)
                    released = check.connect_ex(("127.0.0.1", config["port"])) != 0
                print(json.dumps({"cleanup": "verified-stopped" if released else "failed", "listener_released": released}))
                return 0 if released else 2
            time.sleep(.2)
        print(json.dumps({"cleanup": "unknown", "reason": "stop_timeout_metadata_retained"}))
        return 2
    import uvicorn
    from .lease import GPULease
    from .review_jobs import resolve_python
    from .profiles import resolve_runtime
    for profile in {config["preview_profile"], *(row["job_template"]["runtime_profile"] for row in config["models"])}:
        resolve_python(profile, config["runtime_registry"])
    selected = resolve_runtime({"schema_version": "CVJob-v2", "runtime_profile": config["preview_profile"]},
                               registry_path=Path(config["runtime_registry"]))
    if not root.resolve().is_relative_to(Path(selected["data_root"]).resolve()):
        raise ReviewError("review_state_outside_admitted_storage")
    from .storage import StorageUse, validate_storage_path
    with StorageUse(selected["storage_binding"]):
        validate_storage_path(selected["storage_binding"], root)
        root.mkdir(mode=0o700, parents=True, exist_ok=True)
        validate_storage_path(selected["storage_binding"], root)
        with GPULease(root / "server.lease", job_id="review-server") as lease:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                sock.bind(("127.0.0.1", config["port"]))
                sock.listen(64)
                store = ReviewStore(config)
                server = uvicorn.Server(uvicorn.Config(create_app(config, store=store), host="127.0.0.1", port=config["port"],
                                                      access_log=False, log_level="warning"))
                owner = {"schema_version": "CVReviewServerLease-v1", "token": lease.token, "owner": lease.record["owner"],
                         "url": "http://127.0.0.1:" + str(config["port"]) + "/", "state": "running", "instance_id": store.instance_id}
                write_state(root / "server-owner.json", owner)
                monitor_done = threading.Event()

                def monitor():
                    while not monitor_done.wait(.2):
                        request = root / "stop-request.json"
                        try:
                            if request.is_file() and request.stat().st_size < 1024 and json.loads(request.read_text()).get("token") == lease.token:
                                server.should_exit = True
                                return
                        except (OSError, ValueError):
                            continue

                thread = threading.Thread(target=monitor, daemon=True)
                thread.start()
                print(owner["url"], flush=True)
                print(json.dumps({"instance_id": store.instance_id}), flush=True)
                try:
                    server.run(sockets=[sock])
                finally:
                    monitor_done.set()
                    thread.join(timeout=1)
                    cleanup = store.close()
                    sock.close()
                    owner["state"] = cleanup
                    write_state(root / "server-owner.json", owner)
            finally:
                sock.close()
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
