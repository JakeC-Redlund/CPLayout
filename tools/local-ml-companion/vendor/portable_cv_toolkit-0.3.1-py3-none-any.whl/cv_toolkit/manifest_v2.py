"""Multi-asset manifests. Paths are relative to caller-supplied roots, never authority."""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Mapping

from .artifacts import valid_sha256
from .manifest import ManifestError, _artifact_path, _check_artifacts

SCHEMA_VERSION_V2 = "CVRunManifest-v2"


def verify_manifest_v2(manifest: Mapping, artifact_root: Path | Mapping[str, Path], *, expected_identity=None):
    """Reopen every asset. Declarations of runtime/human proof remain unverified."""
    if not isinstance(manifest, Mapping) or manifest.get("schema_version") != SCHEMA_VERSION_V2:
        raise ManifestError("manifest_version_invalid")
    try:
        clean = json.loads(json.dumps(manifest, allow_nan=False))
    except (TypeError, ValueError) as error:
        raise ManifestError("manifest_json_invalid") from error
    supplied = artifact_root if isinstance(artifact_root, Mapping) else {"artifacts": artifact_root}
    roots = {key: Path(path).resolve(strict=True) for key, path in supplied.items()}
    if not roots or any(not p.is_dir() for p in roots.values()):
        raise ManifestError("artifact_root_not_found")
    if not isinstance(clean.get("run_id"), str) or not clean["run_id"]:
        raise ManifestError("run_identity_missing")
    checked, ids, input_paths, output_paths = {}, set(), set(), set()
    for label in ("inputs", "outputs"):
        rows = clean.get(label)
        if not isinstance(rows, list) or (not rows and label == "inputs"):
            raise ManifestError(label + "_missing")
        for row in rows:
            if not isinstance(row, dict) or not isinstance(row.get("id"), str) or not row["id"] or row["id"] in ids:
                raise ManifestError("asset_identity_invalid")
            ids.add(row["id"])
            root = roots.get(row.get("root_id", "artifacts"))
            if root is None:
                raise ManifestError("asset_root_unknown")
            _check_artifacts([row], root, label)
            path = _artifact_path(root, row["ref"])
            (input_paths if label == "inputs" else output_paths).add(path)
            if label == "inputs":
                dimensions = row.get("dimensions")
                if dimensions is not None and (not isinstance(dimensions, list) or not dimensions or
                        any(type(n) is not int or n <= 0 for n in dimensions)):
                    raise ManifestError("asset_dimensions_invalid")
                if dimensions and not isinstance(row.get("coordinate_units"), str):
                    raise ManifestError("asset_coordinate_units_missing")
                checked[row["id"]] = row["sha256"]
    if input_paths & output_paths or any(a.samefile(b) for a in input_paths for b in output_paths):
        raise ManifestError("output_overwrites_input")
    tool = clean.get("tool")
    if not isinstance(tool, dict) or any(not isinstance(tool.get(key), str) or not tool[key] for key in ("name", "version")) or any(
            not valid_sha256(tool.get(key)) for key in ("build_sha256", "configuration_sha256")):
        raise ManifestError("tool_identity_invalid")
    model = clean.get("model")
    if model is not None:
        if not isinstance(model, dict) or any(not isinstance(model.get(key), str) or not model[key] for key in ("id", "revision")) or any(
                not valid_sha256(model.get(key)) for key in ("weights_sha256", "configuration_sha256")):
            raise ManifestError("model_identity_invalid")
        if model["weights_sha256"] not in checked.values():
            raise ManifestError("model_weights_not_verified_input")
    dataset = clean.get("dataset")
    if dataset is not None:
        if not isinstance(dataset, dict) or any(not valid_sha256(dataset.get(key)) for key in ("manifest_sha256", "split_sha256")):
            raise ManifestError("dataset_identity_invalid")
        if any(dataset[key] not in checked.values() for key in ("manifest_sha256", "split_sha256")):
            raise ManifestError("dataset_identity_not_verified_input")
    if not isinstance(clean.get("runtime"), dict) or not clean["runtime"]:
        raise ManifestError("runtime_identity_invalid")
    for key in ("preprocessing_transforms", "failures", "uncertainty", "limitations"):
        if not isinstance(clean.get(key), list):
            raise ManifestError(key + "_invalid")
    if not isinstance(clean.get("measurements"), dict) or not isinstance(clean.get("observed_verification"), dict):
        raise ManifestError("results_invalid")
    if not isinstance(clean.get("declared_input_classification"), str) or not clean["declared_input_classification"]:
        raise ManifestError("input_classification_missing")
    if clean.get("evidence_class") not in {"metadata", "artifact-bytes", "measured-pixels", "human-review", "runtime-proof"}:
        raise ManifestError("evidence_class_invalid")
    for key in ("predecessor_sha256", "question_catalog_sha256", "capture_fingerprint_sha256"):
        if clean.get(key) is not None and not valid_sha256(clean[key]):
            raise ManifestError(key + "_invalid")
    timing = clean.get("execution_timing_ms")
    if type(timing) not in (int, float) or not math.isfinite(timing) or timing < 0:
        raise ManifestError("timing_invalid")
    if not clean["outputs"] and not clean["failures"]:
        raise ManifestError("output_missing")
    identity = {"input_sha256_by_id": checked, "tool_build_sha256": tool["build_sha256"],
                "tool_configuration_sha256": tool["configuration_sha256"], "model": model,
                "dataset": dataset, "runtime": clean["runtime"],
                "preprocessing_transforms": clean["preprocessing_transforms"],
                "question_catalog_sha256": clean.get("question_catalog_sha256"),
                "capture_fingerprint_sha256": clean.get("capture_fingerprint_sha256")}
    if expected_identity is not None:
        if not isinstance(expected_identity, Mapping) or not expected_identity or set(expected_identity) - set(identity):
            raise ManifestError("expected_identity_invalid")
        if any(identity[key] != value for key, value in expected_identity.items()):
            raise ManifestError("manifest_applicability_mismatch")
    return {"verification_status": "artifact-bytes-verified", "verified_input_count": len(clean["inputs"]),
            "verified_output_count": len(clean["outputs"]), "submitted_manifest": clean,
            "applicability_status": "matched-full-identity" if expected_identity is not None and set(expected_identity) == set(identity)
                else "matched-provided-fields-only" if expected_identity is not None else "not-compared",
            "compared_identity_fields": sorted(expected_identity) if expected_identity is not None else [],
            "human_review_verified": False, "runtime_verified": False}
