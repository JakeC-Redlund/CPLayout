"""Offline managed CV worker: `python -m cv_toolkit.runtime probe|run JOB.json`.

The supervisor owns its child process handle and kernel GPU lease. Browser pages
do not receive this API, shell access, or control credentials. The runtime does
not constitute an OS network sandbox; adapters use explicit local assets only.
"""
from __future__ import annotations

import argparse
from contextlib import ExitStack, nullcontext
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time
import uuid

from .artifacts import artifact_row, atomic_json, json_sha256, sha256_file, valid_sha256
from .jobs import DEFAULT_LIMITS, PROFILE, JobError, validate_job, source_identity
from .lease import GPULease, LeaseBusy, validate_inherited_lease
from .paths import safe_output_path
from .bundles import staged_asset_path
from .profiles import resolve_runtime, validate_job_storage, validate_runtime_path, runtime_environment, ProfileError, V2_PROFILE
from .telemetry import gpu_snapshot, is_wsl, memory_snapshot
from .storage import StorageUse, StorageUnavailable


class StopJob(RuntimeError):
    pass


def probe() -> dict:
    """Metadata visibility only: deliberately does not import torch or models."""
    packages = {}
    for name in ("torch", "torchvision", "SAM-2", "numpy", "Pillow", "onnxruntime-gpu",
                 "transformers", "trackers", "supervision", "opencv-python", "av", "pypdfium2", "fastapi", "uvicorn"):
        try:
            packages[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
    try:
        selection = resolve_runtime({"schema_version": "CVJob-v2", "runtime_profile": V2_PROFILE})
        registry = {"status": "admitted", "profile": V2_PROFILE, "registry_sha256": selection["registry_sha256"],
                    "storage_status": selection["storage_status"], "execution_tested": False}
    except (OSError, ValueError) as error:
        registry = {"status": "readiness-gap", "profile": V2_PROFILE, "reason": str(error), "execution_tested": False}
    return {"schema_version": "CVCapabilityReport-v1", "python": platform.python_version(),
            "platform": platform.platform(), "packages_visible": packages, "expected_profile": PROFILE,
            "gpu_metadata": gpu_snapshot(), "memory": memory_snapshot(), "model_import_tested": False,
            "model_runtime_tested": False, "quality_evaluated": False, "default_limits": DEFAULT_LIMITS,
            "v2_runtime_registry": registry,
            "limitations": ["metadata_visibility_does_not_prove_import_or_inference",
                            "gpu_lease_coordinates_managed_jobs_in_this_operating_system_only"]}


def admission(job: dict, *, memory=None, gpu=None) -> list[str]:
    limits = job["limits"]
    memory = memory_snapshot() if memory is None else memory
    gaps = []
    for key in (["available_bytes", "windows_available_bytes"] if is_wsl() else ["available_bytes"]):
        available = memory.get(key)
        if available is None:
            gaps.append(key + "_unknown")
        elif available < limits["available_ram_bytes"]:
            gaps.append(key + "_below_reserve")
    if job["device"] == "cuda":
        gpu = gpu_snapshot() if gpu is None else gpu
        devices = gpu.get("devices", [])
        if gpu.get("status") != "observed" or not devices or devices[0].get("index") != 0 or not devices[0].get("uuid"):
            gaps.append("gpu_0_telemetry_unknown")
        elif devices[0]["free_bytes"] < limits["gpu_budget_bytes"] + limits["gpu_reserve_bytes"]:
            gaps.append("gpu_free_below_budget_plus_reserve")
    return gaps


class ExecutionContext:
    def __init__(self, job, output, *, memory_reader=memory_snapshot):
        self.job, self.output = job, Path(output)
        self.protected = [Path(asset["path"]) for asset in job["assets"]]
        self.started = time.monotonic()
        self.memory_reader = memory_reader
        self.last_host_check = 0.0
        self.host_memory = None
        self.torch, self.device = None, None
        self.outputs, self.stages, self.timings = [], [], {}
        self.runtime_identity = {}
        self.stop_reason = None
        self.assets_verified = False

    def stage(self, name, device, **evidence):
        record = {"stage": name, "observed_device": device, **evidence}
        previous = next((i for i, row in enumerate(self.stages) if row["stage"] == name), None)
        if previous is None:
            self.stages.append(record)
        else:
            self.stages[previous] = record

    def check(self):
        if self.stop_reason:
            raise StopJob(self.stop_reason)
        if (self.output / ".cancel-requested").exists() or (self.job.get("cancel_file") and Path(self.job["cancel_file"]).exists()):
            raise StopJob("cancelled")
        if time.monotonic() - self.started >= self.job["limits"]["deadline_seconds"]:
            raise StopJob("deadline_exceeded")
        check_host = time.monotonic() - self.last_host_check >= 10
        memory = self.memory_reader(host=check_host)
        if check_host:
            self.host_memory, self.last_host_check = memory.get("windows_available_bytes"), time.monotonic()
        if memory.get("rss_bytes") is None:
            raise StopJob("worker_rss_unknown")
        if memory["rss_bytes"] > self.job["limits"]["rss_budget_bytes"]:
            raise StopJob("worker_rss_budget_exceeded")
        if memory.get("available_bytes") is None or memory["available_bytes"] < self.job["limits"]["available_ram_bytes"]:
            raise StopJob("available_ram_unknown_or_below_reserve")
        if is_wsl() and (self.host_memory is None or self.host_memory < self.job["limits"]["available_ram_bytes"]):
            raise StopJob("windows_ram_unknown_or_below_reserve")
        if self.torch is not None:
            free, _ = self.torch.cuda.mem_get_info(self.device)
            reserved = self.torch.cuda.memory_reserved(self.device)
            if free < self.job["limits"]["gpu_reserve_bytes"] or reserved > self.job["limits"]["gpu_budget_bytes"]:
                raise StopJob("gpu_memory_budget_or_reserve_exceeded")


def execute_inprocess(job: dict, output: Path, *, adapter=None, context_factory=ExecutionContext) -> dict:
    """Worker/test seam; production callers must use run_job for lease/isolation."""
    from .adapters import ADAPTERS, ReadinessGap
    context = context_factory(job, output)
    result = {"schema_version": "CVJobResult-v1", "job_id": job["job_id"], "status": "failed",
              "job_sha256": json_sha256(job), "declared_input_classification": job["input_classification"],
              "asset_sha256_by_id": {row["id"]: row["sha256"] for row in job["assets"]},
              "artifact_bytes_verified": False, "runtime_tested": False, "quality_evaluated": False,
              "operator_accepted": False, "measurements": {}, "failures": [], "limitations": []}
    result["source_identity"] = source_identity()
    start = time.perf_counter()
    try:
        context.check()
        if adapter is None and job["schema_version"] == "CVJob-v2":
            try:
                from .vision_adapters import ADAPTERS as VISION_ADAPTERS
            except ImportError as error:
                raise ReadinessGap("vision_adapter_package_unavailable") from error
            adapter = VISION_ADAPTERS.get(job["adapter"])
            if adapter is None:
                raise ReadinessGap("vision_adapter_unavailable")
        result["measurements"] = (adapter or ADAPTERS[job["adapter"]])(job, context)
        result["status"] = "checkpointed" if context.stop_reason else "completed"
        result["runtime_tested"] = bool(context.stages)
    except ReadinessGap as error:
        result.update(status="readiness-gap", failures=[str(error)])
    except StopJob as error:
        result.update(status="cancelled" if "cancel" in str(error) else "stopped", failures=[str(error)])
    except Exception as error:
        import traceback
        traceback.print_exc(file=sys.stderr)  # supervisor-owned private worker.log
        # Avoid retaining package tracebacks, paths, raw input or arbitrary error bodies.
        result["failures"] = ["adapter_failed:" + type(error).__name__]
        result["failure_code"] = str(error) if isinstance(error, ValueError) and len(str(error)) < 100 else None
    finally:
        result["stage_observations"] = context.stages
        result["partial_runtime_observed"] = bool(context.stages)
        result["runtime_identity"] = context.runtime_identity
        result["artifact_bytes_verified"] = context.assets_verified
        result["outputs"] = context.outputs
        context.timings["worker_end_to_end_ms"] = (time.perf_counter() - start) * 1000
        result["timings"] = context.timings
        result["memory"] = context.memory_reader(host=False)
        if context.torch is not None:
            result["gpu_memory"] = {"peak_allocated_bytes": context.torch.cuda.max_memory_allocated(context.device),
                                    "peak_reserved_bytes": context.torch.cuda.max_memory_reserved(context.device)}
        result["limitations"] = ["resource_checks_are_cooperative_between_model_stages",
                                 "supervisor_deadline_can_interrupt_before_latest_checkpoint",
                                 "no_network_sandbox_claim"]
    atomic_json(output, "worker-result.json", result)
    return result


def _stop_child(child):
    """Only the Popen child created by this invocation is signalled."""
    child.terminate()
    try:
        child.wait(timeout=5)
    except subprocess.TimeoutExpired:
        child.kill()
        child.wait(timeout=10)


def _process_start(pid: int) -> str | None:
    try:
        return Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()[19]
    except (OSError, IndexError):
        return None


def _group_members(group_id: int) -> dict[int, str]:
    members = {}
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            fields = (entry / "stat").read_text().rsplit(")", 1)[1].split()
            if fields[0] != "Z" and int(fields[2]) == group_id and int(fields[3]) == group_id:
                members[int(entry.name)] = fields[19]
        except (OSError, ValueError, IndexError):
            continue
    return members


def _observe_group(child, identities):
    current = _group_members(child.pid)
    if any(identities.get(pid) == start for pid, start in current.items()):
        identities.update(current)
    return current


def stop_owned_group(child, identities: dict[int, str], *, term_grace=3, kill_grace=5) -> str:
    """Signal only this invocation's isolated session with a live identity anchor."""
    for sig, grace in ((signal.SIGTERM, term_grace), (signal.SIGKILL, kill_grace)):
        current = _group_members(child.pid)
        if not current:
            child.poll()
            return "verified-stopped"
        if not any(identities.get(pid) == start for pid, start in current.items()):
            return "unknown"
        identities.update(current)
        try:
            os.killpg(child.pid, sig)
        except ProcessLookupError:
            pass
        deadline = time.monotonic() + grace
        while time.monotonic() < deadline:
            child.poll()
            current = _observe_group(child, identities)
            if not current:
                return "verified-stopped"
            time.sleep(.05)
    return "failed"


def install_parent_death_signal(parent_pid: int) -> None:
    """Arm Linux parent-death termination before importing a model or CUDA."""
    if sys.platform != "linux":
        raise JobError("worker_parent_death_handling_unqualified")
    import ctypes
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(1, signal.SIGTERM, 0, 0, 0) != 0:  # PR_SET_PDEATHSIG
        raise JobError("worker_parent_death_signal_failed")
    # Close the race between parent death and prctl installation. GPU setup has
    # not started. Inherited lease remains held until this process exits.
    if os.getppid() != parent_pid:
        raise JobError("managed_worker_parent_gone")


def verify_result_artifacts(job: dict, result: dict, output: Path) -> dict:
    """Supervisor reopens immutable staged inputs and every worker output."""
    if result.get("schema_version") != "CVJobResult-v1" or result.get("job_sha256") != json_sha256(job):
        raise ValueError("worker_result_identity_mismatch")
    if result.get("source_identity") != source_identity():
        raise ValueError("worker_source_identity_changed")
    sources = []
    for asset in job["assets"]:
        staged = staged_asset_path(output, asset)
        if not staged.is_file() or sha256_file(staged) != asset["sha256"]:
            raise ValueError("staged_input_missing_or_hash_mismatch")
        sources.append(staged)
    refs = set()
    rows = result.get("outputs")
    if not isinstance(rows, list) or not rows:
        raise ValueError("worker_outputs_missing")
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("ref"), str) or row["ref"] in refs or not valid_sha256(row.get("sha256")):
            raise ValueError("worker_output_identity_invalid")
        refs.add(row["ref"])
        path = safe_output_path(output, Path(row["ref"]), sources)
        if not path.is_file() or path.stat().st_size != row.get("bytes") or sha256_file(path) != row["sha256"]:
            raise ValueError("worker_output_missing_or_hash_mismatch")
    return {"status": "artifact-bytes-verified", "input_count": len(sources), "output_count": len(rows),
            "runtime_claim_independently_verified": False}


def run_job(value: dict, *, lease_path: Path | None = None) -> dict:
    # The stack encloses every worker and final artifact write, including all
    # exception paths. Its directory FD makes the active volume visible to fuser.
    with ExitStack() as storage_stack:
        return _run_job(value, lease_path=lease_path, storage_stack=storage_stack)


def _run_job(value: dict, *, lease_path, storage_stack) -> dict:
    started = time.perf_counter()
    # Structural checks read no model bytes. V2 storage must be admitted before
    # reading its large assets or creating anything under its mount point.
    job = validate_job(value, verify_assets=False)
    output = Path(job["output_root"]) / job["job_id"]
    base = {"schema_version": "CVJobResult-v1", "job_id": job["job_id"], "job_sha256": json_sha256(job),
            "runtime_tested": False, "quality_evaluated": False, "operator_accepted": False,
            "stage_observations": [], "outputs": [], "failures": [], "output_directory": str(output)}
    cleanup = "not-started"
    result = base
    child = None
    identities = {}
    lease = None
    output_created = False
    storage_use = None
    try:
        selected_runtime = resolve_runtime(job)
        validate_job_storage(job, selected_runtime)
        if "storage_binding" in selected_runtime:
            storage_use = storage_stack.enter_context(StorageUse(selected_runtime["storage_binding"]))
        job = validate_job(job)
        if sys.platform != "linux":
            raise ProfileError("worker_process_tree_cleanup_unqualified")
        output.mkdir(mode=0o700)
        validate_runtime_path(selected_runtime, output)
        output_created = True
        atomic_json(output, "job.json", job)
        with GPULease(lease_path, job_id=job["job_id"]) if job["device"] == "cuda" else nullcontext() as lease:
            gaps = admission(job)
            if gaps:
                result = {**base, "status": "readiness-gap", "failures": gaps}
            else:
                environment = runtime_environment(selected_runtime, os.environ)
                # Mount topology can change after the first admission. Do not
                # launch a worker that would stage bytes on a foreign volume.
                validate_runtime_path(selected_runtime, output)
                if job["schema_version"] == "CVJob-v2":
                    environment.pop("PYTHONPATH", None)
                    environment.pop("PYTHONHOME", None)
                environment.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_HUB_DISABLE_TELEMETRY="1",
                    OMP_NUM_THREADS=str(job["limits"]["cpu_threads"]), CUBLAS_WORKSPACE_CONFIG=":4096:8",
                    CUDA_VISIBLE_DEVICES="0")
                worker_token = uuid.uuid4().hex
                environment.update(CV_TOOLKIT_WORKER_TOKEN=worker_token, CV_TOOLKIT_PARENT_PID=str(os.getpid()))
                descriptors = (storage_use.fileno(),) if storage_use is not None else ()
                if lease is not None:
                    lease_descriptor = lease.worker_fd()
                    descriptors += (lease_descriptor,)
                    environment.update(CV_TOOLKIT_GPU_LEASE_FD=str(lease_descriptor), CV_TOOLKIT_GPU_LEASE_TOKEN=lease.token)
                else:
                    environment.pop("CV_TOOLKIT_GPU_LEASE_FD", None)
                    environment.pop("CV_TOOLKIT_GPU_LEASE_TOKEN", None)
                atomic_json(output, ".worker-owner.json", {"token": worker_token, "parent_pid": os.getpid()})
                # stdout/stderr stay in the owned run, never governance or browser.
                with (output / "worker.log").open("xb") as log:
                    child = subprocess.Popen([selected_runtime["python"], "-m", "cv_toolkit.runtime", "_worker", str(output / "job.json")],
                        env=environment, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                        start_new_session=True, pass_fds=descriptors)
                    start_identity = _process_start(child.pid)
                    if start_identity is not None:
                        identities[child.pid] = start_identity
                    worker_started = time.monotonic()
                    cancel_started, reason = None, None
                    try:
                        while True:
                            _observe_group(child, identities)
                            if child.poll() is not None:
                                break
                            now = time.monotonic()
                            cancelled = job.get("cancel_file") and Path(job["cancel_file"]).exists()
                            expired = now - worker_started >= job["limits"]["deadline_seconds"]
                            if (cancelled or expired) and cancel_started is None:
                                reason = "cancelled" if cancelled else "deadline_exceeded"
                                cancel_started = now
                                atomic_json(output, ".cancel-requested", {"reason": reason})
                            if cancel_started is not None and now - cancel_started >= job["limits"]["cancel_grace_seconds"]:
                                cleanup = stop_owned_group(child, identities)
                                break
                            time.sleep(0.1)
                    except BaseException:
                        cleanup = stop_owned_group(child, identities)
                        if lease is not None and cleanup != "verified-stopped":
                            lease.retain_on_exit = True
                        raise
                    cleanup = stop_owned_group(child, identities)
                    if lease is not None and cleanup != "verified-stopped":
                        lease.retain_on_exit = True
                worker_result = output / "worker-result.json"
                if worker_result.is_file():
                    result = json.loads(worker_result.read_text())
                    if (not isinstance(result, dict) or not isinstance(result.get("status"), str)
                            or not isinstance(result.get("failures"), list)
                            or any(not isinstance(item, str) for item in result["failures"])):
                        raise ValueError("worker_result_shape_invalid")
                    result["output_directory"] = str(output)
                    if result.get("status") in {"completed", "checkpointed"}:
                        try:
                            result["final_artifact_verification"] = verify_result_artifacts(job, result, output)
                        except (OSError, ValueError) as error:
                            result.update(status="failed", artifact_bytes_verified=False)
                            result["failures"].append(str(error))
                    if reason:
                        result["status"] = "cancelled" if reason == "cancelled" else "stopped"
                        result["failures"].append(reason)
                    if cleanup != "verified-stopped" or (child.returncode != 0 and result.get("status") in {"completed", "checkpointed"}):
                        result.update(status="failed")
                        result["failures"].append("worker_exit_or_cleanup_not_verified")
                else:
                    result = {**base, "status": "cancelled" if reason == "cancelled" else "failed",
                              "failures": [reason or "worker_exited_without_result"], "worker_exit_code": child.returncode}
    except (LeaseBusy, ProfileError, StorageUnavailable) as error:
        result = {**base, "status": "readiness-gap", "failures": [str(error)]}
    except JobError as error:
        result = {**base, "status": "failed", "failures": [str(error)]}
    except (OSError, ValueError) as error:
        result = {**base, "status": "failed", "failures": ["supervisor_failed:" + type(error).__name__]}
    finally:
        if child is not None and child.poll() is None:
            cleanup = stop_owned_group(child, identities)
    result["cleanup"] = cleanup
    if "selected_runtime" in locals():
        result["runtime_selection"] = selected_runtime
    result["supervisor_end_to_end_ms"] = (time.perf_counter() - started) * 1000
    if output_created:
        try:
            validate_runtime_path(selected_runtime, output)
        except ProfileError as error:
            result.update(status="readiness-gap", failures=result.get("failures", []) + [str(error)])
            output_created = False
    result["result_path"] = str(output / "result.json") if output_created else None
    if output_created:
        atomic_json(output, "result.json", result)
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("probe", "run", "_worker"))
    parser.add_argument("job", type=Path, nargs="?")
    args = parser.parse_args(argv)
    try:
        if args.command == "probe":
            result = probe()
        else:
            if args.command == "_worker":
                try:
                    parent_pid = int(os.environ.get("CV_TOOLKIT_PARENT_PID", "0"))
                except ValueError as error:
                    raise JobError("managed_worker_parent_required") from error
                if parent_pid <= 0:
                    raise JobError("managed_worker_parent_required")
                install_parent_death_signal(parent_pid)
            if args.job is None or args.job.stat().st_size > 1024 * 1024:
                raise JobError("job_file_missing_or_oversized")
            job = json.loads(args.job.read_text(encoding="utf-8"))
            if args.command == "_worker":
                job = validate_job(job, output_may_exist=True)
                output = Path(job["output_root"]) / job["job_id"]
                owner = json.loads((output / ".worker-owner.json").read_text())
                if owner.get("token") != os.environ.get("CV_TOOLKIT_WORKER_TOKEN") or str(owner.get("parent_pid")) != os.environ.get("CV_TOOLKIT_PARENT_PID") or owner.get("parent_pid") != os.getppid():
                    raise JobError("managed_worker_parent_required")
                if job["device"] == "cuda":
                    try:
                        descriptor = int(os.environ.get("CV_TOOLKIT_GPU_LEASE_FD", "-1"))
                        validate_inherited_lease(descriptor, os.environ.get("CV_TOOLKIT_GPU_LEASE_TOKEN", ""))
                    except (OSError, ValueError, LeaseBusy) as error:
                        raise JobError("managed_worker_inherited_lease_required") from error
                result = execute_inprocess(job, output)
            else:
                result = run_job(job)
        print(json.dumps(result, sort_keys=True, allow_nan=False))
        return 0 if result.get("status", "completed") in {"completed", "checkpointed"} else 2
    except (OSError, ValueError) as error:
        print(json.dumps({"schema_version": "CVJobResult-v1", "status": "invalid",
                          "failures": [str(error)]}, sort_keys=True))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
