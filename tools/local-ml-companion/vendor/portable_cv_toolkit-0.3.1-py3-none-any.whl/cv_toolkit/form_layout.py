#!/usr/bin/env python3
"""Measure synthetic or approved-redacted browser form captures without retaining OCR text."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import statistics
import sys
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from .paths import OutputPathError, safe_output_path


SCHEMA_VERSION = "RedlundFormLayoutProbe-v2"
SCENARIO_ID = re.compile(r"^[a-z][a-z0-9_-]{2,119}$", re.ASCII)
CAPTURE_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$", re.ASCII)


class ProbeError(ValueError):
    """Fail-closed error for malformed or incomplete capture evidence."""


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--capture-root",
        action="append",
        required=True,
        type=Path,
        help="Ignored child-local directory containing *-form.png and dom-geometry.json.",
    )
    parser.add_argument(
        "--input-class",
        choices=("synthetic", "approved-redacted"),
        required=True,
        help="Authority classification asserted by the operator for every supplied capture.",
    )
    parser.add_argument("--output", type=Path, help="Relative derived JSON filename inside --output-root.")
    parser.add_argument("--output-root", type=Path, help="Existing product-owned directory for derived output.")
    parser.add_argument("--skip-ocr", action="store_true", help="Run DOM and OpenCV measurements only.")
    parser.add_argument("--psm", default=6, type=int, help="Tesseract page segmentation mode.")
    return parser.parse_args(argv)


def image_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def finite_number(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def cluster_rows(values: list[float], tolerance: float = 8.0) -> list[list[float]]:
    rows: list[list[float]] = []
    for value in sorted(values):
        if not rows or abs(value - statistics.median(rows[-1])) > tolerance:
            rows.append([value])
        else:
            rows[-1].append(value)
    return rows


def load_dom_measurements(root: Path) -> dict[tuple[str, int, int], dict[str, Any]]:
    path = root / "dom-geometry.json"
    if not path.is_file():
        raise ProbeError("dom_geometry_not_found")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as error:
        raise ProbeError("dom_geometry_json_invalid") from error
    if not isinstance(payload, dict) or not isinstance(payload.get("measurements"), list):
        raise ProbeError("dom_geometry_json_invalid")
    measurements = payload["measurements"]
    result: dict[tuple[str, int, int], dict[str, Any]] = {}
    for row in measurements:
        if not isinstance(row, dict):
            raise ProbeError("dom_geometry_row_invalid")
        scenario = row.get("scenario")
        width = row.get("width")
        height = row.get("height")
        geometry = row.get("geometry")
        capture_id = row.get("captureId")
        image_hash = row.get("imageSha256")
        if (
            not isinstance(scenario, str)
            or SCENARIO_ID.fullmatch(scenario) is None
            or type(width) is not int
            or width <= 0
            or type(height) is not int
            or height <= 0
            or not isinstance(geometry, dict)
            or not isinstance(capture_id, str)
            or CAPTURE_ID.fullmatch(capture_id) is None
            or not isinstance(image_hash, str)
            or re.fullmatch(r"[0-9a-f]{64}", image_hash) is None
        ):
            raise ProbeError("dom_geometry_row_invalid")
        identity = (scenario, width, height)
        if identity in result:
            raise ProbeError("dom_geometry_duplicate_identity")
        result[identity] = row
    return result


def parse_image_identity(path: Path) -> tuple[str, int, int]:
    if not path.name.endswith("-form.png"):
        raise ProbeError("capture_filename_contract_invalid")
    stem = path.name.removesuffix("-form.png")
    scenario, separator, dimensions = stem.rpartition("-")
    width_text, dimension_separator, height_text = dimensions.partition("x")
    try:
        width = int(width_text)
        height = int(height_text)
    except ValueError as error:
        raise ProbeError("capture_filename_contract_invalid") from error
    if (
        not separator
        or not dimension_separator
        or SCENARIO_ID.fullmatch(scenario) is None
        or width <= 0
        or height <= 0
    ):
        raise ProbeError("capture_filename_contract_invalid")
    return scenario, width, height


def _finite_nonnegative(value: Any, *, positive: bool = False) -> float:
    if type(value) not in (int, float):
        raise ProbeError("dom_geometry_incomplete")
    number = finite_number(value)
    if number is None or number < 0 or (positive and number == 0):
        raise ProbeError("dom_geometry_incomplete")
    return number


def _count(geometry: dict[str, Any], key: str) -> int:
    value = geometry.get(key)
    if type(value) is not int or value < 0:
        raise ProbeError("dom_geometry_incomplete")
    return value


def dom_summary(geometry: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(geometry, dict):
        raise ProbeError("dom_geometry_incomplete")
    controls = geometry.get("controls")
    labels = geometry.get("labels")
    if not isinstance(controls, list) or not controls or not isinstance(labels, list):
        raise ProbeError("dom_geometry_incomplete")
    counts = {key: _count(geometry, key) for key in (
        "controlCount", "disabledControlCount", "fieldsetCount", "labelCount",
        "legendCount", "requiredControlCount", "unlabelledFieldControlCount",
    )}
    if counts["controlCount"] != len(controls) or counts["labelCount"] != len(labels):
        raise ProbeError("dom_geometry_count_mismatch")
    if any(counts[key] > len(controls) for key in ("disabledControlCount", "requiredControlCount", "unlabelledFieldControlCount")):
        raise ProbeError("dom_geometry_count_mismatch")
    form_width = _finite_nonnegative(geometry.get("formWidth"), positive=True)
    form_height = _finite_nonnegative(geometry.get("formHeight"), positive=True)
    overflow = _finite_nonnegative(geometry.get("horizontalOverflowPx"))
    for row in controls:
        if not isinstance(row, dict):
            raise ProbeError("dom_geometry_incomplete")
        _finite_nonnegative(row.get("height"), positive=True)
        _finite_nonnegative(row.get("width"), positive=True)
    for row in labels:
        if not isinstance(row, dict):
            raise ProbeError("dom_geometry_incomplete")
        _finite_nonnegative(row.get("fontSize"), positive=True)
        for key in ("relativeTop", "controlTopWithinLabel"):
            if key not in row:
                raise ProbeError("dom_geometry_incomplete")
            value = row[key]
            if type(value) not in (int, float) or finite_number(value) is None:
                raise ProbeError("dom_geometry_incomplete")
    control_heights = [number for row in controls if (number := finite_number(row.get("height"))) is not None]
    control_widths = [number for row in controls if (number := finite_number(row.get("width"))) is not None]
    label_fonts = [number for row in labels if (number := finite_number(row.get("fontSize"))) is not None]
    label_tops = [number for row in labels if (number := finite_number(row.get("relativeTop"))) is not None]
    label_control_offsets = [
        number
        for row in labels
        if (number := finite_number(row.get("controlTopWithinLabel"))) is not None
    ]
    rows = cluster_rows(label_tops)
    return {
        "available": True,
        "control_count": counts["controlCount"],
        "control_height_px": {
            "maximum": round(max(control_heights), 2) if control_heights else None,
            "median": round(statistics.median(control_heights), 2) if control_heights else None,
            "minimum": round(min(control_heights), 2) if control_heights else None,
        },
        "control_width_px": {
            "maximum": round(max(control_widths), 2) if control_widths else None,
            "median": round(statistics.median(control_widths), 2) if control_widths else None,
            "minimum": round(min(control_widths), 2) if control_widths else None,
        },
        "controls_below_24_px": sum(height < 24 for height in control_heights),
        "controls_below_44_px": sum(height < 44 for height in control_heights),
        "disabled_control_count": counts["disabledControlCount"],
        "fieldset_count": counts["fieldsetCount"],
        "form_height_px": round(form_height, 2),
        "form_width_px": round(form_width, 2),
        "full_width_control_count": sum(width >= form_width * 0.9 for width in control_widths) if form_width else 0,
        "horizontal_overflow_px": round(overflow, 2),
        "label_control_top_offset_px_median": round(statistics.median(label_control_offsets), 2) if label_control_offsets else None,
        "label_count": counts["labelCount"],
        "label_font_minimum_px": round(min(label_fonts), 2) if label_fonts else None,
        "label_row_count": len(rows),
        "labels_in_largest_row": max((len(row) for row in rows), default=0),
        "legend_count": counts["legendCount"],
        "required_control_count": counts["requiredControlCount"],
        "unlabelled_field_control_count": counts["unlabelledFieldControlCount"],
    }


def opencv_summary(image: np.ndarray) -> dict[str, Any]:
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 80, 180)
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=70, minLineLength=40, maxLineGap=5)
    horizontal = 0
    vertical = 0
    if lines is not None:
        for x1, y1, x2, y2 in lines[:, 0]:
            delta_x = abs(int(x2) - int(x1))
            delta_y = abs(int(y2) - int(y1))
            if delta_y <= 2 and delta_x >= 40:
                horizontal += 1
            if delta_x <= 2 and delta_y >= 20:
                vertical += 1
    return {
        "edge_density": round(float(np.mean(edges > 0)), 5),
        "height_px": int(image.shape[0]),
        "hough_horizontal_segment_count": horizontal,
        "hough_vertical_segment_count": vertical,
        "near_white_ratio": round(float(np.mean(gray >= 245)), 5),
        "width_px": int(image.shape[1]),
    }


def ocr_summary(image: np.ndarray, psm: int) -> dict[str, Any]:
    try:
        import pytesseract
        from pytesseract import Output

        data = pytesseract.image_to_data(
            image,
            config=f"--psm {psm}",
            output_type=Output.DICT,
            timeout=30,
        )
    except Exception as error:  # OCR is advisory; retain only the bounded failure class.
        return {"status": "unavailable", "failure_class": error.__class__.__name__, "raw_text_retained": False}
    required = ("text", "conf", "block_num", "par_num", "line_num", "width", "height")
    if not isinstance(data, dict) or not all(isinstance(data.get(key), list) for key in required):
        return {"status": "unavailable", "failure_class": "MalformedOCRResult", "raw_text_retained": False}
    if any(len(data[key]) != len(data["text"]) for key in required):
        return {"status": "unavailable", "failure_class": "MalformedOCRResult", "raw_text_retained": False}
    confidences: list[float] = []
    line_ids: set[tuple[int, int, int]] = set()
    recognized_area = 0
    try:
        for index, text in enumerate(data["text"]):
            if not str(text).strip():
                continue
            confidence = finite_number(data["conf"][index])
            if confidence is not None and confidence >= 0:
                confidences.append(confidence)
            line_ids.add(
                (
                    int(data["block_num"][index]),
                    int(data["par_num"][index]),
                    int(data["line_num"][index]),
                )
            )
            recognized_area += int(data["width"][index]) * int(data["height"][index])
    except (TypeError, ValueError):
        return {"status": "unavailable", "failure_class": "MalformedOCRResult", "raw_text_retained": False}
    image_area = max(1, image.shape[0] * image.shape[1])
    return {
        "below_80_confidence_ratio": round(sum(value < 80 for value in confidences) / len(confidences), 5) if confidences else None,
        "line_count": len(line_ids),
        "median_confidence": round(statistics.median(confidences), 2) if confidences else None,
        "recognized_box_area_ratio": round(recognized_area / image_area, 5),
        "recognized_token_count": len(confidences),
        "raw_text_retained": False,
        "status": "measured",
    }


def aggregate(samples: list[dict[str, Any]]) -> dict[str, Any]:
    control_minimums = [
        row["dom"]["control_height_px"]["minimum"]
        for row in samples
        if row["dom"].get("available") and row["dom"]["control_height_px"]["minimum"] is not None
    ]
    ocr_confidences = [
        row["ocr"]["median_confidence"]
        for row in samples
        if row["ocr"].get("status") == "measured" and row["ocr"]["median_confidence"] is not None
    ]
    return {
        "dom_authority_status": "structurally_complete_origin_unverified",
        "dom_sample_count": len(samples),
        "minimum_control_height_px": min(control_minimums) if control_minimums else None,
        "ocr_median_confidence_across_samples": round(statistics.median(ocr_confidences), 2) if ocr_confidences else None,
        "sample_count": len(samples),
        "samples_with_control_below_24_px": sum(row["dom"]["controls_below_24_px"] > 0 for row in samples),
        "samples_with_control_below_44_px": sum(row["dom"]["controls_below_44_px"] > 0 for row in samples),
        "samples_with_horizontal_overflow": sum(row["dom"]["horizontal_overflow_px"] > 1 for row in samples),
        "scenario_ids": sorted({row["scenario_id"] for row in samples}),
    }


def build_payload(
    capture_roots: list[Path],
    *,
    input_class: str,
    skip_ocr: bool,
    psm: int,
) -> dict[str, Any]:
    if input_class not in {"synthetic", "approved-redacted"}:
        raise ProbeError("input_class_invalid")
    if type(psm) is not int or psm < 0:
        raise ProbeError("ocr_psm_invalid")
    samples: list[dict[str, Any]] = []
    seen_roots: set[Path] = set()
    seen_samples: set[tuple[str, int, int]] = set()
    seen_capture_ids: set[str] = set()
    for root in capture_roots:
        if not root.is_dir():
            raise ProbeError("capture_root_not_found")
        resolved_root = root.resolve()
        if resolved_root in seen_roots:
            raise ProbeError("capture_root_duplicate")
        seen_roots.add(resolved_root)
        dom_measurements = load_dom_measurements(root)
        path_identities = [
            (path, parse_image_identity(path))
            for path in sorted(root.glob("*-form.png"))
        ]
        root_identities = {identity for _, identity in path_identities}
        if len(root_identities) != len(path_identities):
            raise ProbeError("capture_image_duplicate_identity")
        missing_dom = root_identities - set(dom_measurements)
        if missing_dom:
            raise ProbeError("dom_geometry_missing_for_image")
        if set(dom_measurements) - root_identities:
            raise ProbeError("dom_geometry_without_image")
        for path, identity in path_identities:
            scenario, viewport_width, viewport_height = identity
            if identity in seen_samples:
                raise ProbeError("capture_image_duplicate_identity")
            seen_samples.add(identity)
            row = dom_measurements[identity]
            if row["captureId"] in seen_capture_ids:
                raise ProbeError("capture_id_duplicate")
            seen_capture_ids.add(row["captureId"])
            image_hash = image_sha256(path)
            if row["imageSha256"] != image_hash:
                raise ProbeError("capture_image_hash_mismatch")
            image = cv2.imread(str(path))
            if image is None:
                raise ProbeError("capture_image_unreadable")
            if image.shape[1] != viewport_width or image.shape[0] != viewport_height:
                raise ProbeError("capture_dimensions_mismatch")
            sample = {
                "capture_id": row["captureId"],
                "dom": dom_summary(row["geometry"]),
                "dom_record_sha256": image_sha256(root / "dom-geometry.json"),
                "image_sha256": image_hash,
                "opencv": opencv_summary(image),
                "ocr": {"status": "skipped", "raw_text_retained": False}
                if skip_ocr
                else ocr_summary(image, psm),
                "scenario_id": scenario,
                "viewport_height": viewport_height,
                "viewport_width": viewport_width,
            }
            samples.append(sample)
    if not samples:
        raise ProbeError("no_form_capture_images_found")
    return {
        "aggregate": aggregate(samples),
        "downloads_performed": False,
        "artifact_hash_status": "local_image_and_dom_bytes_hashed",
        "dom_geometry_source_status": "capture_packet_declaration_not_independently_authenticated",
        "human_review_status": "not_performed",
        "input_authority_asserted_by_operator": input_class,
        "observed_input_classification": "not_independently_verified",
        "observed_artifacts": "image_and_dom_bytes_read_and_hashed",
        "pixel_measurement_status": "measured_from_local_png",
        "raw_ocr_retained": False,
        "raw_pixels_copied_by_probe": False,
        "samples": samples,
        "schema_version": SCHEMA_VERSION,
        "runtime_proof_status": "not_performed",
    }


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        payload = build_payload(
            args.capture_root,
            input_class=args.input_class,
            skip_ocr=args.skip_ocr,
            psm=args.psm,
        )
    except ProbeError as error:
        raise SystemExit(str(error)) from error
    rendered = f"{json.dumps(payload, indent=2, sort_keys=True)}\n"
    if args.output:
        if args.output_root is None:
            raise SystemExit("output_root_required")
        protected = [path for root in args.capture_root for path in (root / "dom-geometry.json", *root.glob("*-form.png"))]
        try:
            output = safe_output_path(args.output_root, args.output, protected)
        except OutputPathError as error:
            raise SystemExit(str(error)) from error
        output.parent.mkdir(parents=True, exist_ok=True)
        try:
            with output.open("x", encoding="utf-8") as handle:
                handle.write(rendered)
        except FileExistsError as error:
            raise SystemExit("output_exists_preserve_prior_result") from error
    sys.stdout.write(rendered)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
