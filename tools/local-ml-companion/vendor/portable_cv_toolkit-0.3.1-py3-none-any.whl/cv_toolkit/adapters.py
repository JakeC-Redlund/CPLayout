"""Lazy local model adapters, callable only inside the managed worker.

No package installation, Hub client or automatic model acquisition occurs here.
"""
from __future__ import annotations

from contextlib import nullcontext
import importlib.metadata
import math
import os
from pathlib import Path
import statistics
import time

from .artifacts import artifact_row, atomic_write, sha256_file, stage_verified_asset
from .jobs import PROFILE, training_identity


class ReadinessGap(RuntimeError):
    pass


def torch_setup(job, context):
    import sys
    if sys.version_info[:2] != (3, 12):
        raise ReadinessGap("python_runtime_profile_mismatch")
    try:
        import torch
        import torchvision
    except (ImportError, OSError, RuntimeError) as error:
        raise ReadinessGap("torch_torchvision_import_failed:" + type(error).__name__) from error
    # Torch exposes a str subclass (TorchVersion). Persist plain primitives so
    # our own checkpoints remain loadable with weights_only=True.
    actual = {"torch": str(torch.__version__), "torchvision": str(torchvision.__version__),
              "cuda": str(torch.version.cuda) if torch.version.cuda is not None else None}
    if actual["torch"] != PROFILE["torch"] or actual["torchvision"] != PROFILE["torchvision"] or actual["cuda"] != PROFILE["cuda"]:
        raise ReadinessGap("runtime_profile_mismatch")
    context.runtime_identity = actual
    torch.set_num_threads(job["limits"]["cpu_threads"])
    torch.use_deterministic_algorithms(True)
    if job["device"] == "cuda":
        if not torch.cuda.is_available():
            raise ReadinessGap("cuda_not_available")
        device = torch.device("cuda:0")
        total = torch.cuda.get_device_properties(device).total_memory
        torch.cuda.set_per_process_memory_fraction(min(1.0, job["limits"]["gpu_budget_bytes"] / total), device)
        torch.cuda.reset_peak_memory_stats(device)
        context.torch = torch
        context.device = device
        if job["configuration"]["precision"] == "bf16" and not torch.cuda.is_bf16_supported():
            raise ReadinessGap("bf16_not_supported")
    else:
        device = torch.device("cpu")
    context.check()
    return torch, torchvision, device


def autocast(torch, job):
    precision = job["configuration"]["precision"]
    return (torch.autocast("cuda", dtype=torch.float16 if precision == "fp16" else torch.bfloat16)
            if job["device"] == "cuda" and precision != "fp32" else nullcontext())


def synchronize(torch, device):
    if device.type == "cuda":
        torch.cuda.synchronize(device)


def timed_summary(samples):
    ordered = sorted(samples)
    return {"samples_ms": samples, "p50_ms": statistics.median(samples) if samples else None,
            "p95_ms": ordered[max(0, math.ceil(len(ordered) * .95) - 1)] if ordered else None,
            "runs_per_second": 1000 * len(samples) / sum(samples) if samples and sum(samples) else None}


def _state_delta(torch, actual, expected):
    if set(actual) != set(expected):
        raise ValueError("comparison_state_keys_mismatch")
    maximum, equal = 0.0, True
    for key, value in actual.items():
        other = expected[key]
        if value.shape != other.shape or value.dtype != other.dtype:
            raise ValueError("comparison_state_shape_mismatch")
        value, other = value.detach().cpu(), other.detach().cpu()
        equal = equal and torch.equal(value, other)
        maximum = max(maximum, float((value.to(torch.float64) - other.to(torch.float64)).abs().max().item()))
    return {"parameters_and_buffers_exact_match": equal, "maximum_absolute_difference": maximum}


def mobilenet_smoke(job, context):
    if job["configuration"].get("compile"):
        raise ReadinessGap("compile_descendant_cleanup_not_qualified")
    torch, torchvision, device = torch_setup(job, context)
    config = job["configuration"]
    assets = {row["role"]: {**row, "path": str(stage_verified_asset(row, context.output,
              max_bytes=job["limits"]["max_asset_bytes"]))} for row in job["assets"]}
    context.assets_verified = True
    identity = training_identity(job)
    torch.manual_seed(config["seed"])
    if device.type == "cuda":
        torch.cuda.manual_seed_all(config["seed"])
    start = time.perf_counter()
    model = torchvision.models.mobilenet_v3_small(weights=None, num_classes=config["num_classes"]).to(device)
    if config["channels_last"]:
        model = model.to(memory_format=torch.channels_last)
    optimizer = torch.optim.SGD(model.parameters(), lr=config["learning_rate"], momentum=0.9)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda" and config["precision"] == "fp16")
    first_step = 0
    if "resume" in assets:
        checkpoint = torch.load(assets["resume"]["path"], map_location="cpu", weights_only=True)
        if checkpoint.get("schema_version") != "CVTrainingCheckpoint-v1" or checkpoint.get("training_identity") != identity:
            raise ValueError("resume_identity_mismatch")
        first_step = checkpoint["completed_steps"]
        if type(first_step) is not int or not 0 <= first_step < config["steps"]:
            raise ValueError("resume_step_invalid")
        model.load_state_dict(checkpoint["model"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        # Optimizer state loaded for CUDA model parameters is migrated by torch.
        scaler.load_state_dict(checkpoint["scaler"])
        torch.set_rng_state(checkpoint["cpu_rng"])
        if device.type == "cuda":
            torch.cuda.set_rng_state_all(checkpoint["cuda_rng"])
    synchronize(torch, device)
    context.timings["model_load_ms"] = (time.perf_counter() - start) * 1000
    # Keep original state keys independent of torch.compile's _orig_mod wrapper.
    forward_model = torch.compile(model) if config["compile"] else model
    step_times, losses = [], []
    completed = first_step
    checkpoint_path = None

    def save_checkpoint():
        nonlocal checkpoint_path
        payload = {"schema_version": "CVTrainingCheckpoint-v1", "training_identity": identity,
                   "completed_steps": completed, "model": model.state_dict(), "optimizer": optimizer.state_dict(),
                   "scaler": scaler.state_dict(), "cpu_rng": torch.get_rng_state(),
                   "cuda_rng": torch.cuda.get_rng_state_all() if device.type == "cuda" else [],
                   "runtime": context.runtime_identity, "microbatch": 1, "synthetic": True}
        def write_checkpoint(path):
            # torch's zip writer rejects dot-prefixed filenames; file objects
            # preserve our atomic temporary-file protocol on every platform.
            with path.open("wb") as stream:
                torch.save(payload, stream)
        checkpoint_path = atomic_write(context.output, f"checkpoint-{completed:04d}.pt",
                                       write_checkpoint, protected=context.protected)
        context.outputs.append(artifact_row(checkpoint_path, context.output, role="checkpoint"))

    try:
        for step in range(first_step, config["steps"]):
            context.check()
            generator = torch.Generator(device="cpu").manual_seed(config["seed"] + step + 1)
            x = torch.randn((1, 3, config["image_size"], config["image_size"]), generator=generator)
            y = torch.randint(config["num_classes"], (1,), generator=generator)
            synchronize(torch, device)
            transfer_start = time.perf_counter()
            x, y = x.to(device), y.to(device)
            if config["channels_last"]:
                x = x.contiguous(memory_format=torch.channels_last)
            synchronize(torch, device)
            context.timings["transfer_ms"] = context.timings.get("transfer_ms", 0) + (time.perf_counter() - transfer_start) * 1000
            optimizer.zero_grad(set_to_none=True)
            # Microbatch=1: freeze running BatchNorm statistics to support small
            # smoke shapes, while training affine parameters and dropout normally.
            forward_model.train()
            for module in model.modules():
                if isinstance(module, torch.nn.modules.batchnorm._BatchNorm):
                    module.eval()
            step_start = time.perf_counter()
            with autocast(torch, job):
                prediction = forward_model(x)
                loss = torch.nn.functional.cross_entropy(prediction, y)
            if not torch.isfinite(loss).item():
                raise ValueError("nonfinite_training_loss")
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            synchronize(torch, device)
            step_times.append((time.perf_counter() - step_start) * 1000)
            losses.append(float(loss.detach().item()))
            completed = step + 1
            context.stage("forward_backward_optimizer", str(prediction.device), tensors_verified=True,
                          parameter_device=str(next(model.parameters()).device))
            if completed % config["checkpoint_interval"] == 0 or completed == config["steps"]:
                save_checkpoint()
            if config.get("stop_after") == completed:
                context.stop_reason = "requested_checkpoint_stop"
                break
    finally:
        if completed > first_step and (checkpoint_path is None or checkpoint_path.name != f"checkpoint-{completed:04d}.pt"):
            save_checkpoint()
    comparison = None
    if "comparison" in assets:
        expected = torch.load(assets["comparison"]["path"], map_location="cpu", weights_only=True)
        if expected.get("training_identity") != identity or expected.get("completed_steps") != completed:
            raise ValueError("comparison_identity_mismatch")
        comparison = _state_delta(torch, model.state_dict(), expected["model"])
    timed = step_times[1:]  # first step includes lazy CUDA/compile warm-up.
    ordered = sorted(timed)
    context.timings.update(first_step_ms=step_times[0] if step_times else None,
        compute_ms=sum(step_times), warm_step_p50_ms=statistics.median(timed) if timed else None,
        warm_step_p95_ms=ordered[max(0, math.ceil(len(ordered) * .95) - 1)] if ordered else None,
        warm_steps_per_second=1000 * len(timed) / sum(timed) if timed and sum(timed) else None)
    return {"completed_steps": completed, "resumed_from_step": first_step, "microbatch": 1,
            "synthetic_training": True, "quality_evaluated": False,
            "final_loss": losses[-1] if losses else None, "comparison": comparison,
            "training_identity": identity, "checkpoint": checkpoint_path.name if checkpoint_path else None,
            "limitations": ["synthetic_smoke_not_learned_quality", "batchnorm_running_statistics_frozen",
                            "cooperative_checkpoint_on_cancel_hard_timeout_may_keep_last_checkpoint"]}


def sam2_image(job, context):
    torch, _, device = torch_setup(job, context)
    try:
        import numpy as np
        from PIL import Image
        import sam2
        from sam2.build_sam import build_sam2
        from sam2.sam2_image_predictor import SAM2ImagePredictor
    except (ImportError, OSError) as error:
        raise ReadinessGap("sam2_dependencies_unavailable:" + type(error).__name__) from error
    assets = {row["role"]: {**row, "path": str(stage_verified_asset(row, context.output,
              max_bytes=job["limits"]["max_asset_bytes"]))} for row in job["assets"]}
    context.assets_verified = True
    config = job["configuration"]
    installed_config = Path(sam2.__file__).resolve().parent / config["config_name"]
    if not installed_config.is_file() or sha256_file(installed_config) != assets["config"]["sha256"]:
        raise ReadinessGap("installed_sam2_config_hash_mismatch")
    image_path = assets["image"]["path"]
    start = time.perf_counter()
    with Image.open(image_path) as image:
        width, height = image.size
        if width * height > job["limits"]["max_pixels"]:
            raise ValueError("image_oversized")
        image = np.asarray(image.convert("RGB"))
    if any(x >= width or y >= height for x, y in config["points"]):
        raise ValueError("point_outside_image")
    context.timings["preprocessing_ms"] = (time.perf_counter() - start) * 1000
    context.check()
    start = time.perf_counter()
    model = build_sam2(config["config_name"], assets["checkpoint"]["path"], device=str(device),
                       mode="eval", apply_postprocessing=False)
    predictor = SAM2ImagePredictor(model, max_hole_area=0, max_sprinkle_area=0)
    synchronize(torch, device)
    context.timings["model_load_ms"] = (time.perf_counter() - start) * 1000
    context.check()
    warmups, samples = [], []
    def decoder_observed(module, args, output):
        tensor = output[0]
        context.stage("mask_decoder", str(tensor.device), tensors_verified=True,
                      evidence="forward-hook-output-tensor")
    hook = model.sam_mask_decoder.register_forward_hook(decoder_observed)
    try:
        for iteration in range(config["warmup_steps"] + config["measurement_runs"]):
            context.check()
            synchronize(torch, device)
            start = time.perf_counter()
            with torch.inference_mode(), autocast(torch, job):
                predictor.set_image(image)
                embedding = predictor.get_image_embedding()
                context.stage("image_encoder", str(embedding.device), tensors_verified=True,
                              parameter_device=str(next(model.parameters()).device))
                masks, scores, _ = predictor.predict(point_coords=np.asarray(config["points"], dtype=np.float32),
                    point_labels=np.asarray(config["labels"], dtype=np.int32), multimask_output=False)
            synchronize(torch, device)
            elapsed = (time.perf_counter() - start) * 1000
            (warmups if iteration < config["warmup_steps"] else samples).append(elapsed)
    finally:
        hook.remove()
    context.timings.update(compute_ms=sum(warmups + samples), warmup_ms=warmups, measurement=timed_summary(samples))
    context.check()
    mask = masks[0].astype(bool)
    def save_npy(path):
        with path.open("wb") as handle:
            np.save(handle, mask, allow_pickle=False)
    mask_path = atomic_write(context.output, "mask.npy", save_npy, protected=context.protected)
    image_path = atomic_write(context.output, "mask.png", lambda path: Image.fromarray(mask.astype("uint8") * 255).save(path, format="PNG"),
                             protected=context.protected)
    context.outputs.extend([artifact_row(mask_path, context.output, role="mask"),
                            artifact_row(image_path, context.output, role="mask-preview")])
    return {"mask_shape": list(mask.shape), "foreground_pixels": int(mask.sum()), "score": float(scores[0]),
            "model_revision_declared": config["model_revision"], "weights_sha256": assets["checkpoint"]["sha256"],
            "configuration_sha256": assets["config"]["sha256"], "coordinate_units": "image-pixels",
            "postprocessing_enabled": False, "quality_evaluated": False, "operator_accepted": False,
            "limitations": ["sam2_build_cuda_0_no_hole_sprinkle_postprocessing", "single_image_single_prompt",
                            "no_geometry_application_or_field_accuracy_claim"]}


def sam2_video(job, context):
    torch, _, device = torch_setup(job, context)
    try:
        import numpy as np
        from PIL import Image
        import sam2
        from sam2.build_sam import build_sam2_video_predictor
    except (ImportError, OSError) as error:
        raise ReadinessGap("sam2_video_dependencies_unavailable:" + type(error).__name__) from error
    assets = {row["id"]: {**row, "path": str(stage_verified_asset(row, context.output,
              max_bytes=job["limits"]["max_asset_bytes"]))} for row in job["assets"]}
    context.assets_verified = True
    config = job["configuration"]
    checkpoint = next(row for row in assets.values() if row["role"] == "checkpoint")
    configuration = next(row for row in assets.values() if row["role"] == "config")
    installed_config = Path(sam2.__file__).resolve().parent / config["config_name"]
    if not installed_config.is_file() or sha256_file(installed_config) != configuration["sha256"]:
        raise ReadinessGap("installed_sam2_config_hash_mismatch")
    frames_root = context.output / "frames"
    frames_root.mkdir()
    dimensions = None
    for index, frame_id in enumerate(config["frame_ids"]):
        context.check()
        path = Path(assets[frame_id]["path"])
        with Image.open(path) as image:
            if image.format != "JPEG":
                raise ValueError("video_adapter_requires_explicit_jpeg_frames")
            width, height = image.size
            if width * height > job["limits"]["max_pixels"] or (dimensions is not None and dimensions != image.size):
                raise ValueError("video_frame_dimensions_invalid")
            image.verify()
            dimensions = (width, height)
        os.link(path, frames_root / f"{index:05d}.jpg")
    if any(x >= dimensions[0] or y >= dimensions[1] for x, y in config["points"]):
        raise ValueError("point_outside_image")
    context.check()
    start = time.perf_counter()
    predictor = build_sam2_video_predictor(config["config_name"], checkpoint["path"], device=str(device),
                                         mode="eval", apply_postprocessing=False,
                                         hydra_overrides_extra=["++model.fill_hole_area=0"])
    synchronize(torch, device)
    context.timings["model_load_ms"] = (time.perf_counter() - start) * 1000
    def encoder_observed(module, args, output):
        context.stage("video_image_encoder", str(output["vision_features"].device), tensors_verified=True,
                      evidence="forward-hook-output-tensor")
    def decoder_observed(module, args, output):
        context.stage("video_mask_decoder", str(output[0].device), tensors_verified=True,
                      evidence="forward-hook-output-tensor")
    hooks = [predictor.image_encoder.register_forward_hook(encoder_observed),
             predictor.sam_mask_decoder.register_forward_hook(decoder_observed)]
    warmups, samples, frame_metrics = [], [], []
    try:
        for iteration in range(config["warmup_steps"] + config["measurement_runs"]):
            context.check()
            synchronize(torch, device)
            start = time.perf_counter()
            with torch.inference_mode(), autocast(torch, job):
                state = predictor.init_state(video_path=str(frames_root), offload_video_to_cpu=True,
                                             offload_state_to_cpu=True, async_loading_frames=False)
                predictor.add_new_points_or_box(inference_state=state, frame_idx=0, obj_id=1,
                    points=np.asarray(config["points"], dtype=np.float32), labels=np.asarray(config["labels"], dtype=np.int32))
                masks = {}
                frame_metrics = []
                for frame_index, object_ids, mask_logits in predictor.propagate_in_video(state):
                    context.check()
                    synchronize(torch, device)
                    mask = (mask_logits[0, 0] > 0).detach().cpu().numpy()
                    masks[frame_index] = mask
                    frame_metrics.append({"frame_index": frame_index, "object_ids": list(object_ids),
                                          "foreground_pixels": int(mask.sum()), "returned_tensor_device": str(mask_logits.device)})
                predictor.reset_state(state)
                del state
            synchronize(torch, device)
            elapsed = (time.perf_counter() - start) * 1000
            (warmups if iteration < config["warmup_steps"] else samples).append(elapsed)
    finally:
        for hook in hooks:
            hook.remove()
    if set(masks) != set(range(len(config["frame_ids"]))):
        raise ValueError("video_frame_outputs_incomplete")
    for index, mask in sorted(masks.items()):
        def save_mask(path, mask=mask):
            with path.open("wb") as stream:
                np.save(stream, mask, allow_pickle=False)
        path = atomic_write(context.output, f"mask-{index:05d}.npy", save_mask, protected=context.protected)
        context.outputs.append(artifact_row(path, context.output, role="frame-mask", frame_index=index))
    context.timings.update(compute_ms=sum(warmups + samples), warmup_ms=warmups, measurement=timed_summary(samples))
    return {"frame_count": len(masks), "frames": frame_metrics, "model_revision_declared": config["model_revision"],
            "weights_sha256": checkpoint["sha256"], "configuration_sha256": configuration["sha256"],
            "postprocessing_enabled": False, "offload_video_to_cpu": True, "offload_state_to_cpu": True,
            "quality_evaluated": False, "operator_accepted": False,
            "limitations": ["explicit_jpeg_sequence_not_codec_acceleration", "no_hole_sprinkle_postprocessing",
                            "first_frame_single_object_prompt", "no_field_accuracy_or_geometry_application_claim"]}


ADAPTERS = {"mobilenet-smoke": mobilenet_smoke, "sam2-image": sam2_image, "sam2-video": sam2_video}
