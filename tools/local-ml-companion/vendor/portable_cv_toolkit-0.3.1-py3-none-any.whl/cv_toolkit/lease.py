"""Cross-process OS lock plus ownership record. Never signal a recorded PID."""
from __future__ import annotations

import json
import os
from pathlib import Path
import platform
import stat
import time
import uuid


class LeaseBusy(RuntimeError):
    pass


def process_identity() -> dict:
    value = {"pid": os.getpid(), "host": platform.node(), "start": None}
    if os.name == "posix":
        try:
            # comm can contain spaces/parentheses: split after its final ')'.
            fields = Path("/proc/self/stat").read_text().rsplit(")", 1)[1].split()
            value["start"] = Path("/proc/sys/kernel/random/boot_id").read_text().strip() + ":" + fields[19]
        except (OSError, IndexError):
            pass
    elif os.name == "nt":
        import ctypes
        from ctypes import wintypes
        times = [wintypes.FILETIME() for _ in range(4)]
        kernel = ctypes.windll.kernel32
        kernel.GetCurrentProcess.restype = wintypes.HANDLE
        kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
        if kernel.GetProcessTimes(kernel.GetCurrentProcess(), *(ctypes.byref(t) for t in times)):
            value["start"] = str((times[0].dwHighDateTime << 32) | times[0].dwLowDateTime)
    return value


class GPULease:
    """A persistent lock file, not an unlinkable PID-file mutex.

    Kernel lock ownership is authoritative. Crash recovery acquires that same
    lock and preserves prior metadata; it never infers ownership from PID alone.
    Use one local path across all managed Linux workspaces. Separate Windows/WSL
    kernels need host-level orchestration; this lock does not claim cross-OS locks.
    """
    def __init__(self, path: Path | None = None, *, job_id: str):
        self.path = path or Path.home() / ".local/state/cv-toolkit/gpu-0.lease"
        self.job_id = job_id
        self.token = uuid.uuid4().hex
        self.handle = None
        self.record = None
        self.retain_on_exit = False

    def _write(self):
        self.handle.seek(0)
        self.handle.write(json.dumps(self.record, sort_keys=True).encode() + b"\n")
        self.handle.truncate()
        self.handle.flush()
        os.fsync(self.handle.fileno())

    def __enter__(self):
        self.path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        if self.path.is_symlink():
            raise LeaseBusy("lease_symlink_rejected")
        if self.path.parent.resolve() != self.path.parent.absolute():
            raise LeaseBusy("lease_parent_symlink_rejected")
        flags = os.O_RDWR | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
        descriptor = os.open(self.path, flags, 0o600)
        opened = os.fstat(descriptor)
        if not stat.S_ISREG(opened.st_mode) or opened.st_nlink != 1:
            os.close(descriptor)
            raise LeaseBusy("lease_not_unique_regular_file")
        if os.name == "posix" and (opened.st_uid != os.getuid() or self.path.parent.stat().st_mode & 0o022):
            os.close(descriptor)
            raise LeaseBusy("lease_ownership_or_directory_permissions_invalid")
        current = self.path.lstat()
        if (current.st_dev, current.st_ino) != (opened.st_dev, opened.st_ino) or stat.S_ISLNK(current.st_mode):
            os.close(descriptor)
            raise LeaseBusy("lease_identity_changed")
        self.handle = os.fdopen(descriptor, "r+b")
        try:
            if os.name == "nt":
                import msvcrt
                if self.path.stat().st_size == 0:
                    self.handle.write(b" ")
                    self.handle.flush()
                self.handle.seek(0)
                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, ImportError) as error:
            self.handle.close()
            self.handle = None
            raise LeaseBusy("gpu_lease_busy_or_lock_unavailable") from error
        self.handle.seek(0)
        try:
            old = json.loads(self.handle.read(65536))
        except (ValueError, UnicodeError):
            old = None
        self.record = {"schema_version": "CVGPULease-v1", "token": self.token, "owner": process_identity(),
                       "job_id": self.job_id, "state": "running", "started_unix": time.time(),
                       "prior": {k: old.get(k) for k in ("token", "owner", "job_id", "state")} if isinstance(old, dict) else None,
                       "recovery": "kernel-lock-reacquired" if old and old.get("state") == "running" else None}
        self._write()
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.handle:
            try:
                self.record.update(state="cleanup-unverified" if self.retain_on_exit else "released", ended_unix=time.time())
                self._write()
            finally:
                if self.retain_on_exit:
                    # Never issue LOCK_UN against the shared open-file description
                    # while an inherited worker may still hold it. Closing only our
                    # reference keeps the worker's kernel lock alive.
                    pass
                elif os.name == "nt":
                    import msvcrt
                    self.handle.seek(0)
                    msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
                self.handle.close()
                self.handle = None

    def worker_fd(self) -> int:
        if os.name != "posix" or self.handle is None:
            raise LeaseBusy("inherited_lease_unavailable")
        return self.handle.fileno()


def validate_inherited_lease(descriptor: int, token: str) -> None:
    """Validate the explicitly inherited descriptor without unlocking/reopening it."""
    metadata = os.fstat(descriptor)
    if not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink != 1 or metadata.st_uid != os.getuid():
        raise LeaseBusy("inherited_lease_invalid")
    # pread leaves the shared offset unchanged for supervisor metadata updates.
    record = json.loads(os.pread(descriptor, 65536, 0))
    if not isinstance(record, dict) or record.get("token") != token or record.get("state") != "running":
        raise LeaseBusy("inherited_lease_identity_mismatch")
