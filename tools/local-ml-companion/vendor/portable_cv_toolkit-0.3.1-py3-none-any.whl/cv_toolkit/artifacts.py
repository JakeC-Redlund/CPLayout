"""Streaming artifact identities and confined, atomic local writes."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import tempfile

from .paths import safe_output_path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def json_sha256(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def valid_sha256(value: object) -> bool:
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def atomic_write(root: Path, name: str, writer, *, protected=()) -> Path:
    """Write beside the target then publish atomically; no source overwrite.

    The caller owns root and must prevent hostile concurrent directory changes.
    Existing symlinks and traversal are rejected. Immutable artifacts use a hard
    link for atomic no-clobber publication, rather than exists-then-rename.
    """
    target = safe_output_path(root, Path(name), protected)
    if target.parent != Path(root).resolve() and not target.parent.is_dir():
        raise ValueError("output_parent_missing")
    fd, temporary = tempfile.mkstemp(prefix=".cv-write-", dir=target.parent)
    os.close(fd)
    temporary = Path(temporary)
    try:
        writer(temporary)
        with temporary.open("rb") as handle:
            os.fsync(handle.fileno())
        if safe_output_path(root, Path(name), protected) != target:
            raise ValueError("output_changed_during_write")
        os.link(temporary, target)
        temporary.unlink()
        if os.name == "posix":
            directory = os.open(target.parent, os.O_RDONLY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
    finally:
        temporary.unlink(missing_ok=True)
    return target


def atomic_json(root: Path, name: str, value: object, **kwargs) -> Path:
    data = json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    return atomic_write(root, name, lambda path: path.write_text(data, encoding="utf-8"), **kwargs)


def artifact_row(path: Path, root: Path, **extra) -> dict:
    path = Path(path).resolve(strict=True)
    return {"ref": path.relative_to(Path(root).resolve()).as_posix(),
            "sha256": sha256_file(path), "bytes": path.stat().st_size, **extra}


def stage_verified_asset(asset: dict, root: Path, *, max_bytes: int) -> Path:
    """Copy the bytes actually opened, hash that copy, publish only on a match.

    Adapters load only this immutable, product-owned copy. Renaming/changing an
    external source after validation cannot silently change the admitted bytes.
    """
    def copy(source_target):
        digest, count = hashlib.sha256(), 0
        with Path(asset["path"]).open("rb") as source, source_target.open("wb") as target:
            for chunk in iter(lambda: source.read(1024 * 1024), b""):
                count += len(chunk)
                if count > max_bytes:
                    raise ValueError("asset_oversized_during_staging")
                digest.update(chunk)
                target.write(chunk)
        if digest.hexdigest() != asset["sha256"]:
            raise ValueError("asset_hash_mismatch_during_staging")
    return atomic_write(root, "input-" + asset["id"] + ".asset", copy, protected=[Path(asset["path"])])
