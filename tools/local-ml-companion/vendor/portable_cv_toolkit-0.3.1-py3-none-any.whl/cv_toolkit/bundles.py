"""Closed named model bundles and immutable, independently verifiable staging."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat

from .artifacts import atomic_write, sha256_file, valid_sha256
from .paths import safe_output_path
from .storage import host_capacity

BUNDLE_IDS = frozenset({"ocr-det", "ocr-rec", "detector"})
MODEL_NAMES = frozenset({"config.json", "preprocessor_config.json", "processor_config.json", "tokenizer.json",
    "tokenizer_config.json", "special_tokens_map.json", "vocab.txt", "vocab.json", "merges.txt",
    "added_tokens.json", "model.safetensors", "model.safetensors.index.json"})
MAX_BUNDLE_BYTES = 4 * 1024**3


def _hardlink_eligible(source: Path, output: Path) -> bool:
    """Only owner-controlled immutable files on the same admitted volume."""
    try:
        row = source.lstat()
        return (os.name == "posix" and source.resolve() == source.absolute()
                and stat.S_ISREG(row.st_mode) and row.st_uid == os.getuid()
                and row.st_mode & 0o222 == 0 and row.st_dev == output.stat().st_dev)
    except OSError:
        return False


def _admit_copy_growth(output: Path, required: int) -> None:
    if required <= 0:
        return
    capacity = host_capacity()
    free = capacity.get("free_bytes", {}).get("H")
    if type(free) is not int or free < 100 * 1024**3 + required:
        raise ValueError("staging_host_h_growth_reserve_unavailable")
    if shutil.disk_usage(output).free < 1024**3 + required:
        raise ValueError("staging_volume_growth_reserve_unavailable")


def _verified_hardlink(source: Path, destination: Path, expected: str, context) -> None:
    if not _hardlink_eligible(source, context.output):
        raise ValueError("model_hardlink_source_became_ineligible")
    descriptor = os.open(source, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    linked = False
    try:
        with os.fdopen(descriptor, "rb") as stream:
            initial = os.fstat(stream.fileno())
            if initial.st_size > context.job["limits"]["max_asset_bytes"]:
                raise ValueError("asset_oversized_during_staging")
            digest = hashlib.sha256()
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                context.check()
                digest.update(chunk)
            if digest.hexdigest() != expected:
                raise ValueError("asset_hash_mismatch_during_staging")
            os.link(source, destination, follow_symlinks=False)
            linked = True
            observed = destination.lstat()
            if ((initial.st_dev, initial.st_ino) != (observed.st_dev, observed.st_ino)
                    or observed.st_mode & 0o222 or observed.st_uid != os.getuid()
                    or not stat.S_ISREG(observed.st_mode)):
                raise ValueError("model_hardlink_source_identity_changed")
            # Reopen the actual staged name, independently of the source handle.
            if sha256_file(destination) != expected:
                raise ValueError("asset_hash_mismatch_after_link")
            context.check()
    except BaseException:
        if linked:
            destination.unlink(missing_ok=True)
        raise


def validate_member(asset: dict) -> None:
    bundle, ref = asset.get("bundle"), asset.get("relative_path")
    if not isinstance(bundle, str) or bundle not in BUNDLE_IDS:
        raise ValueError("bundle_id_invalid")
    if not isinstance(ref, str) or not ref or "\\" in ref:
        raise ValueError("bundle_relative_path_invalid")
    path = PurePosixPath(ref)
    if path.is_absolute() or len(path.parts) != 1 or str(path) != ref:
        raise ValueError("bundle_relative_path_invalid")
    if ref not in MODEL_NAMES and not re.fullmatch(r"model-\d{5}-of-\d{5}\.safetensors", ref):
        raise ValueError("bundle_member_not_allowlisted")


def staged_asset_path(output: Path, asset: dict) -> Path:
    if asset.get("role") == "model":
        validate_member(asset)
        return safe_output_path(output, Path("models") / asset["bundle"] / asset["relative_path"])
    return safe_output_path(output, Path("input-" + asset["id"] + ".asset"))


def validate_bundle_files(rows: list[dict]) -> None:
    """No pickle, executable code, or remote-code configuration in accepted bundles."""
    grouped = {}
    for row in rows:
        if row["role"] != "model":
            continue
        validate_member(row)
        members = grouped.setdefault(row["bundle"], {})
        if row["relative_path"] in members:
            raise ValueError("bundle_member_duplicate")
        members[row["relative_path"]] = row
    for bundle, members in grouped.items():
        if "config.json" not in members or "preprocessor_config.json" not in members:
            raise ValueError("bundle_configuration_missing:" + bundle)
        weights = [name for name in members if name.endswith(".safetensors")]
        if not weights:
            raise ValueError("bundle_safetensors_missing:" + bundle)
        if "model.safetensors" not in members and "model.safetensors.index.json" not in members:
            raise ValueError("bundle_shard_index_missing:" + bundle)
        if bundle == "detector" and ("tokenizer_config.json" not in members or not ({"tokenizer.json", "vocab.txt", "vocab.json"} & members.keys())):
            raise ValueError("bundle_tokenizer_missing")


def _check_json(path: Path, members: set[str]):
    if path.stat().st_size > 32 * 1024**2:
        raise ValueError("bundle_json_oversized")
    value = json.loads(path.read_text(encoding="utf-8"))
    def visit(item):
        if isinstance(item, dict):
            if "auto_map" in item or item.get("trust_remote_code") is True:
                raise ValueError("bundle_remote_code_configuration_rejected")
            for child in item.values():
                visit(child)
        elif isinstance(item, list):
            for child in item:
                visit(child)
    visit(value)
    if path.name == "model.safetensors.index.json":
        mapping = value.get("weight_map") if isinstance(value, dict) else None
        if not isinstance(mapping, dict) or not mapping or any(not isinstance(name, str) or name not in members or not name.endswith(".safetensors") for name in mapping.values()):
            raise ValueError("bundle_shard_index_invalid")
    # The actual safetensors parser and pinned built-in processor validate their
    # structures at load. Metadata names/URLs never grant download authority.


def stage_job_assets(job: dict, context) -> dict:
    validate_bundle_files(job["assets"])
    if sum(Path(row["path"]).stat().st_size for row in job["assets"] if row["role"] == "model") > MAX_BUNDLE_BYTES:
        raise ValueError("bundle_total_bytes_exceeded")
    result = {"media": None, "bundles": {}, "assets": {}}
    hardlink_ids = {row["id"] for row in job["assets"] if row["role"] == "model"
                    and _hardlink_eligible(Path(row["path"]), context.output)}
    source_sizes = {row["id"]: Path(row["path"]).stat().st_size for row in job["assets"]}
    copy_bytes = sum(source_sizes[row["id"]] for row in job["assets"] if row["id"] not in hardlink_ids)
    _admit_copy_growth(context.output, copy_bytes)
    for row in job["assets"]:
        context.check()
        destination = staged_asset_path(context.output, row)
        destination.parent.mkdir(parents=True, exist_ok=True)
        relative = destination.relative_to(context.output.resolve()).as_posix()
        def copy(path, row=row):
            digest, count = hashlib.sha256(), 0
            with Path(row["path"]).open("rb") as source, path.open("wb") as target:
                for chunk in iter(lambda: source.read(1024 * 1024), b""):
                    context.check()
                    count += len(chunk)
                    if count > job["limits"]["max_asset_bytes"] or count > source_sizes[row["id"]]:
                        raise ValueError("asset_oversized_during_staging")
                    digest.update(chunk)
                    target.write(chunk)
            if digest.hexdigest() != row["sha256"]:
                raise ValueError("asset_hash_mismatch_during_staging")
        if row["id"] in hardlink_ids:
            _verified_hardlink(Path(row["path"]), destination, row["sha256"], context)
        else:
            atomic_write(context.output, relative, copy, protected=context.protected)
        result["assets"][row["id"]] = destination
        if row["role"] == "model":
            result["bundles"][row["bundle"]] = destination.parent
        else:
            result["media"] = destination
    for directory in result["bundles"].values():
        members = {path.name for path in directory.iterdir()}
        for path in directory.glob("*.json"):
            _check_json(path, members)
    context.assets_verified = True
    return result
