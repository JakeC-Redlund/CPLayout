"""Constrain derived outputs to an explicitly selected, existing owner directory."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable


class OutputPathError(ValueError):
    """The output would escape its owner or overwrite a source."""


def safe_output_path(output_root: Path, requested: Path, protected_inputs: Iterable[Path] = ()) -> Path:
    """Resolve a relative output name inside output_root without writing anything.

    The root must already exist so a typo cannot silently create an output tree.
    Existing symlinks are resolved, including a symlink at the final target.
    """
    root = Path(output_root)
    name = Path(requested)
    if not root.is_dir():
        raise OutputPathError("output_root_not_found")
    if name.is_absolute() or not name.parts or any(part in ("", ".", "..") for part in name.parts):
        raise OutputPathError("output_path_invalid")
    canonical_root = root.resolve(strict=True)
    target = (canonical_root / name).resolve(strict=False)
    if not target.is_relative_to(canonical_root) or target == canonical_root:
        raise OutputPathError("output_path_outside_root")
    if target.exists() and not target.is_file():
        raise OutputPathError("output_path_not_file")
    for source in protected_inputs:
        source_path = Path(source).resolve(strict=False)
        if target == source_path or (target.exists() and source_path.exists() and target.samefile(source_path)):
            raise OutputPathError("output_overwrites_source")
    return target
