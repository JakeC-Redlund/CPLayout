"""Optional, explicitly sourced telemetry. Unknown is null, never zero."""
from __future__ import annotations

import ctypes
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys


def is_wsl() -> bool:
    return sys.platform == "linux" and "microsoft" in platform.release().lower()


def windows_available_bytes() -> int | None:
    if os.name == "nt":
        class MemoryStatus(ctypes.Structure):
            _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong)] + [
                (key, ctypes.c_ulonglong) for key in (
                    "total_physical", "available_physical", "total_page", "available_page",
                    "total_virtual", "available_virtual", "extended")]
        value = MemoryStatus()
        value.length = ctypes.sizeof(value)
        return int(value.available_physical) if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(value)) else None
    if is_wsl():
        executable = shutil.which("powershell.exe")
        if executable:
            try:
                result = subprocess.run([executable, "-NoProfile", "-NonInteractive", "-Command",
                    "[string]((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory * 1024)"],
                    capture_output=True, text=True, timeout=8, check=True)
                return int(result.stdout.strip())
            except (OSError, ValueError, subprocess.SubprocessError):
                pass
    return None


def memory_snapshot(*, host=True) -> dict:
    result = {"rss_bytes": None, "peak_rss_bytes": None, "available_bytes": None,
              "windows_available_bytes": None, "source": None,
              "windows_source": None, "units": "bytes"}
    if sys.platform == "linux":
        try:
            info = {line.split(":", 1)[0]: int(line.split()[1]) * 1024
                    for line in Path("/proc/meminfo").read_text().splitlines() if ":" in line}
            status = {line.split(":", 1)[0]: int(line.split()[1]) * 1024
                      for line in Path("/proc/self/status").read_text().splitlines()
                      if line.startswith(("VmRSS:", "VmHWM:"))}
            result.update(rss_bytes=status.get("VmRSS"), peak_rss_bytes=status.get("VmHWM"),
                          available_bytes=info.get("MemAvailable"), source="linux-procfs")
        except (OSError, ValueError, IndexError):
            pass
    elif os.name == "nt":
        from ctypes import wintypes
        class ProcessMemory(ctypes.Structure):
            _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD)] + [
                (key, ctypes.c_size_t) for key in ("PeakWorkingSetSize", "WorkingSetSize",
                    "QuotaPeakPagedPoolUsage", "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage",
                    "QuotaNonPagedPoolUsage", "PagefileUsage", "PeakPagefileUsage")]
        value = ProcessMemory()
        value.cb = ctypes.sizeof(value)
        kernel = ctypes.windll.kernel32
        kernel.GetCurrentProcess.restype = wintypes.HANDLE
        psapi = ctypes.windll.psapi
        psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD]
        if psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(value), value.cb):
            result.update(rss_bytes=int(value.WorkingSetSize), peak_rss_bytes=int(value.PeakWorkingSetSize),
                          source="windows-process-memory-counters")
        result["available_bytes"] = windows_available_bytes()
    else:
        try:
            import resource
            peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            result.update(peak_rss_bytes=int(peak if sys.platform == "darwin" else peak * 1024),
                          source="getrusage-peak-only")
        except ImportError:
            pass
    if host and (is_wsl() or os.name == "nt"):
        result["windows_available_bytes"] = windows_available_bytes()
        result["windows_source"] = "GlobalMemoryStatusEx" if os.name == "nt" else "Windows-CIM-via-WSL"
    return result


def gpu_snapshot() -> dict:
    result = {"source": "nvidia-smi", "devices": [], "status": "unknown"}
    executable = shutil.which("nvidia-smi")
    if not executable:
        return result
    try:
        response = subprocess.run([executable,
            "--query-gpu=index,uuid,name,driver_version,memory.total,memory.free,memory.used",
            "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=5, check=True)
        for line in response.stdout.strip().splitlines():
            index, uuid, name, driver, total, free, used = [p.strip() for p in line.split(",")]
            result["devices"].append({"index": int(index), "uuid": uuid, "name": name,
                "driver_version": driver, "total_bytes": int(total) * 1024**2,
                "free_bytes": int(free) * 1024**2, "used_bytes": int(used) * 1024**2})
        result["status"] = "observed" if result["devices"] else "unknown"
    except (OSError, ValueError, subprocess.SubprocessError):
        pass
    return result
