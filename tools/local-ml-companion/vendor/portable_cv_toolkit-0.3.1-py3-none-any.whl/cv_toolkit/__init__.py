"""Offline, dependency-free CV evidence contracts and path safeguards."""

from .manifest import (
    SCHEMA_VERSION,
    ManifestError,
    build_run_manifest,
    load_run_manifest,
    verify_run_manifest,
)
from .paths import safe_output_path

__all__ = [
    "SCHEMA_VERSION",
    "ManifestError",
    "build_run_manifest",
    "load_run_manifest",
    "verify_run_manifest",
    "safe_output_path",
]
