"""Closed v1/v2 job contracts. No optional model package is imported here."""
from __future__ import annotations

import json
import math
from pathlib import Path
import re

from .artifacts import json_sha256, sha256_file, valid_sha256
from .bundles import validate_member, validate_bundle_files, MAX_BUNDLE_BYTES
from .profiles import V2_PROFILE

GIB = 1024**3
DEFAULT_LIMITS = {"gpu_budget_bytes": int(5.5 * GIB), "gpu_reserve_bytes": int(1.5 * GIB),
                  "rss_budget_bytes": 4 * GIB, "available_ram_bytes": 2 * GIB,
                  "cpu_threads": 4, "deadline_seconds": 900, "cancel_grace_seconds": 30,
                  "max_asset_bytes": 2 * GIB, "max_pixels": 16_000_000}
PROFILE = {"id": "torch-cu130-v1", "python": "3.12", "torch": "2.12.1+cu130",
           "torchvision": "0.27.1+cu130", "cuda": "13.0", "torchaudio_required": False}


class JobError(ValueError):
    pass


def _number(value, low, high, integer=False):
    return type(value) in ((int,) if integer else (int, float)) and low <= value <= high and math.isfinite(value)


def validate_job(value: object, *, verify_assets=True, output_may_exist=False) -> dict:
    if not isinstance(value, dict) or value.get("schema_version") not in ("CVJob-v1", "CVJob-v2"):
        raise JobError("job_schema_invalid")
    v2 = value["schema_version"] == "CVJob-v2"
    allowed = {"schema_version", "job_id", "kind", "adapter", "device", "output_root", "assets",
               "input_classification", "configuration", "limits", "cancel_file", "predecessor_sha256"}
    if v2:
        allowed.add("runtime_profile")
        if value.get("runtime_profile") != V2_PROFILE:
            raise JobError("runtime_profile_invalid")
    if set(value) - allowed:
        raise JobError("job_fields_unknown")
    if not isinstance(value.get("job_id"), str) or not re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,63}", value["job_id"]):
        raise JobError("job_id_invalid")
    combinations = ({("inference", name) for name in ("ppocr-image", "ppocr-pdf", "ppocr-video",
                    "grounding-dino-image", "grounding-dino-pdf", "grounding-dino-video-track")} if v2 else {
            ("training", "mobilenet-smoke"), ("inference", "sam2-image"), ("inference", "sam2-video")})
    if not isinstance(value.get("kind"), str) or not isinstance(value.get("adapter"), str) or (value["kind"], value["adapter"]) not in combinations:
        raise JobError("adapter_kind_invalid")
    if not isinstance(value.get("device"), str) or value["device"] not in {"cpu", "cuda"}:
        raise JobError("device_invalid")
    if not isinstance(value.get("input_classification"), str) or value["input_classification"] not in {"synthetic", "public-licensed", "approved-redacted"}:
        raise JobError("input_classification_invalid")
    if not isinstance(value.get("output_root"), str) or not Path(value["output_root"]).is_absolute():
        raise JobError("output_root_absolute_required")
    root = Path(value["output_root"]).resolve()
    if not root.is_dir():
        raise JobError("output_root_not_found")
    if not output_may_exist and (root / value["job_id"]).exists():
        raise JobError("job_output_exists")
    supplied = value.get("limits", {})
    if not isinstance(supplied, dict) or set(supplied) - set(DEFAULT_LIMITS):
        raise JobError("limits_invalid")
    limits = {**DEFAULT_LIMITS, **supplied}
    for name, item in limits.items():
        high = 86400 if name == "deadline_seconds" else 120 if name == "cancel_grace_seconds" else 8 if name == "cpu_threads" else 64 * GIB
        if not _number(item, 1, high, integer=name not in {"deadline_seconds", "cancel_grace_seconds"}):
            raise JobError("limit_invalid:" + name)
        if name in {"gpu_budget_bytes", "rss_budget_bytes", "cpu_threads", "max_asset_bytes", "max_pixels"} and item > DEFAULT_LIMITS[name]:
            raise JobError("profile_limit_cannot_increase:" + name)
        if name in {"gpu_reserve_bytes", "available_ram_bytes"} and item < DEFAULT_LIMITS[name]:
            raise JobError("profile_reserve_cannot_decrease:" + name)
    assets = value.get("assets", [])
    if not isinstance(assets, list) or len(assets) > (128 if v2 else 64):
        raise JobError("assets_invalid")
    ids, roles = set(), set()
    for asset in assets:
        expected_fields = {"id", "path", "sha256", "role"}
        if isinstance(asset, dict) and v2 and asset.get("role") == "model":
            expected_fields |= {"bundle", "relative_path"}
        if not isinstance(asset, dict) or set(asset) != expected_fields:
            raise JobError("asset_fields_invalid")
        if not isinstance(asset["id"], str) or not re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,63}", asset["id"]) or asset["id"] in ids:
            raise JobError("asset_id_invalid")
        ids.add(asset["id"])
        allowed_roles = {"image", "pdf", "video", "model"} if v2 else {"image", "frame", "checkpoint", "config", "resume", "comparison"}
        if not isinstance(asset["role"], str) or asset["role"] not in allowed_roles or (asset["role"] in roles and asset["role"] not in {"frame", "model"}):
            raise JobError("asset_role_invalid_or_duplicate")
        roles.add(asset["role"])
        if asset["role"] == "model":
            try:
                validate_member(asset)
            except ValueError as error:
                raise JobError(str(error)) from error
        if not isinstance(asset["path"], str) or not Path(asset["path"]).is_absolute() or not valid_sha256(asset["sha256"]):
            raise JobError("asset_identity_invalid")
        path = Path(asset["path"]).resolve()
        if path.is_relative_to(root / value["job_id"]):
            raise JobError("output_contains_source")
        if verify_assets:
            if not path.is_file():
                raise JobError("asset_missing:" + asset["id"])
            if path.stat().st_size > limits["max_asset_bytes"]:
                raise JobError("asset_oversized:" + asset["id"])
            if sha256_file(path) != asset["sha256"]:
                raise JobError("asset_hash_mismatch:" + asset["id"])
    config = value.get("configuration", {})
    if not isinstance(config, dict):
        raise JobError("configuration_invalid")
    if v2:
        config = _normalize_v2_config(value["adapter"], config, assets)
        allowed_config = set(config)
        try:
            validate_bundle_files(assets)
        except ValueError as error:
            raise JobError(str(error)) from error
        if verify_assets and sum(Path(row["path"]).stat().st_size for row in assets if row["role"] == "model") > MAX_BUNDLE_BYTES:
            raise JobError("bundle_total_bytes_exceeded")
    elif value["adapter"] == "mobilenet-smoke":
        allowed_config = {"steps", "seed", "image_size", "num_classes", "precision", "learning_rate",
                          "checkpoint_interval", "stop_after", "compile", "channels_last"}
        config = {"steps": 100, "seed": 42, "image_size": 64, "num_classes": 4,
                  "precision": "fp32", "learning_rate": 0.01, "checkpoint_interval": 10,
                  "compile": False, "channels_last": False, **config}
        if roles - {"resume", "comparison"} or value["input_classification"] != "synthetic":
            raise JobError("training_smoke_requires_synthetic_and_checkpoint_assets_only")
        for name, bounds in {"steps": (1, 1000), "seed": (0, 2**31 - 1), "image_size": (32, 512),
                             "num_classes": (2, 1000), "checkpoint_interval": (1, 1000), "stop_after": (1, 1000)}.items():
            if name in config and not _number(config[name], *bounds, integer=True):
                raise JobError("configuration_invalid:" + name)
        if config["image_size"] % 32 or not _number(config["learning_rate"], 1e-8, 1):
            raise JobError("training_configuration_invalid")
        if any(type(config[name]) is not bool for name in ("compile", "channels_last")):
            raise JobError("training_flags_invalid")
    else:
        allowed_config = {"precision", "points", "labels", "model_revision", "config_name", "warmup_steps", "measurement_runs", "frame_ids"}
        config = {"precision": "fp32", "config_name": "configs/sam2.1/sam2.1_hiera_t.yaml",
                  "warmup_steps": 1, "measurement_runs": 5, **config}
        if roles != ({"image", "checkpoint", "config"} if value["adapter"] == "sam2-image" else {"frame", "checkpoint", "config"}):
            raise JobError("sam2_requires_image_checkpoint_config")
        if not _number(config["warmup_steps"], 0, 10, integer=True) or not _number(config["measurement_runs"], 1, 100, integer=True):
            raise JobError("sam2_measurement_counts_invalid")
        if value["adapter"] == "sam2-video":
            frame_ids = config.get("frame_ids")
            actual_ids = {row["id"] for row in assets if row["role"] == "frame"}
            if not isinstance(frame_ids, list) or not 2 <= len(frame_ids) <= 16 or any(not isinstance(x, str) for x in frame_ids) or len(set(frame_ids)) != len(frame_ids) or set(frame_ids) != actual_ids:
                raise JobError("video_frame_ids_invalid")
        elif "frame_ids" in config:
            raise JobError("image_job_frame_ids_invalid")
        if config["config_name"] != "configs/sam2.1/sam2.1_hiera_t.yaml":
            raise JobError("sam2_tiny_config_required")
        if not isinstance(config.get("model_revision"), str) or not config["model_revision"].strip():
            raise JobError("model_revision_required")
        points, labels = config.get("points"), config.get("labels")
        if not isinstance(points, list) or not 1 <= len(points) <= 256 or not isinstance(labels, list) or len(labels) != len(points):
            raise JobError("sam2_points_invalid")
        if any(not isinstance(point, list) or len(point) != 2 or any(not _number(x, 0, 1_000_000) for x in point) for point in points):
            raise JobError("sam2_points_invalid")
        if any(type(label) is not int or label not in (0, 1) for label in labels):
            raise JobError("sam2_labels_invalid")
    if set(config) - allowed_config or not isinstance(config["precision"], str) or config["precision"] not in {"fp32", "fp16", "bf16"}:
        raise JobError("configuration_fields_or_precision_invalid")
    if value["device"] == "cpu" and config["precision"] != "fp32":
        raise JobError("cpu_profile_requires_fp32")
    if value.get("predecessor_sha256") is not None and not valid_sha256(value["predecessor_sha256"]):
        raise JobError("predecessor_invalid")
    cancel = value.get("cancel_file")
    if cancel is not None and (not isinstance(cancel, str) or not Path(cancel).is_absolute()):
        raise JobError("cancel_file_absolute_required")
    if cancel and Path(cancel).resolve().is_relative_to(root / value["job_id"]):
        raise JobError("cancel_file_must_be_outside_job_outputs")
    result = {**value, "assets": assets, "output_root": str(root), "configuration": config, "limits": limits}
    try:
        return json.loads(json.dumps(result, allow_nan=False))
    except (ValueError, TypeError) as error:
        raise JobError("job_json_invalid") from error


def _normalize_v2_config(adapter: str, supplied: dict, assets: list[dict]) -> dict:
    detector = adapter.startswith("grounding-dino-")
    medium = "video" if "video" in adapter else "pdf" if adapter.endswith("pdf") else "image"
    expected_bundles = {"detector"} if detector else {"ocr-det", "ocr-rec"}
    bundles = {row["bundle"] for row in assets if row["role"] == "model"}
    if bundles != expected_bundles or [row["role"] for row in assets if row["role"] != "model"] != [medium]:
        raise JobError("adapter_assets_invalid")
    defaults = {"precision": "fp32", "max_side": 1536}
    allowed = {"precision", "model_revisions", "max_side"}
    ranges = {"max_side": (32, 1536, True)}
    if medium == "image":
        defaults.update(warmup_steps=1, measurement_runs=5)
        ranges.update(warmup_steps=(0, 10, True), measurement_runs=(1, 100, True))
    elif medium == "pdf":
        defaults["dpi"] = 200
        allowed.add("pages")
        ranges["dpi"] = (72, 300, True)
    else:
        defaults.update(stream_index=0, clip_start_seconds=0, clip_duration_seconds=10,
                        frame_policy="every-frame", max_frames=900, max_width=1920, max_height=1080)
        ranges.update(stream_index=(0, 64, True), clip_start_seconds=(0, 86400, False),
            clip_duration_seconds=(0.001, 30, False), max_frames=(1, 900, True),
            max_width=(1, 1920, True), max_height=(1, 1080, True))
    if detector:
        defaults.update(threshold=.25, text_threshold=.25, max_detections=200)
        allowed.add("queries")
        ranges.update(threshold=(0, 1, False), text_threshold=(0, 1, False), max_detections=(1, 200, True))
        if medium == "video":
            defaults.update(low_threshold=.1, high_threshold=.3, activation_threshold=.35,
                            iou_threshold=.3, min_consecutive_frames=2, lost_buffer_seconds=.5)
            ranges.update(low_threshold=(0, 1, False), high_threshold=(0, 1, False), activation_threshold=(0, 1, False),
                iou_threshold=(0, 1, False), min_consecutive_frames=(1, 30, True), lost_buffer_seconds=(0, 2, False))
    else:
        defaults["max_regions"] = 128
        ranges["max_regions"] = (1, 128, True)
    allowed |= set(defaults)
    if set(supplied) - allowed:
        raise JobError("configuration_fields_unknown")
    config = {**defaults, **supplied}
    for name, (minimum, maximum, integer) in ranges.items():
        if not _number(config[name], minimum, maximum, integer=integer):
            raise JobError("configuration_invalid:" + name)
    revisions = config.get("model_revisions")
    if not isinstance(revisions, dict) or set(revisions) != expected_bundles or any(
            not isinstance(revision, str) or not re.fullmatch(r"[0-9a-f]{40}", revision) for revision in revisions.values()):
        raise JobError("model_revisions_invalid")
    if medium == "pdf":
        pages = config.get("pages")
        if not isinstance(pages, list) or not 1 <= len(pages) <= 20 or any(not _number(page, 1, 100000, integer=True) for page in pages) or pages != sorted(set(pages)):
            raise JobError("pdf_pages_invalid")
    if medium == "video" and config["frame_policy"] != "every-frame":
        raise JobError("video_every_frame_required")
    if detector:
        queries, ids = config.get("queries"), set()
        if not isinstance(queries, list) or not 1 <= len(queries) <= 16:
            raise JobError("queries_invalid")
        for query in queries:
            if not isinstance(query, dict) or set(query) != {"id", "text"} or not isinstance(query["id"], str) or not re.fullmatch(r"[a-z0-9][a-z0-9_-]{0,63}", query["id"]) or query["id"] in ids:
                raise JobError("query_identity_invalid")
            ids.add(query["id"])
            if not isinstance(query["text"], str) or not 1 <= len(query["text"].strip()) <= 200 or any(ord(char) < 32 for char in query["text"]):
                raise JobError("query_text_invalid")
        if medium == "video" and not config["low_threshold"] <= config["high_threshold"] <= config["activation_threshold"]:
            raise JobError("tracking_threshold_order_invalid")
    return config


def training_identity(job: dict) -> str:
    """Resume identity intentionally excludes total/stop steps and output path."""
    configuration = {key: value for key, value in job["configuration"].items()
                     if key not in {"steps", "checkpoint_interval", "stop_after"}}
    return json_sha256({"adapter": job["adapter"], "device": job["device"], "configuration": configuration,
                        "synthetic_generator": "per-step-torch-cpu-rng-v1", "profile": PROFILE,
                        "source_sha256": source_identity()["sha256"]})


def source_identity() -> dict:
    root = Path(__file__).resolve().parent
    names = ("adapters.py", "artifacts.py", "jobs.py", "lease.py", "runtime.py", "telemetry.py", "paths.py",
             "bundles.py", "profiles.py", "storage.py", "vision_adapters.py", "media.py", "tracking.py")
    files = {name: sha256_file(root / name) for name in names}
    return {"sha256": json_sha256(files), "files": files}
