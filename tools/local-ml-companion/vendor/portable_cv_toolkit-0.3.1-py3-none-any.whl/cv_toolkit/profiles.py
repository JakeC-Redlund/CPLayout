"""Host-owned runtime selection; jobs never supply Python paths or commands."""
from __future__ import annotations

import json
import os
from pathlib import Path
import stat
import sys

from .artifacts import sha256_file, valid_sha256
from .storage import validate_storage, validate_storage_path, validate_storage_paths, child_environment, StorageUnavailable

REGISTRY_VERSION = "CVRuntimeRegistry-v1"
V2_PROFILE = "torch-transformers-cu130-v1"


class ProfileError(ValueError):
    pass


def profile_for_job(job: dict) -> dict:
    """Return fixed core versions; full environment locks stay host-owned."""
    return {"id": job.get("runtime_profile", "torch-cu130-v1"), "python": "3.12",
            "torch": "2.12.1+cu130", "torchvision": "0.27.1+cu130", "cuda": "13.0"}


def resolve_runtime(job: dict, *, registry_path: Path | None = None) -> dict:
    if job["schema_version"] == "CVJob-v1":
        return {"id": "torch-cu130-v1", "python": sys.executable, "registry_sha256": None,
                "python_sha256": sha256_file(Path(sys.executable))}
    if job.get("runtime_profile") != V2_PROFILE:
        raise ProfileError("runtime_profile_unknown")
    path = registry_path or Path(os.environ.get("CV_TOOLKIT_PROFILE_REGISTRY",
                                str(Path.home() / ".local/share/cv-toolkit/runtime-registry.json")))
    if not path.is_absolute() or path.is_symlink() or not path.is_file() or path.stat().st_size > 65536:
        raise ProfileError("runtime_registry_missing_or_invalid")
    metadata = path.stat()
    if os.name == "posix" and (metadata.st_uid != os.getuid() or metadata.st_mode & 0o022):
        raise ProfileError("runtime_registry_owner_or_permissions_invalid")
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or set(value) != {"schema_version", "profiles"} or value["schema_version"] != REGISTRY_VERSION or not isinstance(value["profiles"], dict):
        raise ProfileError("runtime_registry_schema_invalid")
    entry = value["profiles"].get(V2_PROFILE)
    if not isinstance(entry, dict) or set(entry) != {"python", "python_sha256", "storage_binding"}:
        raise ProfileError("runtime_registry_profile_invalid")
    if not isinstance(entry["python"], str) or not Path(entry["python"]).is_absolute() or not valid_sha256(entry["python_sha256"]):
        raise ProfileError("runtime_registry_python_invalid")
    executable = Path(entry["python"])
    binding_path = entry["storage_binding"]
    if not isinstance(binding_path, str) or not Path(binding_path).is_absolute():
        raise ProfileError("runtime_storage_binding_invalid")
    try:
        storage = validate_storage(binding_path)
    except StorageUnavailable as error:
        raise ProfileError("runtime_storage_unavailable:" + str(error)) from error
    data_root = Path(storage["binding"]["dataRoot"])
    # The venv's bin directory must be on the admitted volume. Its Python
    # executable may legitimately symlink to the system interpreter.
    if not executable.parent.resolve().is_relative_to(data_root):
        raise ProfileError("runtime_python_outside_storage")
    try:
        validate_storage_path(binding_path, executable.parent)
    except StorageUnavailable as error:
        raise ProfileError("runtime_storage_unavailable:" + str(error)) from error
    if not executable.is_file() or not os.access(executable, os.X_OK) or sha256_file(executable) != entry["python_sha256"]:
        raise ProfileError("runtime_registry_python_missing_or_changed")
    return {"id": V2_PROFILE, "python": str(executable), "python_sha256": entry["python_sha256"],
            "registry_sha256": sha256_file(path), "storage_binding": binding_path,
            "storage_binding_sha256": sha256_file(Path(binding_path)), "data_root": str(data_root),
            "storage_status": "admitted"}


def validate_job_storage(job: dict, selected: dict) -> None:
    """Large mutable outputs and model assets belong to the admitted volume."""
    if job["schema_version"] != "CVJob-v2":
        return
    root = Path(selected["data_root"])
    if not Path(job["output_root"]).resolve().is_relative_to(root):
        raise ProfileError("runtime_output_outside_storage")
    for row in job["assets"]:
        if row["role"] == "model" and not Path(row["path"]).resolve().is_relative_to(root):
            raise ProfileError("runtime_model_outside_storage")
    paths = [Path(job["output_root"]), Path(job["output_root"]) / job["job_id"]]
    paths.extend(Path(row["path"]) for row in job["assets"] if row["role"] == "model")
    try:
        validate_storage_paths(selected["storage_binding"], paths)
    except StorageUnavailable as error:
        raise ProfileError("runtime_storage_unavailable:" + str(error)) from error


def validate_runtime_path(selected: dict, path: Path) -> None:
    if "storage_binding" not in selected:
        return
    try:
        validate_storage_path(selected["storage_binding"], path)
    except StorageUnavailable as error:
        raise ProfileError("runtime_storage_unavailable:" + str(error)) from error


def runtime_environment(selected: dict, base_env: dict) -> dict:
    if "storage_binding" not in selected:
        return dict(base_env)
    try:
        # Recheck immediately before child launch; never create an unmounted
        # directory or silently send caches back to the system drive.
        report = validate_storage(selected["storage_binding"])
        if sha256_file(Path(selected["storage_binding"])) != selected["storage_binding_sha256"]:
            raise ProfileError("runtime_storage_binding_changed")
        return child_environment(report["binding"], base_env=base_env, create=False,
                                 observation=report["mount"], capacity=report["capacity"])
    except StorageUnavailable as error:
        raise ProfileError("runtime_storage_unavailable:" + str(error)) from error


def resolve_profile_python(profile_id: str, registry_path: Path | None = None) -> Path:
    if not isinstance(profile_id, str) or profile_id != V2_PROFILE:
        raise ProfileError("runtime_profile_unknown")
    return Path(resolve_runtime({"schema_version": "CVJob-v2", "runtime_profile": profile_id},
                                registry_path=registry_path)["python"])
