"""Bounded media preview worker. Never accepts a path from browser requests."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from .artifacts import sha256_file
from .review_schema import ReviewError, integer

EXTENSIONS = {".png": "image", ".jpg": "image", ".jpeg": "image", ".webp": "image", ".bmp": "image",
              ".pdf": "pdf", ".mp4": "video", ".mov": "video", ".mkv": "video", ".webm": "video", ".avi": "video"}
MAX_PIXELS = 16_000_000


def media_kind(path):
    try:
        return EXTENSIONS[Path(path).suffix.lower()]
    except KeyError as exc:
        raise ReviewError("unsupported_media_extension") from exc


def _dimensions(width, height):
    if width <= 0 or height <= 0 or width * height > MAX_PIXELS:
        raise ReviewError("media_dimensions_exceed_limit")


def _image(path):
    from PIL import Image, ImageOps
    Image.MAX_IMAGE_PIXELS = MAX_PIXELS
    image = Image.open(path)
    _dimensions(*image.size)
    image.load()
    result = ImageOps.exif_transpose(image).convert("RGB")
    image.close()
    return result


def inspect(path):
    path = Path(path)
    kind = media_kind(path)
    if kind == "image":
        with _image(path) as image:
            return {"kind": kind, "width": image.width, "height": image.height, "units": 1, "unit": "image"}
    if kind == "pdf":
        import pypdfium2 as pdfium
        document = pdfium.PdfDocument(path)
        try:
            if not 1 <= len(document) <= 10000:
                raise ReviewError("pdf_page_count_exceeds_limit")
            page = document[0]
            try:
                width, height = page.get_size()
            finally:
                page.close()
            return {"kind": kind, "width": width, "height": height, "units": len(document), "unit": "page"}
        finally:
            document.close()
    import av
    from .media import VIDEO_OPEN_OPTIONS, VIDEO_FORMATS
    with av.open(str(path), options=VIDEO_OPEN_OPTIONS) as container:
        if not set(container.format.name.split(",")) <= VIDEO_FORMATS:
            raise ReviewError("video_container_not_admitted")
        stream = next((stream for stream in container.streams if stream.type == "video"), None)
        if stream is None:
            raise ReviewError("video_stream_missing")
        _dimensions(stream.width, stream.height)
        rate = float(stream.average_rate) if stream.average_rate else None
        duration = float(stream.duration * stream.time_base) if stream.duration is not None else None
        return {"kind": kind, "width": stream.width, "height": stream.height,
                "units": stream.frames or None, "unit": "frame", "duration_seconds": duration,
                "frames_per_second": rate, "frame_count_verified": False}


def preview(path, output, index=0, video_configuration=None):
    path, output = Path(path), Path(output)
    kind = media_kind(path)
    integer(index, 0, 10000)
    metadata = {"kind": kind, "index": index}
    if kind == "image":
        if index:
            raise ReviewError("image_index_must_be_zero")
        image = _image(path)
    elif kind == "pdf":
        import pypdfium2 as pdfium
        document = pdfium.PdfDocument(path)
        try:
            if index >= len(document):
                raise ReviewError("page_out_of_range")
            page = document[index]
            try:
                width, height = page.get_size()
                scale = min(2.0, (MAX_PIXELS / max(width * height, 1)) ** .5)
                bitmap = page.render(scale=scale)
                try:
                    image = bitmap.to_pil().convert("RGB")
                finally:
                    bitmap.close()
            finally:
                page.close()
        finally:
            document.close()
    else:
        from .media import VideoSelection, iter_video_frames
        if index >= 900:
            raise ReviewError("preview_frame_limit_900")
        image = None
        selection = VideoSelection.from_config(video_configuration or {"clip_start_seconds": 0, "clip_duration_seconds": 30})
        frames = iter_video_frames(path, selection)
        try:
            for frame_image, row in frames:
                if row["ordinal"] == index:
                    image = frame_image.copy()
                    metadata.update(timestamp_seconds=row["timestamp_seconds"], pts=row["pts"],
                                    frame_count_verified=False, pixel_sha256=row["pixel_sha256"])
                    frame_image.close()
                    break
                frame_image.close()
        finally:
            frames.close()
        if image is None:
            raise ReviewError("frame_out_of_range")
    try:
        _dimensions(image.width, image.height)
        metadata.update(source_width=image.width, source_height=image.height)
        image.thumbnail((1600, 1600))
        image.save(output, format="PNG")
        metadata.update(width=image.width, height=image.height, sha256=sha256_file(output))
        return metadata
    finally:
        image.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("inspect", "preview"))
    parser.add_argument("request", type=Path)
    args = parser.parse_args(argv)
    try:
        if sys.platform.startswith("linux"):
            import resource
            resource.setrlimit(resource.RLIMIT_AS, (4 * 1024**3, 4 * 1024**3))
            resource.setrlimit(resource.RLIMIT_CPU, (25, 25))
        if args.request.stat().st_size > 65536:
            raise ReviewError("preview_request_oversized")
        request = json.loads(args.request.read_text())
        source = Path(request["path"])
        if source.stat().st_size > 128 * 1024 * 1024 or sha256_file(source) != request["sha256"]:
            raise ReviewError("source_changed_or_oversized")
        result = inspect(source) if args.operation == "inspect" else preview(source, Path(request["output"]), request.get("index", 0), request.get("video_configuration"))
        if sha256_file(source) != request["sha256"]:
            raise ReviewError("source_changed_during_preview")
        print(json.dumps({"status": "completed", **result}, allow_nan=False))
        return 0
    except Exception as error:
        print(json.dumps({"status": "failed", "error": type(error).__name__}))
        return 2


if __name__ == "__main__":
    sys.exit(main())
