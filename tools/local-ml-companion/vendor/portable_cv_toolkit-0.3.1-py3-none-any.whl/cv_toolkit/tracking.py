"""Class-separated ByteTrack associations, never physical identity assertions."""
from __future__ import annotations

import math


class QueryTrackers:
    def __init__(self, job_id, queries, config, *, tracker_factory=None, detections_class=None):
        if tracker_factory is None:
            try:
                from trackers import ByteTrackTracker
            except (ImportError, OSError) as error:
                raise ImportError("bytetrack_runtime_unavailable") from error
            tracker_factory = ByteTrackTracker
        if detections_class is None:
            try:
                from supervision import Detections
            except (ImportError, OSError) as error:
                raise ImportError("supervision_runtime_unavailable") from error
            detections_class = Detections
        self.job_id = job_id
        self.detections_class = detections_class
        self.low = config.get("low_threshold", .1)
        self.instances = {q["id"]: tracker_factory(
            lost_track_buffer=math.ceil(config.get("lost_buffer_seconds", .5) * 30),
            frame_rate=30.0, track_activation_threshold=config.get("activation_threshold", .35),
            minimum_consecutive_frames=config.get("min_consecutive_frames", 2),
            minimum_iou_threshold=config.get("iou_threshold", .3),
            high_conf_det_threshold=config.get("high_threshold", .3)) for q in queries}
        self.last_timestamp = None

    def update(self, detections, timestamp):
        import numpy as np
        if not math.isfinite(timestamp) or (self.last_timestamp is not None and timestamp < self.last_timestamp):
            raise ValueError("tracking_timestamp_backwards_or_nonfinite")
        self.last_timestamp = timestamp
        output = [{**row, "track_id": None, "association": "provisional"} for row in detections]
        if any(row["query_id"] not in self.instances for row in output):
            raise ValueError("tracking_query_unknown")
        for query_id, tracker in self.instances.items():
            indices = [i for i, row in enumerate(output) if row["query_id"] == query_id and row["score"] >= self.low]
            detections = self.detections_class(
                xyxy=np.asarray([output[i]["box_xyxy"] for i in indices], dtype=float).reshape((-1, 4)),
                confidence=np.asarray([output[i]["score"] for i in indices], dtype=float),
                data={"source_index": np.asarray(indices, dtype=int)})
            tracked = tracker.update(detections, timestamp=timestamp)
            # Supervision data follows any library reorder, avoiding coordinate-
            # based guesses when duplicate boxes occur.
            if tracked.tracker_id is None:
                raise ValueError("tracker_ids_missing")
            for source_index, track_id in zip(tracked.data.get("source_index", []), tracked.tracker_id):
                index = int(source_index)
                if index not in indices:
                    raise ValueError("tracker_source_index_invalid")
                if int(track_id) >= 0:
                    output[index]["track_id"] = f"{self.job_id}:{query_id}:{int(track_id)}"
                    output[index]["association"] = "algorithmic"
        return output
