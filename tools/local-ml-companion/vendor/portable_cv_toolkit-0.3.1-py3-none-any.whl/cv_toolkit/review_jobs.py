"""Disk-acknowledged local review queue and owned subprocess lifecycle."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import copy
import csv
import hashlib
import html
import io
import json
import os
from pathlib import Path
import re
import secrets
import signal
import stat
import subprocess
import threading
import time
import uuid
import zipfile

from .artifacts import json_sha256, sha256_file
from .review_media import media_kind
from .review_schema import CLASSIFICATIONS, ReviewError, host_config, note_request, opaque_id, run_request, text

FINAL = {"completed", "checkpointed", "failed", "cancelled", "stopped", "readiness-gap", "invalid", "interrupted"}
RESOURCE_RELEASED = {"verified-stopped", "verified-not-started"}


def csv_literal(value):
    """All external text is literal, including whitespace/control formula prefixes."""
    return "'" + value if isinstance(value, str) else value


def write_state(path, value):
    """Mutable owner state, atomically replaced after fsync; artifacts stay immutable."""
    path = Path(path)
    temporary = path.with_name("." + path.name + "." + secrets.token_hex(8))
    try:
        with temporary.open("x", encoding="utf-8") as handle:
            json.dump(value, handle, sort_keys=True, indent=2, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
        if os.name == "posix":
            descriptor = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
    finally:
        temporary.unlink(missing_ok=True)


def resolve_python(profile, registry_path):
    """Host-only registry; browser requests cannot select a binary or registry."""
    from .profiles import resolve_profile_python
    return str(resolve_profile_python(profile, Path(registry_path)))


def _tagged_processes(token):
    if not Path("/proc/self/stat").is_file() or not token:
        return None
    marker = ("CV_REVIEW_OWNER_TOKEN=" + token).encode()
    found = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit():
            continue
        try:
            if marker not in (entry / "environ").read_bytes().split(b"\0"):
                continue
            fields = (entry / "stat").read_text().rsplit(")", 1)[1].split()
            if fields[0] != "Z":
                found.append((int(entry.name), fields[19]))
        except (OSError, IndexError):
            continue
    return found


def _signal_identity(identity, action):
    pid, started = identity
    try:
        fields = Path("/proc", str(pid), "stat").read_text().rsplit(")", 1)[1].split()
        if fields[19] == started and fields[0] != "Z":
            os.kill(pid, action)
    except (OSError, IndexError):
        pass


def stop_owned_process(child, *, timeout=10):
    """Close only tagged Linux descendants, checking PID/start again before signals."""
    token = getattr(child, "_review_token", None)
    owned = _tagged_processes(token)
    if owned is None:
        return "unknown"
    deadline = time.monotonic() + max(0, timeout)
    for action in (signal.SIGTERM, signal.SIGKILL):
        for identity in owned:
            _signal_identity(identity, action)
        phase_deadline = min(deadline, time.monotonic() + timeout / 2)
        while time.monotonic() < phase_deadline:
            child.poll()  # reap the direct child before checking remaining descendants
            owned = _tagged_processes(token)
            if not owned and child.poll() is not None:
                return "verified-stopped"
            time.sleep(.05)
    return "failed"


def process_anchor(pid):
    fields = Path("/proc", str(pid), "stat").read_text().rsplit(")", 1)[1].split()
    return {"pid": pid, "start": fields[19], "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip()}


class ReviewStore:
    def __init__(self, config, *, runner=None, resolver=resolve_python, media_runner=None, validator=None, storage_path_validator=None):
        self._storage_use = None
        try:
            self._initialize(config, runner=runner, resolver=resolver, media_runner=media_runner, validator=validator,
                             storage_path_validator=storage_path_validator)
        except BaseException:
            if hasattr(self, "executor"):
                self.executor.shutdown(wait=True, cancel_futures=True)
            if self._storage_use is not None:
                self._storage_use.__exit__(None, None, None)
                self._storage_use = None
            raise

    def _initialize(self, config, *, runner=None, resolver=resolve_python, media_runner=None, validator=None, storage_path_validator=None):
        self.config = host_config(config)
        validate_path = storage_path_validator or (lambda path: Path(path))
        validate_paths = lambda paths: [validate_path(path) for path in paths]
        # Admission precedes even mkdir: an absent mounted data volume must not
        # silently create an identically named directory on the internal drive.
        for profile in {self.config["preview_profile"], *(row["job_template"]["runtime_profile"] for row in self.config["models"])}:
            resolver(profile, self.config["runtime_registry"])
        if resolver is resolve_python:
            from .profiles import resolve_runtime
            selected = resolve_runtime({"schema_version": "CVJob-v2", "runtime_profile": self.config["preview_profile"]},
                                       registry_path=Path(self.config["runtime_registry"]))
            if not Path(self.config["state_root"]).resolve().is_relative_to(Path(selected["data_root"]).resolve()):
                raise ReviewError("review_state_outside_admitted_storage")
            from .storage import StorageUse, validate_storage_paths
            self._storage_use = StorageUse(selected["storage_binding"])
            self._storage_use.__enter__()
            validate_paths = lambda paths: validate_storage_paths(selected["storage_binding"], paths)
        self.root = Path(self.config["state_root"])
        directories = [self.root / name for name in ("records", "uploads", "requests", "runs", "cancel", "previews", "exports", "resources")]
        validate_paths([self.root, *directories])
        if self.root.is_symlink():
            raise ReviewError("state_root_symlink_forbidden")
        self.root.mkdir(mode=0o700, parents=True, exist_ok=True)
        for directory in directories:
            if directory.is_symlink():
                raise ReviewError("state_directory_symlink_forbidden")
            directory.mkdir(mode=0o700, exist_ok=True)
        validate_paths([self.root, *directories])
        self.lock = threading.RLock()
        self.media_lock = threading.Lock()
        self.executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="cv-review-job")
        self.runner, self.resolver, self.media_runner = runner, resolver, media_runner
        self.validator = validator
        self.records, self.sources, self.models = {}, {}, {row["id"]: row for row in self.config["models"]}
        self.children = {}
        self.futures = []
        self.resources = {}
        self.active_resource_ids = set()
        self.cleanup_results = []
        self.closing = False
        self.instance_id = uuid.uuid4().hex
        for file in (self.root / "resources").glob("*.json"):
            resource = json.loads(file.read_text())
            if opaque_id(resource["id"]) != file.stem:
                raise ReviewError("stored_resource_identity_invalid")
            self.resources[resource["id"]] = resource
        for row in self.config["sources"]:
            self._register_source(row)
        catalog = self.root / "uploads.json"
        if catalog.exists():
            for row in json.loads(catalog.read_text()):
                if not Path(row["path"]).resolve().is_relative_to(self.root / "uploads"):
                    raise ReviewError("stored_upload_path_invalid")
                self._register_source(row)
        for file in (self.root / "records").glob("*.json"):
            record = json.loads(file.read_text())
            opaque_id(record["id"])
            if file.stem != record["id"]:
                raise ReviewError("stored_job_identity_invalid")
            if record["status"] not in FINAL:
                record.update(status="interrupted", cleanup="unknown", error="server_restarted_no_process_ownership_assumed")
                write_state(file, record)
            resource = self.resources.get(record.get("resource_id"))
            if resource and resource.get("cleanup") in RESOURCE_RELEASED and record["status"] == "interrupted":
                record["cleanup"] = resource["cleanup"]
                write_state(file, record)
            self.records[record["id"]] = record

    def recovery_gaps(self):
        return [row["id"] for row in self.resources.values() if row.get("cleanup") not in RESOURCE_RELEASED and row["id"] not in self.active_resource_ids] + [
            row["id"] for row in self.records.values() if row["status"] == "interrupted" and row.get("cleanup") == "unknown" and not row.get("resource_id")]

    def _prepare_resource(self, role, job_id=None):
        resource = {"schema_version": "CVReviewProcessLease-v1", "id": "resource-" + uuid.uuid4().hex,
                    "owner_token": secrets.token_hex(32), "role": role, "job_id": job_id,
                    "launch_state": "prepared", "pid": None, "start": None, "boot_id": None,
                    "cleanup": "unknown", "created_at": time.time()}
        with self.lock:
            write_state(self.root / "resources" / (resource["id"] + ".json"), resource)
            self.resources[resource["id"]] = resource
            self.active_resource_ids.add(resource["id"])
            if job_id:
                self.records[job_id]["resource_id"] = resource["id"]
                self._persist(self.records[job_id])
        return resource

    def _spawn_resource(self, resource, *args, **kwargs):
        try:
            child = subprocess.Popen(*args, **kwargs)
        except (OSError, ValueError, TypeError) as error:
            # Popen's ordinary creation/exec failures do not return a live
            # child. Preserve that definitive outcome separately from a crash
            # or interruption in the launch/identity-recording window.
            resource.update(launch_state="failed-before-start", launch_error=type(error).__name__)
            self._resource_finished(resource, "verified-not-started")
            raise
        except BaseException:
            self._resource_finished(resource, "unknown")
            raise
        try:
            self._resource_launched(resource, child)
        except BaseException:
            cleanup = stop_owned_process(child, timeout=5)
            try:
                self._resource_finished(resource, cleanup)
            except OSError:
                pass
            raise
        return child

    def _resource_launched(self, resource, child):
        child._review_token = resource["owner_token"]
        child._review_resource_id = resource["id"]
        try:
            resource.update(process_anchor(child.pid), launch_state="started")
        except (OSError, IndexError):
            resource.update(pid=child.pid, launch_state="identity-unavailable")
        with self.lock:
            write_state(self.root / "resources" / (resource["id"] + ".json"), resource)

    def _resource_finished(self, resource, cleanup):
        with self.lock:
            self.active_resource_ids.discard(resource["id"])
            resource["cleanup"] = cleanup
            resource["finished_at"] = time.time()
            write_state(self.root / "resources" / (resource["id"] + ".json"), resource)
            if resource.get("job_id") in self.records:
                self.records[resource["job_id"]]["cleanup"] = cleanup

    def _register_source(self, row):
        path = Path(row["path"]).resolve(strict=True)
        if not path.is_file() or path.stat().st_size > self.config["max_upload_bytes"]:
            raise ReviewError("source_missing_or_oversized")
        identifier = opaque_id(row["id"])
        if identifier in self.sources:
            raise ReviewError("duplicate_source_id")
        digest = sha256_file(path)
        if row.get("sha256") and row["sha256"] != digest:
            raise ReviewError("stored_source_changed")
        self.sources[identifier] = {**row, "path": str(path), "kind": media_kind(path), "sha256": digest,
                                    "bytes": path.stat().st_size}

    def source(self, identifier):
        opaque_id(identifier)
        try:
            return self.sources[identifier]
        except KeyError as exc:
            raise ReviewError("source_not_found") from exc

    def source_catalog(self):
        return [{key: row[key] for key in ("id", "label", "kind", "sha256", "bytes", "input_classification")}
                for row in self.sources.values()]

    def model_catalog(self):
        return [{"id": row["id"], "label": row["label"], "adapter": row["job_template"]["adapter"],
                 "runtime_profile": row["job_template"]["runtime_profile"],
                 "device": row["job_template"]["device"]} for row in self.models.values()]

    def add_upload(self, path, label, classification):
        if classification not in CLASSIFICATIONS or not Path(path).resolve().is_relative_to(self.root / "uploads"):
            raise ReviewError("upload_identity_invalid")
        row = {"id": "source-" + uuid.uuid4().hex, "label": text(label), "path": str(path),
               "input_classification": classification, "uploaded": True}
        with self.lock:
            if len(self.sources) >= 128:
                raise ReviewError("source_catalog_full")
            self._register_source(row)
            write_state(self.root / "uploads.json", [row for row in self.sources.values() if row.get("uploaded")])
            return next(item for item in self.source_catalog() if item["id"] == row["id"])

    def _persist(self, record):
        write_state(self.root / "records" / (record["id"] + ".json"), record)

    def submit(self, value):
        request = run_request(value)
        with self.lock:
            if self.closing:
                raise ReviewError("server_stopping")
            if self.recovery_gaps():
                raise ReviewError("owned_resource_recovery_required")
            if sum(row["status"] not in FINAL for row in self.records.values()) >= self.config["max_queue"]:
                raise ReviewError("queue_full")
            source = self.source(request["source_id"])
            model = self.models.get(request["model_id"])
            if model is None:
                raise ReviewError("model_not_found")
            job = copy.deepcopy(model["job_template"])
            suffix = {"image": "image", "pdf": "pdf", "video": "video"}[source["kind"]]
            if not (job["adapter"].endswith("-" + suffix) or suffix == "video" and job["adapter"].endswith("-video-track")):
                raise ReviewError("model_source_kind_mismatch")
            if sha256_file(Path(source["path"])) != source["sha256"]:
                raise ReviewError("source_changed")
            identifier = "review-" + uuid.uuid4().hex
            job.update(job_id=identifier, output_root=str(self.root / "runs"),
                       cancel_file=str(self.root / "cancel" / identifier), input_classification=source["input_classification"])
            job["assets"] = [*job.get("assets", []), {"id": source["id"], "path": source["path"],
                                                       "sha256": source["sha256"], "role": source["kind"]}]
            configuration = job.setdefault("configuration", {})
            for key in ("pages", "clip_start_seconds", "clip_duration_seconds", "queries"):
                if key in request:
                    configuration[key] = request[key]
            if source["kind"] == "video":
                configuration["frame_policy"] = "every-frame"
            if self.validator:
                self.validator(job)
            else:
                from .jobs import validate_job
                validate_job(job)
            executable = self.resolver(job["runtime_profile"], self.config["runtime_registry"])
            request_path = self.root / "requests" / (identifier + ".json")
            write_state(request_path, job)
            record = {"id": identifier, "source_id": source["id"], "source_sha256": source["sha256"],
                      "model_id": model["id"], "status": "queued", "created_at": time.time(),
                      "notes": [], "note_revision": 0, "cleanup": "not-started", "artifacts": [],
                      "authorship_verified": False}
            self._persist(record)
            self.records[identifier] = record
            self.futures.append(self.executor.submit(self._execute, identifier, job, executable))
            return self.public_record(record)

    def _execute(self, identifier, job, executable):
        with self.lock:
            record = self.records[identifier]
            if record["status"] == "cancelled" or self.closing:
                record.update(status="cancelled", cleanup="not-started")
                self._persist(record)
                return
            record["status"] = "running"
            self._persist(record)
        try:
            if self.runner:
                result = self.runner(job)
            else:
                result = self._run_process(identifier, job, executable)
            with self.lock:
                record["status"] = result.get("status", "failed") if result.get("status") in FINAL else "failed"
                record["cleanup"] = result.get("cleanup", "unknown")
                record["prediction"] = {key: result[key] for key in ("status", "runtime_tested", "quality_evaluated",
                    "operator_accepted", "stage_observations", "measurements", "failures", "final_artifact_verification") if key in result}
                record["artifacts"] = self._artifact_rows(identifier, result.get("outputs", []))
                if record["status"] == "completed":
                    identity = self._current_evidence_identity(record)
                    record["review_evidence_identity"] = identity
                    record["review_evidence_identity_sha256"] = json_sha256(identity)
                self._persist(record)
        except Exception as error:
            with self.lock:
                record.update(status="failed", error=type(error).__name__)
                self._persist(record)

    def _run_process(self, identifier, job, executable):
        if not Path("/proc/self/stat").is_file():
            raise ReviewError("managed_jobs_require_linux_or_wsl")
        env = dict(os.environ)
        resource = self._prepare_resource("runtime", identifier)
        owner_token = resource["owner_token"]
        env.update(CV_TOOLKIT_PROFILE_REGISTRY=self.config["runtime_registry"], HF_HUB_OFFLINE="1",
                   TRANSFORMERS_OFFLINE="1", HF_HUB_DISABLE_TELEMETRY="1", CV_REVIEW_OWNER_TOKEN=owner_token)
        child = self._spawn_resource(resource, [executable, "-m", "cv_toolkit.runtime", "run",
                                  str(self.root / "requests" / (identifier + ".json"))],
                                 stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 env=env, start_new_session=os.name == "posix",
                                 pass_fds=(self._storage_use.fileno(),) if self._storage_use is not None else ())
        with self.lock:
            self.children[identifier] = child
        result = None
        try:
            deadline = time.monotonic() + job.get("limits", {}).get("deadline_seconds", 900) + 60
            while child.poll() is None:
                if time.monotonic() >= deadline:
                    stop_owned_process(child)
                    raise ReviewError("review_supervisor_deadline")
                time.sleep(.1)
            result_path = self.root / "runs" / identifier / "result.json"
            if not result_path.is_file() or result_path.stat().st_size > 16 * 1024 * 1024:
                raise ReviewError("result_missing_or_oversized")
            result = json.loads(result_path.read_text())
            if result.get("job_id") != identifier:
                raise ReviewError("result_identity_mismatch")
            return result
        finally:
            cleanup = stop_owned_process(child)
            self._resource_finished(resource, cleanup)
            if isinstance(result, dict) and cleanup != "verified-stopped":
                result["cleanup"] = cleanup
                result.setdefault("failures", []).append("review_process_cleanup_unverified")
            with self.lock:
                self.children.pop(identifier, None)
                self.records[identifier]["cleanup"] = cleanup
                self.cleanup_results.append(cleanup)

    def _artifact_rows(self, identifier, rows):
        root = self.root / "runs" / identifier
        result = []
        for index, row in enumerate(rows):
            if not isinstance(row, dict) or not isinstance(row.get("ref"), str):
                raise ReviewError("artifact_contract_invalid")
            raw_path = root / row["ref"]
            path = raw_path.resolve()
            if not path.is_relative_to(root.resolve()) or not path.is_file() or raw_path.is_symlink():
                raise ReviewError("artifact_path_invalid")
            if sha256_file(path) != row.get("sha256"):
                raise ReviewError("artifact_hash_mismatch")
            # Logs, checkpoints, executable content and input copies are not browser artifacts.
            if path.suffix.lower() not in {".json", ".jsonl", ".csv", ".png", ".jpg", ".jpeg"}:
                continue
            result.append({"id": "artifact-" + str(index), "ref": row["ref"], "sha256": row["sha256"], "bytes": path.stat().st_size})
        return result

    def record(self, identifier):
        opaque_id(identifier)
        try:
            return self.records[identifier]
        except KeyError as exc:
            raise ReviewError("job_not_found") from exc

    def _current_evidence_identity(self, record):
        if record["status"] != "completed":
            raise ReviewError("review_requires_completed_result")
        if record.get("cleanup") != "verified-stopped":
            raise ReviewError("review_requires_verified_worker_cleanup")
        source = self.source(record["source_id"])
        if source["sha256"] != record["source_sha256"] or sha256_file(Path(source["path"])) != record["source_sha256"]:
            raise ReviewError("review_source_changed")
        root = (self.root / "runs" / record["id"]).resolve()
        result_path = root / "result.json"
        if result_path.is_symlink() or not result_path.is_file() or result_path.stat().st_size > 16 * 1024 * 1024:
            raise ReviewError("review_final_result_missing")
        result_bytes = result_path.read_bytes()
        result = json.loads(result_bytes)
        if result.get("schema_version") != "CVJobResult-v1" or result.get("job_id") != record["id"] or result.get("status") != "completed":
            raise ReviewError("review_final_result_identity_invalid")
        artifacts = self._artifact_rows(record["id"], result.get("outputs", []))
        if not artifacts or artifacts != record["artifacts"]:
            raise ReviewError("review_artifact_set_changed")
        request = self.root / "requests" / (record["id"] + ".json")
        return {"schema_version": "CVReviewEvidenceIdentity-v1", "job_id": record["id"],
                "source_id": record["source_id"], "source_sha256": record["source_sha256"],
                "request_sha256": sha256_file(request), "result_sha256": hashlib.sha256(result_bytes).hexdigest(),
                "artifacts": artifacts}

    def review_eligibility(self, record):
        try:
            if record["status"] != "completed":
                raise ReviewError("review_requires_completed_result")
            expected = record.get("review_evidence_identity_sha256")
            if not expected or json_sha256(record.get("review_evidence_identity")) != expected:
                raise ReviewError("review_evidence_identity_missing_or_changed")
            actual = self._current_evidence_identity(record)
            if json_sha256(actual) != expected:
                raise ReviewError("review_evidence_changed")
            if any(note.get("evidence_identity_sha256") != expected for note in record["notes"]):
                raise ReviewError("review_note_evidence_stale")
            return {"eligible": True, "reason": None, "evidence_identity_sha256": expected}
        except (OSError, ValueError, TypeError) as error:
            reason = str(error) if isinstance(error, ReviewError) else "review_evidence_unavailable"
            return {"eligible": False, "reason": reason, "evidence_identity_sha256": None}

    def public_record(self, record, *, verify_evidence=True):
        result = copy.deepcopy(record)
        result["review_eligibility"] = self.review_eligibility(record) if verify_evidence else {
            "eligible": False, "reason": "evidence_verification_required", "evidence_identity_sha256": None}
        if not verify_evidence:
            result["notes"] = []
        else:
            for note in result["notes"]:
                note["evidence_status"] = "current" if result["review_eligibility"]["eligible"] else "stale"
        progress = self.root / "runs" / record["id"] / "progress.json"
        if progress.is_file() and progress.stat().st_size <= 4096:
            try:
                value = json.loads(progress.read_text())
                result["progress"] = {key: value.get(key) for key in ("stage", "completed", "total", "unit")}
            except (ValueError, OSError):
                pass
        return result

    def list_jobs(self):
        with self.lock:
            return [self.public_record(row, verify_evidence=False) for row in sorted(self.records.values(), key=lambda row: row["created_at"], reverse=True)]

    def cancel(self, identifier):
        with self.lock:
            record = self.record(identifier)
            if record["status"] == "queued":
                record.update(status="cancelled", cleanup="not-started")
            elif record["status"] not in FINAL:
                write_state(self.root / "cancel" / identifier, {"requested_at": time.time()})
                record["status"] = "cancel-requested"
            self._persist(record)
            return self.public_record(record)

    def save_note(self, identifier, value):
        value = note_request(value)
        with self.lock:
            record = self.record(identifier)
            eligibility = self.review_eligibility(record)
            if not eligibility["eligible"]:
                raise ReviewError(eligibility["reason"])
            if value["evidence_identity_sha256"] != eligibility["evidence_identity_sha256"]:
                raise ReviewError("review_evidence_changed")
            if value["expected_revision"] != record["note_revision"]:
                raise ReviewError("revision_conflict")
            note = {"revision": record["note_revision"] + 1, "decision": value["decision"], "comment": value["comment"],
                    "author_label": value.get("author_label", ""), "authorship": "browser-submitted-unverified",
                    "recorded_at": time.time(), "source_sha256": record["source_sha256"],
                    "evidence_identity_sha256": eligibility["evidence_identity_sha256"]}
            updated = copy.deepcopy(record)
            updated["notes"].append(note)
            updated["note_revision"] = note["revision"]
            self._persist(updated)
            # Publish only after the atomic disk replacement succeeds. A failed
            # write must leave the acknowledged revision available for retry.
            self.records[identifier] = updated
            return {"acknowledged": True, "revision": note["revision"], "note": note}

    def artifact(self, identifier, artifact_id):
        opaque_id(artifact_id)
        record = self.record(identifier)
        row = next((row for row in record["artifacts"] if row["id"] == artifact_id), None)
        if row is None:
            raise ReviewError("artifact_not_found")
        root = (self.root / "runs" / identifier).resolve()
        path = (root / row["ref"]).resolve()
        if not path.is_relative_to(root) or sha256_file(path) != row["sha256"]:
            raise ReviewError("artifact_changed")
        return path

    def media(self, identifier, *, index=None, job_id=None):
        # Preview parsing has its own bounded single-worker lane; repeated slider
        # or competing-tab requests cannot spawn an unbounded decoder pool.
        with self.media_lock:
            return self._media(identifier, index=index, job_id=job_id)

    def _media(self, identifier, *, index=None, job_id=None):
        if self.closing:
            raise ReviewError("server_stopping")
        source = self.source(identifier)
        video_configuration = None
        if job_id is not None:
            record = self.record(job_id)
            if record["source_id"] != identifier:
                raise ReviewError("preview_job_source_mismatch")
            job = json.loads((self.root / "requests" / (job_id + ".json")).read_text())
            if source["kind"] == "video":
                video_configuration = {key: value for key, value in job["configuration"].items() if key in
                    {"stream_index", "clip_start_seconds", "clip_duration_seconds", "frame_policy", "max_frames", "max_width", "max_height"}}
        cache_id = hashlib.sha256((source["sha256"] + ":" + str(index) + ":" + str(video_configuration)).encode()).hexdigest()
        metadata = self.root / "previews" / (cache_id + ".json")
        preview = self.root / "previews" / (cache_id + ".png")
        if sha256_file(Path(source["path"])) != source["sha256"]:
            raise ReviewError("source_changed")
        if metadata.exists():
            result = json.loads(metadata.read_text())
            if index is None or preview.is_file() and sha256_file(preview) == result.get("sha256"):
                return result, preview
        request = {"path": source["path"], "sha256": source["sha256"], "output": str(preview), "index": index or 0,
                   "video_configuration": video_configuration}
        if self.media_runner:
            result = self.media_runner("inspect" if index is None else "preview", request)
        else:
            request_path = self.root / "requests" / ("media-" + uuid.uuid4().hex + ".json")
            write_state(request_path, request)
            executable = self.resolver(self.config["preview_profile"], self.config["runtime_registry"])
            if not Path("/proc/self/stat").is_file():
                raise ReviewError("managed_previews_require_linux_or_wsl")
            resource = self._prepare_resource("preview")
            owner_token = resource["owner_token"]
            environment = dict(os.environ, CV_REVIEW_OWNER_TOKEN=owner_token)
            child = self._spawn_resource(resource, [executable, "-m", "cv_toolkit.review_media", "inspect" if index is None else "preview", str(request_path)],
                                     stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                     env=environment, start_new_session=os.name == "posix",
                                     pass_fds=(self._storage_use.fileno(),) if self._storage_use is not None else ())
            with self.lock:
                self.children["media-" + cache_id] = child
            try:
                output, _ = child.communicate(timeout=30)
                if len(output) > 65536:
                    raise ReviewError("preview_metadata_oversized")
                result = json.loads(output)
                if child.returncode or result.get("status") != "completed":
                    raise ReviewError("preview_unavailable")
            finally:
                cleanup = stop_owned_process(child)
                self._resource_finished(resource, cleanup)
                with self.lock:
                    self.children.pop("media-" + cache_id, None)
                    self.cleanup_results.append(cleanup)
        write_state(metadata, result)
        return result, preview

    def export(self, identifier):
        with self.lock:
            record = copy.deepcopy(self.record(identifier))
            if record["status"] not in FINAL:
                raise ReviewError("job_not_finished")
            if record["status"] == "completed" or record["notes"]:
                eligibility = self.review_eligibility(record)
                if not eligibility["eligible"]:
                    raise ReviewError(eligibility["reason"])
        files = {"review.json": json.dumps(record, sort_keys=True, indent=2).encode(),
                 "predictions.json": json.dumps(record.get("prediction", {}), sort_keys=True, indent=2).encode(),
                 "review-notes.json": json.dumps(record["notes"], sort_keys=True, indent=2).encode()}
        if record.get("review_evidence_identity"):
            result_bytes = (self.root / "runs" / identifier / "result.json").read_bytes()
            if hashlib.sha256(result_bytes).hexdigest() != record["review_evidence_identity"]["result_sha256"]:
                raise ReviewError("review_evidence_changed")
            files["runtime-result.json"] = result_bytes
        csv_data = io.StringIO(newline="")
        writer = csv.writer(csv_data)
        writer.writerow(["revision", "decision", "comment", "author_label", "authorship"])
        for note in record["notes"]:
            values = [str(note.get(key, "")) for key in ("revision", "decision", "comment", "author_label", "authorship")]
            writer.writerow([csv_literal(value) for value in values])
        files["review-notes.csv"] = csv_data.getvalue().encode()
        prediction_items = []
        for row in record["artifacts"]:
            path = self.artifact(identifier, row["id"])
            if path.stat().st_size > 32 * 1024 * 1024 or sum(map(len, files.values())) + path.stat().st_size > 256 * 1024 * 1024:
                raise ReviewError("export_exceeds_limit")
            captured = path.read_bytes()
            if len(captured) != row["bytes"] or hashlib.sha256(captured).hexdigest() != row["sha256"]:
                raise ReviewError("export_artifact_changed_during_capture")
            files["artifacts/" + row["id"] + path.suffix.lower()] = captured
            if path.name == "predictions.json":
                prediction_items.extend(json.loads(captured).get("items", []))
            elif path.name == "predictions.jsonl":
                prediction_items.extend(json.loads(line) for line in captured.splitlines() if line.strip())
        prediction_table, predictions_csv = [], io.StringIO(newline="")
        prediction_writer = csv.writer(predictions_csv)
        prediction_writer.writerow(["page_or_frame", "text_or_object", "score", "track_id", "box_xyxy"])
        for item in prediction_items:
            for prediction in item.get("regions", item.get("detections", [])):
                values = [str(item.get("page_number", item.get("ordinal", 1))),
                    str(prediction.get("text", prediction.get("text_label", prediction.get("query_id", "")))),
                    str(prediction.get("recognition_score", prediction.get("score", prediction.get("detection_score", "")))),
                    str(prediction.get("track_id", "")), json.dumps(prediction.get("box_xyxy", prediction.get("quad", [])))]
                prediction_writer.writerow([csv_literal(value) for value in values])
                if len(prediction_table) < 500:
                    prediction_table.append("<tr>" + "".join("<td>" + html.escape(value) + "</td>" for value in values) + "</tr>")
        files["predictions.csv"] = predictions_csv.getvalue().encode()
        figures = []
        try:
            preview_index = max(0, int(prediction_items[0].get("page_number", 1)) - 1) if prediction_items else 0
            figure_metadata, figure = self.media(record["source_id"], index=preview_index, job_id=identifier)
            figure_bytes = figure.read_bytes()
            if hashlib.sha256(figure_bytes).hexdigest() != figure_metadata["sha256"]:
                raise ReviewError("export_figure_changed_during_capture")
            files["figures/source.png"] = figure_bytes
            figures.append('<figure><img src="figures/source.png" alt="Reviewed source preview"><figcaption>Source preview of the first analyzed page or selected clip frame.</figcaption></figure>')
        except (OSError, ValueError, subprocess.TimeoutExpired):
            figures.append("<p>Source preview unavailable; source hash remains in review.json.</p>")
        content = '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Local CV review</title><h1>Local CV review</h1><p>Predictions and browser-submitted review notes are separate. Human authorship has not been independently verified.</p>'
        content += "".join(figures) + "<h2>Prediction summary</h2><pre>" + html.escape(json.dumps(record.get("prediction", {}), indent=2)) + "</pre><h2>Review notes</h2>"
        content += "".join("<article><h3>Revision " + str(note["revision"]) + ": " + html.escape(note["decision"]) + "</h3><pre>" + html.escape(note["comment"]) + "</pre></article>" for note in record["notes"])
        content += '<h2>Model predictions</h2><p>First 500 rows shown; the CSV and JSON files contain the full retained predictions. Scores are uncalibrated model outputs.</p><table><thead><tr><th>Page/frame</th><th>Text/object</th><th>Score</th><th>Track ID</th><th>Coordinates</th></tr></thead><tbody>' + "".join(prediction_table) + '</tbody></table>'
        content += '<p><a href="review.json">Review JSON</a> · <a href="predictions.csv">Prediction CSV</a> · <a href="review-notes.csv">Review CSV</a> · <a href="integrity-manifest.json">Integrity manifest</a></p><h2>Verified artifacts</h2><ul>'
        content += "".join('<li><a href="' + html.escape(name, quote=True) + '">' + html.escape(name) + '</a></li>' for name in files if name.startswith("artifacts/")) + '</ul></html>'
        files["index.html"] = content.encode()
        if record.get("review_evidence_identity") and not self.review_eligibility(record)["eligible"]:
            raise ReviewError("review_evidence_changed_during_export")
        if sum(map(len, files.values())) > 256 * 1024 * 1024:
            raise ReviewError("export_exceeds_limit")
        manifest = {"schema_version": "CVReviewExport-v1", "job_id": identifier,
                    "files": [{"ref": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()} for name, data in sorted(files.items())]}
        files["integrity-manifest.json"] = json.dumps(manifest, sort_keys=True, indent=2).encode()
        destination = self.root / "exports" / (identifier + "-" + uuid.uuid4().hex + ".zip")
        with zipfile.ZipFile(destination, "x", compression=zipfile.ZIP_DEFLATED) as archive:
            for name, data in sorted(files.items()):
                archive.writestr(name, data)
        verify_export(destination)
        return destination

    def close(self, grace_seconds=40):
        deadline = time.monotonic() + max(0, grace_seconds)
        with self.lock:
            self.closing = True
            for identifier in list(self.records):
                if self.records[identifier]["status"] not in FINAL:
                    self.cancel(identifier)
        # A decoder may be between source verification and Popen registration.
        # Drain that lane before releasing the mount-use descriptor.
        media_drained = self.media_lock.acquire(timeout=max(0, deadline - time.monotonic()))
        if media_drained:
            self.media_lock.release()
        while time.monotonic() < deadline:
            with self.lock:
                if not self.children and all(future.done() for future in self.futures):
                    break
            time.sleep(.1)
        with self.lock:
            children = list(self.children.items())
        cleanup = []
        for identifier, child in children:
            status = stop_owned_process(child, timeout=max(0, deadline - time.monotonic()))
            cleanup.append({"id": identifier, "status": status})
            self.cleanup_results.append(status)
        self.executor.shutdown(wait=False, cancel_futures=True)
        status = "verified-stopped" if (media_drained and not self.children and all(future.done() for future in self.futures)
                 and not self.recovery_gaps() and all(value == "verified-stopped" for value in self.cleanup_results)) else "unknown"
        write_state(self.root / "cleanup.json", {"status": status,
                                                   "children": cleanup, "artifacts_retained": True})
        if status == "verified-stopped" and self._storage_use is not None:
            self._storage_use.__exit__(None, None, None)
            self._storage_use = None
        return status


def verify_export(path):
    """Verify an unopened/extracted-independent ZIP; this does not prove authorship."""
    path = Path(path)
    cap = 256 * 1024 * 1024
    if not path.is_file() or path.stat().st_size > cap:
        raise ReviewError("export_archive_oversized_or_missing")
    required = {"review.json", "predictions.json", "review-notes.json", "review-notes.csv", "predictions.csv", "index.html"}
    fixed = required | {"integrity-manifest.json", "runtime-result.json", "figures/source.png"}
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        names = [entry.filename for entry in entries]
        if len(entries) > 2048 or len(names) != len(set(names)):
            raise ReviewError("export_duplicate_or_excess_members")
        if not required | {"integrity-manifest.json"} <= set(names):
            raise ReviewError("export_required_member_missing")
        for entry in entries:
            if entry.filename not in fixed and not re.fullmatch(r"artifacts/artifact-[0-9]+\.(?:json|jsonl|csv|png|jpg|jpeg)", entry.filename):
                raise ReviewError("export_member_not_allowlisted")
            if entry.is_dir() or stat.S_IFMT(entry.external_attr >> 16) not in {0, stat.S_IFREG} or entry.flag_bits & 1:
                raise ReviewError("export_member_type_invalid")
            if entry.file_size > 64 * 1024 * 1024:
                raise ReviewError("export_member_oversized")
        if sum(entry.file_size for entry in entries) > cap:
            raise ReviewError("export_expanded_archive_oversized")
        if archive.getinfo("integrity-manifest.json").file_size > 1024 * 1024:
            raise ReviewError("export_manifest_oversized")
        manifest = json.loads(archive.read("integrity-manifest.json"))
        if not isinstance(manifest, dict) or set(manifest) != {"schema_version", "job_id", "files"} or manifest["schema_version"] != "CVReviewExport-v1":
            raise ReviewError("export_manifest_invalid")
        opaque_id(manifest["job_id"])
        rows = manifest["files"]
        if not isinstance(rows, list):
            raise ReviewError("export_manifest_files_invalid")
        seen, captured = set(), {}
        for row in rows:
            if not isinstance(row, dict) or set(row) != {"ref", "bytes", "sha256"}:
                raise ReviewError("export_manifest_row_invalid")
            ref = row["ref"]
            if not isinstance(ref, str) or ref in seen or ref == "integrity-manifest.json" or ref not in names:
                raise ReviewError("export_manifest_members_mismatch")
            seen.add(ref)
            if type(row["bytes"]) is not int or row["bytes"] != archive.getinfo(ref).file_size or not isinstance(row["sha256"], str) or not re.fullmatch(r"[0-9a-f]{64}", row["sha256"]):
                raise ReviewError("export_manifest_identity_invalid")
            data = archive.read(ref)
            if len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"]:
                raise ReviewError("export_member_hash_mismatch")
            captured[ref] = data
        if seen != set(names) - {"integrity-manifest.json"}:
            raise ReviewError("export_manifest_members_mismatch")
        review = json.loads(captured["review.json"])
        if review.get("id") != manifest["job_id"] or json.loads(captured["review-notes.json"]) != review.get("notes"):
            raise ReviewError("export_review_identity_mismatch")
        if json.loads(captured["predictions.json"]) != review.get("prediction", {}):
            raise ReviewError("export_prediction_summary_mismatch")
        identity = review.get("review_evidence_identity")
        bound = False
        if identity:
            digest = json_sha256(identity)
            if (identity.get("schema_version") != "CVReviewEvidenceIdentity-v1" or
                    digest != review.get("review_evidence_identity_sha256") or identity.get("job_id") != review["id"] or
                    identity.get("source_id") != review.get("source_id") or identity.get("source_sha256") != review.get("source_sha256")):
                raise ReviewError("export_evidence_identity_mismatch")
            if hashlib.sha256(captured.get("runtime-result.json", b"")).hexdigest() != identity.get("result_sha256"):
                raise ReviewError("export_runtime_result_mismatch")
            if identity.get("artifacts") != review.get("artifacts"):
                raise ReviewError("export_artifact_identity_mismatch")
            runtime_result = json.loads(captured["runtime-result.json"])
            if runtime_result.get("job_id") != review["id"] or runtime_result.get("status") != "completed":
                raise ReviewError("export_runtime_result_identity_invalid")
            runtime_outputs = {row["ref"]: row for row in runtime_result.get("outputs", [])}
            for row in identity["artifacts"]:
                member = "artifacts/" + row["id"] + Path(row["ref"]).suffix.lower()
                data = captured.get(member)
                if data is None or len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"]:
                    raise ReviewError("export_artifact_identity_mismatch")
                if runtime_outputs.get(row["ref"], {}).get("sha256") != row["sha256"]:
                    raise ReviewError("export_runtime_artifact_binding_mismatch")
            if any(note.get("evidence_identity_sha256") != digest for note in review["notes"]):
                raise ReviewError("export_review_note_stale")
            bound = True
        elif review["notes"]:
            raise ReviewError("export_review_note_unbound")
    return {"schema_version": "CVReviewExportVerification-v1", "status": "artifact-bytes-verified",
            "job_id": manifest["job_id"], "file_count": len(rows), "evidence_binding_verified": bound,
            "source_bytes_included": False, "authenticity_verified": False, "human_authorship_verified": False}


def recover_process_lease(resource, *, timeout=10):
    """Host recovery primitive; callers must hold the exclusive inactive-server lease."""
    if (resource.get("schema_version") != "CVReviewProcessLease-v1" or
            not isinstance(resource.get("owner_token"), str) or not re.fullmatch(r"[0-9a-f]{64}", resource["owner_token"]) or
            type(resource.get("pid")) is not int or resource["pid"] <= 0 or
            not isinstance(resource.get("start"), str) or not resource["start"].isdigit() or
            not isinstance(resource.get("boot_id"), str)):
        return {"cleanup": "unknown", "reason": "launch_identity_missing_or_untrusted"}
    try:
        if resource["boot_id"] != Path("/proc/sys/kernel/random/boot_id").read_text().strip():
            return {"cleanup": "unknown", "reason": "host_boot_identity_changed"}
        # A different start time means the historical PID was reused. Never
        # signal it; matching-token descendants are independently anchored below.
        try:
            anchor = process_anchor(resource["pid"])
            parent_present = anchor["start"] == resource["start"]
        except (OSError, IndexError):
            parent_present = False
        owned = _tagged_processes(resource["owner_token"])
        if owned is None:
            return {"cleanup": "unknown", "reason": "process_inspection_unavailable"}
        if parent_present and (resource["pid"], resource["start"]) not in owned:
            return {"cleanup": "unknown", "reason": "live_parent_token_mismatch"}
        deadline = time.monotonic() + max(0, timeout)
        for action in (signal.SIGTERM, signal.SIGKILL):
            for identity in owned:
                _signal_identity(identity, action)
            phase_end = min(deadline, time.monotonic() + timeout / 2)
            while time.monotonic() < phase_end:
                owned = _tagged_processes(resource["owner_token"])
                if not owned:
                    return {"cleanup": "verified-stopped", "reason": "owned_token_and_start_identities_verified"}
                time.sleep(.05)
        return {"cleanup": "unknown", "reason": "owned_processes_remain", "remaining_count": len(owned or [])}
    except (OSError, ValueError):
        return {"cleanup": "unknown", "reason": "process_inspection_failed"}


def _recover_records_under_lease(root):
    """Internal: entered only by host recovery with the server kernel lock held."""
    outcomes = []
    for path in sorted((root / "resources").glob("*.json")):
        if path.is_symlink() or path.stat().st_size > 65536 or path.stat().st_uid != os.getuid():
            outcomes.append({"id": path.stem, "cleanup": "unknown", "reason": "resource_record_untrusted"})
            continue
        resource = json.loads(path.read_text())
        if resource.get("id") != path.stem:
            outcomes.append({"id": path.stem, "cleanup": "unknown", "reason": "resource_record_identity_mismatch"})
            continue
        if resource.get("cleanup") in RESOURCE_RELEASED:
            continue
        outcome = recover_process_lease(resource)
        resource["cleanup"] = outcome["cleanup"]
        resource["recovery"] = {**outcome, "at": time.time()}
        write_state(path, resource)
        outcomes.append({"id": resource["id"], **outcome})
        if resource.get("job_id"):
            opaque_id(resource["job_id"])
            record_path = root / "records" / (resource["job_id"] + ".json")
            if record_path.is_file():
                record = json.loads(record_path.read_text())
                if record.get("resource_id") == resource["id"]:
                    record.update(cleanup=outcome["cleanup"])
                    if record["status"] not in FINAL:
                        record["status"] = "interrupted"
                    write_state(record_path, record)
    for path in (root / "records").glob("*.json"):
        record = json.loads(path.read_text())
        if record.get("cleanup") == "unknown" and not record.get("resource_id") and record.get("status") not in {"completed", "cancelled", "failed"}:
            outcomes.append({"id": record["id"], "cleanup": "unknown", "reason": "historical_process_identity_missing"})
    report = {"status": "verified-stopped" if all(row["cleanup"] == "verified-stopped" for row in outcomes) else "unknown",
              "resources": outcomes, "artifacts_retained": True}
    write_state(root / "recovery.json", report)
    return report


def recover_owned_resources(config):
    """No HTTP recovery endpoint; inactive owner/kernel lease required before signals."""
    from .lease import GPULease
    from .profiles import resolve_runtime
    from .storage import StorageUse, validate_storage_paths
    config = host_config(config)
    selected = resolve_runtime({"schema_version": "CVJob-v2", "runtime_profile": config["preview_profile"]},
                               registry_path=Path(config["runtime_registry"]))
    root = Path(config["state_root"])
    with StorageUse(selected["storage_binding"]):
        validate_storage_paths(selected["storage_binding"], [root, root / "resources", root / "records"])
        with GPULease(root / "server.lease", job_id="review-resource-recovery"):
            return _recover_records_under_lease(root)
